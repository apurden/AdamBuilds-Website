export type Usage = { context: number | null; h5: number | null; week: number | null }

declare module 'claude-code' {
  interface PluginState {
    'usage-bar': { usage: Usage }
  }
}
