import { atom, read, update } from 'claude-code'
import type { Register, SessionRateLimit } from 'claude-code'

import type { Usage } from '../types'

const usage = atom({ plugin: 'usage-bar', key: 'usage' } as const, {
  context: null,
  h5: null,
  week: null,
} as Usage)

const SQUARES = 10
// Square colours by position: green, then yellow, orange, red as the bar fills.
const COLORS = ['#3fb950', '#3fb950', '#3fb950', '#3fb950', '#e3c11f', '#e3c11f', '#f0883e', '#f0883e', '#f85149', '#f85149']

const pick = (limits: readonly SessionRateLimit[], kind: string) =>
  limits.find(l => l.kind === kind)?.percentUsed ?? null

async function store(
  $: Parameters<typeof update>[0],
  context: { percent?: number },
  limits: readonly SessionRateLimit[],
) {
  await update($, usage, () => ({
    context: context.percent ?? null,
    h5: pick(limits, 'five_hour'),
    week: pick(limits, 'seven_day'),
  }))
}

export const register: Register = on => {
  on('session.start', async ($, e, next) => {
    const u = await $.session.usage()
    await store($, u.context, u.rateLimits)
    return next(e)
  })

  on('session.measure', async ($, e, next) => {
    await store($, e.context, e.rateLimits)
    return next(e)
  })

  on('ui.render', { component: 'AbovePrompt' }, async ($, e, next) => {
    const u = await read($, usage)
    if (e.props.hasSurvey) return next(e)

    const { Box, Text } = $.ui.resolve(e)
    const meter = (label: string, pct: number | null) => {
      const filled = pct === null ? 0 : Math.max(pct > 0 ? 1 : 0, Math.round((pct / 100) * SQUARES))
      return (
        <Box key={label} marginRight={2}>
          <Text dimColor>{label} </Text>
          {Array.from({ length: SQUARES }, (_, i) =>
            i < filled ? (
              <Text key={i} color={COLORS[i]}>■</Text>
            ) : (
              <Text key={i} dimColor>□</Text>
            ),
          )}
          <Text dimColor> {pct === null ? '–' : `${Math.round(pct)}%`}</Text>
        </Box>
      )
    }

    return (
      <Box>
        {meter('Context', u.context)}
        {meter('5h', u.h5)}
        {meter('Week', u.week)}
      </Box>
    )
  })
}
