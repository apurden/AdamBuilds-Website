Usage bar for Claude (free, from Adam Builds)

WHAT IT DOES
Adds a small bar above the chat box in the Claude desktop app (Code tab):
  Context  how full this chat is (the same number as /context)
  5h       how much of your five-hour limit you have used
  Week     how much of your weekly limit you have used
The filled squares turn green, then yellow, orange and red as they fill up.

INSTALL (about a minute)
1. Unzip this download. You get a folder called usage-bar-plugin.
2. Move that folder somewhere it can stay, like your Documents folder.
   Claude reads the plugin from that folder, so if you delete it later the bar goes away.
3. In the Claude desktop app, open the Code tab and start a new chat.
4. Type: Install the plugin in my Documents folder called usage-bar-plugin for every chat I start.
   (If you put the folder somewhere else, say where.)
5. The bar appears above the chat box, and it shows in every new chat from now on.

REMOVE IT
Type: Uninstall the usage-bar plugin.

IS IT SAFE?
A plugin is code that runs inside your chat, so look before you install.
This one only reads the usage numbers Claude already has and draws one line
above the chat box. It makes no network calls and touches no files.
The whole thing is one short file you can read:
  mods/usage-bar/hooks/register.tsx

Made by Adam Builds. More at adambuilds.io
