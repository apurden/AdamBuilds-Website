import { atom, read, update } from 'claude-code'
import type { Register } from 'claude-code'

import type { Badge, Banner, Board } from '../types'

// The Living Workshop app counts every chat and writes ~/.claude/living-workshop/badges.json.
// This mod only reads that file and shows it: a small badge row above the prompt,
// a gold line when a new badge is earned, and /badges for the full list.
const board = atom({ plugin: 'workshop-badges', key: 'board' } as const, null as Board | null)
const banner = atom({ plugin: 'workshop-badges', key: 'banner' } as const, null as Banner)
const hidden = atom({ plugin: 'workshop-badges', key: 'hidden' } as const, false)

const BANNER_MS = 2 * 60 * 1000 // how long the "new badge" line stays
const RECENT_MS = 10 * 60 * 1000 // a chat opened soon after an unlock still celebrates it
const GOLD = '#f2c14e'

type Api = Parameters<typeof update>[0]
let file = ''
const toasted = new Set<string>()

async function badgesFile($: Api) {
  if (file) return file
  let home = $.plugin.root.includes('/.claude/') ? $.plugin.root.split('/.claude/')[0] : ''
  if (!home) home = (await $.process.run(['/usr/bin/printenv', 'HOME'])).stdout.trim()
  file = `${home}/.claude/living-workshop/badges.json`
  return file
}

async function showBanner($: Api, text: string) {
  const until = (await $.clock.now()) + BANNER_MS
  await update($, banner, () => ({ text, until }))
  $.clock.after(BANNER_MS + 500, async () => {
    const now = await $.clock.now()
    await update($, banner, b => (b && b.until <= now ? null : b))
  })
}

async function refresh($: Api) {
  let fresh: Board
  try {
    fresh = JSON.parse(await $.fs.read(await badgesFile($))) as Board
  } catch {
    return
  }
  const prev = await read($, board)
  if (!prev || prev.updated !== fresh.updated) await update($, board, () => fresh)

  // The first time ever: say how many were already earned from past chats.
  if (!(await $.store.get('introduced'))) {
    await $.store.set('introduced', true)
    const have = fresh.badges.filter(b => b.earned).length
    if (have) await showBanner($, `🏅 You already have ${have} of ${fresh.badges.length} badges from past chats. Type /badges to see them.`)
    for (const b of fresh.badges) if (b.earned) toasted.add(b.id)
    return
  }
  const now = await $.clock.now()
  const unlocked = fresh.badges.filter(b => b.earned && !b.old && b.earnedAt && now - b.earnedAt < RECENT_MS && !toasted.has(b.id))
  if (!unlocked.length) return
  for (const b of unlocked) toasted.add(b.id)
  const text =
    unlocked.length === 1
      ? `🏆 New badge: ${unlocked[0].icon} ${unlocked[0].name}, ${unlocked[0].desc}`
      : `🏆 ${unlocked.length} new badges: ${unlocked.map(b => `${b.icon} ${b.name}`).join(', ')}`
  $.ui.toast(text)
  await showBanner($, text)
}

const pct = (b: Badge) => Math.floor((100 * b.value) / b.goal)
const nextUp = (badges: Badge[]) => badges.filter(b => !b.earned).sort((p, q) => q.value / q.goal - p.value / p.goal)[0]

function listText(b: Board) {
  const earned = b.badges.filter(x => x.earned)
  const lines = [`🏅 ${earned.length} of ${b.badges.length} badges earned`, '']
  for (const x of earned) lines.push(`${x.icon} ${x.name}: ${x.desc}`)
  lines.push('', 'Still to earn:')
  for (const x of b.badges.filter(y => !y.earned)) lines.push(`${x.icon} ${x.name}: ${x.desc} (${x.value.toLocaleString()} of ${x.goal.toLocaleString()}, ${pct(x)}%)`)
  lines.push('', '/badges show puts the badge row above the prompt; /badges hide takes it away again.')
  return lines.join('\n')
}

export const register: Register = on => {
  on('session.start', async ($, e, next) => {
    await $.command.register({ name: 'badges', description: 'Show your workshop badges', argumentHint: '[hide | show]' })
    // The badge row stays off unless you turn it on with /badges show; new badges still get a short gold line.
    const stored = await $.store.get('hidden')
    await update($, hidden, () => stored !== false)
    await refresh($)
    $.clock.every(30000, () => refresh($))
    return next(e)
  })

  on('turn.complete', async ($, e, next) => {
    await refresh($)
    return next(e)
  })

  on('command.run', { command: 'badges' }, async ($, e) => {
    const arg = e.args.trim().toLowerCase()
    if (arg === 'hide' || arg === 'show') {
      await $.store.set('hidden', arg === 'hide')
      await update($, hidden, () => arg === 'hide')
      return { text: arg === 'hide' ? 'Badge row hidden. New badges still get a short line when you earn them.' : 'Badge row is on.' }
    }
    await refresh($)
    const b = await read($, board)
    return { text: b ? listText(b) : 'No badges yet: the Living Workshop app counts them. Is it running?' }
  })

  on('ui.render', { component: 'AbovePrompt' }, async ($, e, next) => {
    // Draw whatever other mods draw here (the usage bar) and add one line under it.
    const below = await next(e)
    if (e.props.hasSurvey) return below
    const b = await read($, board)
    const ban = await read($, banner)
    const off = await read($, hidden)
    const { Box, Text } = $.ui.resolve(e)
    let row = null
    if (ban) {
      row = (
        <Box key="badge-banner">
          <Text color={GOLD} bold>
            {ban.text}
          </Text>
        </Box>
      )
    } else if (b && !off) {
      const earned = b.badges.filter(x => x.earned)
      const goal = nextUp(b.badges)
      const icons = earned.slice(-10).map(x => x.icon).join(' ')
      row = (
        <Box key="badge-row">
          <Text dimColor wrap="truncate-end">
            🏅 {earned.length}/{b.badges.length} {icons}
            {goal ? `   next: ${goal.icon} ${goal.name} ${pct(goal)}%` : ''}
          </Text>
        </Box>
      )
    }
    if (!row) return below
    return (
      <Box flexDirection="column">
        {below}
        {row}
      </Box>
    )
  })
}
