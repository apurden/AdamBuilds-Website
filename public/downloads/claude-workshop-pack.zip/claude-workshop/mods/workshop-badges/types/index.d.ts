export type Badge = {
  id: string
  icon: string
  name: string
  desc: string
  goal: number
  value: number
  earned: boolean
  earnedAt: number | null
  old: boolean
}
export type Board = { updated: number; badges: Badge[] }
export type Banner = { text: string; until: number } | null

declare module 'claude-code' {
  interface PluginState {
    'workshop-badges': { board: Board | null; banner: Banner; hidden: boolean }
  }
}
