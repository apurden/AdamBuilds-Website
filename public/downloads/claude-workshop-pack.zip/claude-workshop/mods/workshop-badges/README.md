# Workshop badges

Small badges for what Claude has done on this computer. Nothing shows above the prompt until you earn a new badge: then a gold line appears under the usage bar for two minutes and a toast pops up. Type `/badges` for the full list with progress; `/badges show` keeps a badge row above the prompt and `/badges hide` removes it.

The counting is done by the workshop app (`stats.js`), which reads tool names and timestamps from every chat log and writes `~/.claude/living-workshop/badges.json`. This mod only reads that file. Badge rules live in the workshop's `stats.js`.
