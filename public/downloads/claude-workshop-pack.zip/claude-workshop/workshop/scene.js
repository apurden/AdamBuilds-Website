import * as THREE from 'three'
const { ipcRenderer } = window.require('electron')

// Video mode (?replay=tall or ?replay=wide) draws one frame at a time for the time-lapse.
const REPLAY = new URLSearchParams(location.search).get('replay')
const FRAME = REPLAY === 'tall' ? { w: 1080, h: 1920 } : REPLAY === 'wide' ? { w: 1920, h: 1080 } : null
const BAND = REPLAY === 'tall' ? { x: 0, y: 600, w: 1080, h: 580 } : REPLAY === 'wide' ? { x: 0, y: 170, w: 1920, h: 760 } : null
const W = BAND ? BAND.w : innerWidth, H = BAND ? BAND.h : innerHeight
const px = x => (x - 960) / 52 // a spot given on a 1920-wide screen, in world units
// In video mode the empty middle of the beam is left out, so the right side moves left by GAP.
const GAP = REPLAY ? 820 : 0
const pr = x => px(x - GAP)
const SPAN = REPLAY ? { l: px(150), r: pr(1930) } : null
// The vertical video is zoomed in and its camera follows the worker; the wide one shows the whole workshop.
const ZOOM = REPLAY === 'tall' ? 1.45 : 1
const PX = REPLAY ? (W * ZOOM) / (SPAN.r - SPAN.l + 0.6) : (52 * W) / 1920 // screen pixels per world unit
const TAG = REPLAY ? 1.3 : 1 // labels are bigger in videos

const r = new THREE.WebGLRenderer({ canvas: document.getElementById('c'), alpha: true, antialias: true, premultipliedAlpha: true, preserveDrawingBuffer: !!REPLAY })
r.setPixelRatio(REPLAY ? 1 : Math.min(devicePixelRatio, 2)); r.setSize(W, H); r.setClearColor(0, 0)
r.shadowMap.enabled = true; r.shadowMap.type = THREE.PCFSoftShadowMap
r.toneMapping = THREE.ACESFilmicToneMapping; r.toneMappingExposure = 1.2
const s = new THREE.Scene()
const fov = 16, visH = H / PX, dist = visH / 2 / Math.tan((fov * Math.PI) / 360)
const cam = new THREE.PerspectiveCamera(fov, W / H, 0.1, 200)
let camX = REPLAY ? (SPAN.l + SPAN.r) / 2 : 0
const lookY = visH / 2 - 0.62
const aimCam = x => { cam.position.set(x, lookY + 2.6, dist); cam.lookAt(x, lookY, 0) }
aimCam(camX)

const mat = (c, o = {}) => new THREE.MeshStandardMaterial({ color: c, roughness: 0.82, metalness: 0.04, ...o })
const shadow = m => ((m.castShadow = m.receiveShadow = true), m)
const put = (parent, m, x, y, z) => (m.position.set(x, y, z), parent.add(m), m)
const box = (p, w, h, d, c, x, y, z, o) => put(p, shadow(new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat(c, o))), x, y, z)
const cyl = (p, a, b, h, c, x, y, z, o) => put(p, shadow(new THREE.Mesh(new THREE.CylinderGeometry(a, b, h, 28), mat(c, o))), x, y, z)
const ball = (p, rad, c, x, y, z, o) => put(p, shadow(new THREE.Mesh(new THREE.SphereGeometry(rad, 28, 20), mat(c, o))), x, y, z)
let seed = 11; const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647

// Ground: wooden platforms at each side, joined by a thin beam across the middle.
const leftEnd = px(585), rightStart = pr(1505), L = REPLAY ? px(150) : px(-20), R = pr(REPLAY ? 1930 : 1940)
for (let i = 0; i < 5; i++) {
  const z = -0.95 + i * 0.47, c = i % 2 ? 0x5a3a22 : 0x4e3120
  // The back three planks leave gaps behind Claude's account name and settings gear (screen x 0-245 and 273-352), so those stay readable; the table's legs keep their floor.
  if (!REPLAY && i < 3) {
    const sx = x => ((x - 960) / 52) * (dist - z) / dist   // screen x to world x at this plank's depth
    for (const [a, b] of [[sx(245), sx(273)], [sx(352), leftEnd]]) box(s, b - a, 0.18, 0.46, c, (a + b) / 2, -0.09, z)
  } else box(s, leftEnd - L, 0.18, 0.46, c, (leftEnd + L) / 2, -0.09, z)
  box(s, R - rightStart, 0.18, 0.46, c, (R + rightStart) / 2, -0.09, z)
}
box(s, rightStart - leftEnd, 0.1, 0.5, 0x6b4630, (leftEnd + rightStart) / 2, -0.05, 0.2)

// Desk with lamp
const deskX = px(295)
box(s, 2.2, 0.12, 1, 0x7a4c2b, deskX, 1.05, -0.45)
for (const [a, b] of [[-1, -0.85], [1, -0.85], [-1, -0.05], [1, -0.05]]) box(s, 0.1, 1.02, 0.1, 0x3e2614, deskX + a, 0.51, b)
box(s, 0.8, 0.03, 0.56, 0xefe6cd, deskX - 0.3, 1.13, -0.42)
// A small stack of books on the desk, for reading
for (const [i, c] of [0xc8553d, 0x4d7ea8, 0xe0a458].entries()) box(s, 0.5 - i * 0.05, 0.1, 0.36, c, deskX - 0.85, 1.16 + i * 0.1, -0.5).rotation.y = i * 0.18
cyl(s, 0.1, 0.14, 0.08, 0x8a5a2b, deskX + 0.72, 1.15, -0.65)
cyl(s, 0.03, 0.03, 0.62, 0x444444, deskX + 0.72, 1.45, -0.65)
cyl(s, 0.08, 0.27, 0.24, 0xe0a458, deskX + 0.62, 1.82, -0.6, { emissive: 0xffb45e, emissiveIntensity: 0.9 })
// Stove
const stoveX = px(472)
cyl(s, 0.55, 0.62, 1.1, 0x26252b, stoveX, 0.6, -0.5, { metalness: 0.55, roughness: 0.45 })
const fire = box(s, 0.5, 0.42, 0.05, 0xff7a2a, stoveX, 0.5, 0.05, { emissive: 0xff5a14, emissiveIntensity: 1.5 })
cyl(s, 0.13, 0.13, 1.15, 0x26252b, stoveX, 1.72, -0.55, { metalness: 0.55 })
const fireLight = new THREE.PointLight(0xff7a2a, 9, 5, 1.6); fireLight.position.set(stoveX, 0.8, 0.5); s.add(fireLight)
// Rug for thinking
const rugX = px(543)
const rug = cyl(s, 0.62, 0.62, 0.02, 0x8c3a48, rugX, 0.01, 0.2); rug.scale.z = 0.5
// Telescope
const scopeX = pr(1610)
// The wide end points at the sky; the narrow eyepiece sits low and to the left, at eye height for the bent-over worker.
const tube = cyl(s, 0.16, 0.08, 1.5, 0xc4923f, scopeX, 1.9, -0.3, { metalness: 0.8, roughness: 0.3 }); tube.rotation.z = -0.9
const eyeCup = cyl(s, 0.1, 0.1, 0.1, 0x2a2118, scopeX - 0.587, 1.433, -0.3, { roughness: 0.6 }); eyeCup.rotation.z = -0.9
for (const a of [-0.32, 0.32]) { const l = cyl(s, 0.03, 0.03, 1.72, 0x5a3a1f, scopeX + a * 0.55, 0.84, -0.3); l.rotation.z = a * 0.5 }
const stars = []
for (let i = 0; i < 16; i++) stars.push(ball(s, 0.035 + rnd() * 0.03, 0xfff6cf, scopeX + 0.4 + rnd() * 1.6, 2.2 + rnd() * 1.6, -0.3 - rnd() * 0.3, { emissive: 0xfff6cf, emissiveIntensity: 2, transparent: true }))
// Machine
const machX = pr(1810)
box(s, 2.3, 1.7, 1, 0x3a4048, machX, 0.87, -0.5, { metalness: 0.65, roughness: 0.42 })
box(s, 1.8, 0.5, 0.05, 0x101317, machX, 1.28, 0.02)
const lamps = []
for (let i = 0; i < 6; i++) { const c = [0x5cff9d, 0xffbf47, 0xff5a4a][i % 3]; lamps.push(ball(s, 0.06, c, machX - 0.62 + i * 0.25, 1.28, 0.06, { emissive: c, emissiveIntensity: 1.6 })) }
const tubes = []
for (let i = 0; i < 3; i++) {
  const x = machX - 0.72 + i * 0.72
  tubes.push(cyl(s, 0.2, 0.2, 0.68, 0x7fffe0, x, 2.14, -0.5, { emissive: 0x35e8b7, emissiveIntensity: 0.6, transparent: true, opacity: 0.72 }))
  cyl(s, 0.24, 0.24, 0.1, 0x8a5a2b, x, 2.5, -0.5, { metalness: 0.8 }); cyl(s, 0.24, 0.24, 0.1, 0x8a5a2b, x, 1.78, -0.5, { metalness: 0.8 })
}
const gear = new THREE.Group(); put(s, gear, machX, 0.52, 0.03)
cyl(gear, 0.32, 0.32, 0.08, 0xc4923f, 0, 0, 0, { metalness: 0.8, roughness: 0.3 }).rotation.x = Math.PI / 2
for (let i = 0; i < 8; i++) { const a = (i / 8) * Math.PI * 2; box(gear, 0.1, 0.14, 0.08, 0xc4923f, Math.cos(a) * 0.36, Math.sin(a) * 0.36, 0, { metalness: 0.8 }).rotation.z = a - Math.PI / 2 }
// A small crate, so a worker standing away from the machine has something to fix
box(s, 0.42, 0.42, 0.42, 0x7a5230, machX - 2.5, 0.21, 0.55)
box(s, 0.46, 0.05, 0.46, 0x4a2c18, machX - 2.5, 0.3, 0.55)
const machLight = new THREE.PointLight(0x5ce8c0, 5, 5, 1.6); machLight.position.set(machX, 2.1, 0.5); s.add(machLight)
// Lighting
s.add(new THREE.HemisphereLight(0xcfd6ff, 0x3a2414, 1.25))
const sun = new THREE.DirectionalLight(0xfff0dc, 2.2); sun.position.set(-3, 9, 7); sun.castShadow = true
sun.shadow.mapSize.set(2048, 512); Object.assign(sun.shadow.camera, { left: -20, right: 20, top: 6, bottom: -3, near: 1, far: 30 }); sun.shadow.radius = 3; sun.shadow.bias = -0.0006
s.add(sun)
const lampLight = new THREE.PointLight(0xffb45e, 7, 4.5, 1.6); lampLight.position.set(deskX + 0.6, 1.6, -0.3); s.add(lampLight)

// The worker
const CAST = [
  { skin: 0xf6d2ad, hair: 0xd9a441, shirt: 0x4fa7a0, apron: 0x2d5f66, scarf: 0x3fd0c9, pants: 0x38405a, extra: 'pigtails' },
  { skin: 0x9c6a48, hair: 0x1f1a1c, shirt: 0xb56cc9, apron: 0x5b3570, scarf: 0xe7a6ff, pants: 0x2b2640, extra: 'beanie' },
  { skin: 0xe9b58f, hair: 0xb8452c, shirt: 0x7fae5a, apron: 0x46652f, scarf: 0xf4d35e, pants: 0x3a3320, extra: 'bun' },
  { skin: 0xc98f66, hair: 0x6e6a78, shirt: 0xd96c6c, apron: 0x7a3333, scarf: 0x7fb2ff, pants: 0x2c3044, extra: 'cap' },
]
function makeWorker(size = 1, look = {}) {
  const L = { skin: 0xf2c79b, hair: 0x3a2a22, shirt: 0xd9a15f, apron: 0x6b3f21, scarf: 0xe8743b, pants: 0x2f2d40, goggles: true, extra: null, ...look }
  const root = new THREE.Group(), body = new THREE.Group(); root.add(body); root.scale.setScalar(size)
  const limb = (x, y, len, rad, c) => { const piv = new THREE.Group(); put(body, piv, x, y, 0); const m = shadow(new THREE.Mesh(new THREE.CapsuleGeometry(rad, len, 6, 14), mat(c))); put(piv, m, 0, -len / 2 - rad * 0.5, 0); return piv }
  const legL = limb(-0.17, 0.62, 0.32, 0.12, L.pants), legR = limb(0.17, 0.62, 0.32, 0.12, L.pants)
  for (const l of [legL, legR]) { const b = ball(l, 0.14, 0x4a2a16, 0, -0.5, 0.05); b.scale.set(1, 0.62, 1.35) }
  const torso = ball(body, 0.36, L.shirt, 0, 0.92, 0); torso.scale.set(1, 1.1, 0.82)
  const apron = ball(body, 0.33, L.apron, 0, 0.87, 0.07); apron.scale.set(0.86, 1.02, 0.76)
  box(body, 0.2, 0.13, 0.04, 0x8c5a30, 0, 0.84, 0.34)
  const scarf = put(body, shadow(new THREE.Mesh(new THREE.TorusGeometry(0.24, 0.085, 12, 28), mat(L.scarf))), 0, 1.25, 0); scarf.rotation.x = Math.PI / 2
  const tail = box(body, 0.13, 0.36, 0.06, L.scarf, 0.2, 1.08, 0.2); tail.rotation.z = 0.25
  const armL = limb(-0.38, 1.13, 0.34, 0.09, L.shirt), armR = limb(0.38, 1.13, 0.34, 0.09, L.shirt)
  for (const a of [armL, armR]) ball(a, 0.1, L.skin, 0, -0.5, 0)
  const head = new THREE.Group(); put(body, head, 0, 1.68, 0)
  const skull = ball(head, 0.46, L.skin, 0, 0, 0)
  const hair = ball(head, 0.475, L.hair, 0, 0.1, -0.05); hair.scale.set(1, 0.9, 1); hair.material.side = THREE.DoubleSide
  hair.geometry = new THREE.SphereGeometry(0.475, 28, 18, 0, Math.PI * 2, 0, Math.PI * 0.52)
  const tuft = ball(head, 0.1, L.hair, 0.05, 0.52, 0); tuft.scale.set(0.7, 1.5, 0.7); tuft.rotation.z = -0.5
  if (L.extra === 'pigtails') for (const x of [-0.52, 0.52]) { const p = ball(head, 0.17, L.hair, x, 0.05, -0.08); p.scale.y = 1.35 }
  if (L.extra === 'beanie') { const b = ball(head, 0.515, L.scarf, 0, 0.14, -0.03); b.scale.y = 0.86; ball(head, 0.1, L.apron, 0, 0.56, 0) }
  if (L.extra === 'bun') ball(head, 0.2, L.hair, 0, 0.56, -0.12)
  if (L.extra === 'cap') { const c = ball(head, 0.505, L.scarf, 0, 0.15, -0.03); c.scale.y = 0.8; const brim = box(head, 0.5, 0.05, 0.3, L.apron, 0, 0.22, 0.46); brim.rotation.x = 0.14 }
  if (L.goggles) put(head, shadow(new THREE.Mesh(new THREE.TorusGeometry(0.46, 0.035, 10, 40), mat(0x5a4034))), 0, 0.18, 0).rotation.x = Math.PI / 2 - 0.08
  if (L.goggles) for (const x of [-0.17, 0.17]) {
    put(head, new THREE.Mesh(new THREE.TorusGeometry(0.135, 0.03, 10, 24), mat(0xc98d3a, { metalness: 0.7, roughness: 0.3 })), x, 0.2, 0.41)
    ball(head, 0.12, 0x9fe6ff, x, 0.2, 0.39, { roughness: 0.15, metalness: 0.2, emissive: 0x3aa7d0, emissiveIntensity: 0.25 }).scale.z = 0.4
  }
  const eyes = [-0.15, 0.15].map(x => { const e = ball(head, 0.062, 0x241f2c, x, -0.04, 0.42); e.scale.set(0.9, 1.25, 0.5); return e })
  for (const x of [-0.26, 0.26]) { const c = ball(head, 0.07, 0xee9a7f, x, -0.13, 0.36); c.scale.z = 0.3; c.castShadow = false }
  const mouth = put(head, new THREE.Mesh(new THREE.TorusGeometry(0.07, 0.016, 8, 16, Math.PI), mat(0x7a3f2c)), 0, -0.16, 0.44); mouth.rotation.z = Math.PI
  // Things the worker can hold, each shown only at its station
  const book = new THREE.Group(); put(armR, book, -0.12, -0.55, 0.14)
  box(book, 0.46, 0.34, 0.05, 0xa5361f, 0, 0, 0); box(book, 0.42, 0.3, 0.06, 0xf4ead2, 0, 0, 0.02)
  const pen = box(armR, 0.035, 0.34, 0.035, 0xf7efe0, 0, -0.65, 0.1); pen.rotation.x = 0.7
  const wrench = new THREE.Group(); put(armR, wrench, 0, -0.6, 0.06)
  box(wrench, 0.07, 0.5, 0.05, 0xb7bcc6, 0, -0.14, 0, { metalness: 0.8, roughness: 0.3 })
  put(wrench, new THREE.Mesh(new THREE.TorusGeometry(0.08, 0.03, 8, 16), mat(0xb7bcc6, { metalness: 0.8 })), 0, -0.42, 0)
  return { root, body, head, legL, legR, armL, armR, eyes, book, pen, wrench }
}
const STATION = {
  read: { x: deskX - 1.55, z: 0.45, face: 0.55, label: 'Reading files' },
  write: { x: deskX - 0.85, z: 0.32, face: 2.3, label: 'Writing' },
  idle: { x: px(417), z: 0.5, face: 0.95, label: 'Resting' },
  think: { x: rugX, z: 0.2, face: 0, label: 'Thinking' },
  web: { x: scopeX - 1.42, z: -0.3, face: Math.PI / 2, label: 'Searching the web' },
  run: { x: machX - 1.75, z: 0.55, face: 1.0, label: 'Running a command' },
}
const stoolX = STATION.idle.x, stoolZ = STATION.idle.z
cyl(s, 0.27, 0.27, 0.06, 0x8a5a2b, stoolX, 0.29, stoolZ)
for (const [a, b] of [[-0.16, -0.14], [0.16, -0.14], [0, 0.18]]) cyl(s, 0.03, 0.03, 0.28, 0x4a2c18, stoolX + a, 0.13, stoolZ + b)
const w = makeWorker(); s.add(w.root); w.root.position.set(STATION.idle.x, 0, STATION.idle.z)
const helpers = [0, 1, 2].map(() => { const h = makeWorker(0.5); h.root.visible = false; h.pop = 0; s.add(h.root); return h })
let wantHelpers = 0
// Background jobs: a small crew stays at the machine until the jobs finish.
const OFF_LEFT = px(-70), CREW_SIZE = 0.74, CREW_SPEED = 9.5
// Each worker gets their own place, so the machine stays visible. Labels stack above the machine, clear of the tubes and telescope.
const crewSpots = [
  { x: machX + 1.5, z: 0.25, face: -1.95, dir: -1, tagY: 3.5 }, // right of the machine
  { x: machX - 3.05, z: 0.55, face: 1.5, dir: 1, tagY: 4.15 }, // at the crate
  { x: machX - 1.6, z: 0.05, face: 1.95, dir: 1, tagY: 4.8 }, // left of the machine, behind the main worker's spot
  { x: machX + 0.55, z: 0.8, face: 2.7, dir: 0, tagY: 5.45 }, // a fourth job only: in front
]
if (REPLAY) crewSpots.forEach((c, i) => (c.tagY = 3.55 + i * 0.82))
const TAG_MIN_X = pr(1724), TAG_MAX_X = pr(1826)
const RUN_FRONT = { ...STATION.run, x: machX - 0.85, z: 0.85, face: 2.6 }
const crew = CAST.map((look, i) => {
  const c = makeWorker(CREW_SIZE, { ...look, goggles: false })
  c.root.visible = false; c.state = 'free'; c.spot = crewSpots[i]; c.jobId = null; c.color = look.scarf; s.add(c.root)
  const canvas = document.createElement('canvas'); canvas.width = 512; canvas.height = 96
  const tex = new THREE.CanvasTexture(canvas); tex.colorSpace = THREE.SRGBColorSpace
  c.tag = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthTest: false })); c.tag.scale.set(3.3 * TAG, 0.62 * TAG, 1); c.tag.visible = false; s.add(c.tag)
  c.canvas = canvas; c.tex = tex
  // A thin line from the label to the worker it belongs to
  c.tether = new THREE.Line(new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3()]), new THREE.LineBasicMaterial({ color: look.scarf, transparent: true, opacity: 0.75, depthTest: false }))
  c.tether.frustumCulled = false; c.tether.visible = false; s.add(c.tether)
  return c
})
// One short scene plays at a time: waving someone in, or being woken up.
let cut = null
const actions = []
const crewFor = id => crew.find(c => c.jobId === id)
function jobStart(id, label, instant) {
  if (crewFor(id) || actions.some(a => a.id === id)) return
  if (instant) { const c = crew.find(k => k.state === 'free'); if (c) sendIn(c, id, label, true); return }
  actions.push({ type: 'wave', id, label })
}
function sendIn(c, id, label, instant) {
  c.jobId = id; c.state = instant ? 'work' : 'run-in'; c.root.visible = true; c.tag.visible = true
  c.root.position.set(instant ? c.spot.x : OFF_LEFT, 0, instant ? c.spot.z : 0.2)
  c.tagX = c.root.position.x; c.tagY = instant ? c.spot.tagY : 1.78
  setSign(label, c.canvas, c.tex, c.color)
}
function jobEnd(id) {
  const queued = actions.findIndex(a => a.id === id)
  if (queued >= 0) { actions.splice(queued, 1); return }
  const c = crewFor(id)
  if (c) { c.jobId = null; c.state = 'run-back'; setSign('Done!', c.canvas, c.tex, c.color) }
}

// A small sign over the worker saying what is going on
const signCanvas = document.createElement('canvas'); signCanvas.width = 512; signCanvas.height = 96
const signTex = new THREE.CanvasTexture(signCanvas); signTex.colorSpace = THREE.SRGBColorSpace
const sign = new THREE.Sprite(new THREE.SpriteMaterial({ map: signTex, transparent: true, depthTest: false })); sign.scale.set(3.3 * TAG, 0.62 * TAG, 1); s.add(sign)
function setSign(text, canvas = signCanvas, tex = signTex, color = 0xe8743b) {
  const c = canvas.getContext('2d'); c.clearRect(0, 0, 512, 96)
  c.font = `600 ${text.length > 20 ? 30 : 40}px -apple-system, Helvetica, sans-serif`; const tw = c.measureText(text).width
  const bw = tw + 56, x = 256 - bw / 2
  c.fillStyle = 'rgba(24,20,28,.92)'; c.beginPath(); c.roundRect(x, 12, bw, 72, 22); c.fill()
  c.strokeStyle = `#${color.toString(16).padStart(6, '0')}`; c.lineWidth = 4; c.stroke()
  c.fillStyle = '#fff4e4'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(text, 256, 49)
  tex.needsUpdate = true
}
// Thought bubble and sleep letters
const bubble = new THREE.Group(); s.add(bubble)
const white = o => mat(0xf7f0df, { roughness: 1, ...o })
put(bubble, new THREE.Mesh(new THREE.SphereGeometry(0.06, 12, 10), white()), 0, 0, 0)
put(bubble, new THREE.Mesh(new THREE.SphereGeometry(0.1, 12, 10), white()), 0.14, 0.17, 0)
const cloud = put(bubble, new THREE.Mesh(new THREE.SphereGeometry(0.42, 20, 14), white()), 0.5, 0.56, 0); cloud.scale.set(1.25, 0.82, 0.3)
const dots = [0, 1, 2].map(i => put(bubble, new THREE.Mesh(new THREE.SphereGeometry(0.058, 12, 10), mat(0x3a2a22)), 0.28 + i * 0.22, 0.56, 0.14))
const zCanvas = document.createElement('canvas'); zCanvas.width = zCanvas.height = 64
{ const c = zCanvas.getContext('2d'); c.font = '700 54px Georgia'; c.fillStyle = '#dfe6ff'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText('z', 32, 34) }
const zTex = new THREE.CanvasTexture(zCanvas)
const zs = [0, 1, 2].map(() => { const z = new THREE.Sprite(new THREE.SpriteMaterial({ map: zTex, transparent: true, depthTest: false })); s.add(z); return z })
// Small particles: steam, sparks, ink
const parts = Array.from({ length: 40 }, () => { const m = new THREE.Mesh(new THREE.SphereGeometry(0.06, 10, 8), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0, depthWrite: false })); m.visible = false; s.add(m); return { m, life: 0, max: 1, vx: 0, vy: 0, grow: 0 } })
let nextPart = 0
function emit(x, y, z, color, vx, vy, max, size, grow = 0) {
  const p = parts[nextPart++ % parts.length]
  Object.assign(p, { life: max, max, vx, vy, grow }); p.m.position.set(x, y, z); p.m.material.color.set(color); p.m.scale.setScalar(size); p.m.visible = true
}

// Behaviour: keep one station as the goal and stay long enough to be readable.
const SPEED = 8.5, DWELL = 1.7
let station = 'idle', wanted = null, arrivedAt = 0, walking = false, facing = STATION.idle.face, shownLabel = ''
setSign(STATION.idle.label); shownLabel = STATION.idle.label
function chooseNext(t) {
  if (cut) return
  if (!wanted || wanted === station) { wanted = null; return }
  if (!walking && t - arrivedAt < DWELL) return
  station = wanted; wanted = null; walking = true
}
ipcRenderer.on('activity', (_e, msg) => handle(msg))
function handle(msg) {
  if (msg.kind === 'go') { wanted = msg.station; if (msg.station !== station) console.log('goal', msg.station) }
  if (msg.kind === 'helpers') { wantHelpers = msg.count; console.log('helpers', msg.count) }
  if (msg.kind === 'jobStart') { console.log('job start', msg.label); jobStart(msg.id, msg.label, msg.instant) }
  if (msg.kind === 'jobEnd') { console.log('job end'); jobEnd(msg.id) }
  // While hidden, stop drawing so it costs nothing
  if (msg.kind === 'pause') { paused = msg.on; if (!paused && !looping) { looping = true; clock.getDelta(); requestAnimationFrame(animate) } }
}
let paused = false, looping = true

const clock = new THREE.Clock()
let drawTick = 0, frames = 0, lastFps = 0, sparkAcc = 0, steamAcc = 0
const lerpAngle = (a, b, k) => a + Math.atan2(Math.sin(b - a), Math.cos(b - a)) * k
let simT = 0
// One step of the world; returns how often to draw (every frame while busy, less when calm).
function step(dt) {
  simT += dt
  const t = simT
  if (!cut && !walking && actions.length) {
    const a = actions[0]
    if (a.type === 'wave') { const free = crew.find(k => k.state === 'free'); if (free) { actions.shift(); cut = { type: 'wave', t0: t, a, c: free, sent: false } } }
    else { actions.shift(); cut = { type: 'wake', t0: t, c: a.c, wasAsleep: station === 'idle' } }
  }
  chooseNext(t)
  // With a third job running, that worker has the main worker's usual spot, so the main worker uses the front of the machine
  const goal = station === 'run' && crew[2].state !== 'free' ? RUN_FRONT : STATION[station], pos = w.root.position
  const dx = goal.x - pos.x, dz = goal.z - pos.z, d = Math.hypot(dx, dz)
  if (walking) {
    if (d < 0.08) { walking = false; arrivedAt = t } else {
      const step = Math.min(SPEED * dt, d); pos.x += (dx / d) * step; pos.z += (dz / d) * step
      facing = lerpAngle(facing, Math.atan2(dx, dz), Math.min(1, dt * 12))
    }
  }
  const label = !cut ? goal.label : cut.type === 'wake' ? (t - cut.t0 > (cut.wasAsleep ? 1.1 : 0.2) ? 'Job finished!' : goal.label) : 'Sending a helper'
  if (label !== shownLabel) { setSign(label); shownLabel = label }
  let at = !walking ? station : null
  if (cut && !(cut.type === 'wake' && cut.wasAsleep && t - cut.t0 < 1.1)) at = null
  if (!walking) {
    let aim = goal.face
    if (cut && cut.type === 'wave') aim = cut.sent && cut.c.state === 'run-in' ? Math.atan2(cut.c.root.position.x - pos.x, 2.5) : cut.sent ? 0.9 : -0.85
    if (cut && cut.type === 'wake' && !at) aim = Math.atan2(cut.c.root.position.x - pos.x, 1.5)
    facing = lerpAngle(facing, aim, Math.min(1, dt * 7))
  }
  w.body.rotation.y = facing
  // Pose
  const swing = walking ? Math.sin(t * 17) * 0.95 : 0
  w.legL.rotation.x = swing; w.legR.rotation.x = -swing
  let armLx = -swing * 0.8, armRx = swing * 0.8, armRz = 0, armLz = 0.08, bodyY = 0, tilt = walking ? 0.16 : 0, headX = 0, headY = 0
  if (walking) bodyY = Math.abs(Math.sin(t * 17)) * 0.12
  else {
    bodyY = Math.sin(t * 2.2) * 0.012
    if (at === 'read') { armRx = -1.25 + Math.sin(t * 1.3) * 0.05; armLx = -1.1; armLz = -0.45; headX = 0.28 + Math.sin(t * 1.3) * 0.03; headY = Math.sin(t * 0.8) * 0.12 }
    if (at === 'write') { armRx = -1.25 + Math.sin(t * 15) * 0.12; armRz = Math.sin(t * 9) * 0.22; armLx = -1; headX = 0.3 }
    if (at === 'run') { armRx = -1.9 + (Math.sin(t * 11) + 1) * 0.72; tilt = 0.08 + Math.sin(t * 11) * 0.05 }
    if (at === 'web') { tilt = 0.42; w.legL.rotation.x = -0.42; w.legR.rotation.x = -0.42; armRx = -1.05; armRz = 0.12; armLx = -0.95; armLz = -0.12; headX = -0.25; bodyY = Math.sin(t * 1.6) * 0.006 }
    if (at === 'think') { armRx = -2.15; armRz = -0.42; armLx = -0.5; armLz = -0.6; headY = Math.sin(t * 0.9) * 0.3; headX = -0.12 + Math.sin(t * 0.6) * 0.05 }
    if (at === 'idle') { bodyY = -0.3; w.legL.rotation.x = -1.2; w.legR.rotation.x = -1.2; armRx = -0.95; armLx = -0.95; armRz = -0.12; armLz = -0.12; headX = 0.3 + Math.sin(t * 1.4) * 0.04; tilt = 0.13 }
  }
  if (cut && !at) {
    const e = t - cut.t0
    if (cut.type === 'wave') {
      if (!cut.sent && e < 1.5) { armRx = -2.9; armRz = -0.25 + Math.sin(t * 13) * 0.42; armLx = -0.1; bodyY = Math.abs(Math.sin(t * 6.5)) * 0.05; headX = -0.08 }
      else { armRx = -0.15; armLx = -0.15; armLz = 0.35; armRz = 0.35; headX = -0.05 }
      if (!cut.sent && e >= 1.5) { sendIn(cut.c, cut.a.id, cut.a.label, false); cut.sent = true }
      if (cut.sent && cut.c.state !== 'run-in') { armRx = -2.7; armRz = -0.2 + Math.sin(t * 11) * 0.3; if (cut.done === undefined) cut.done = t; if (t - cut.done > 0.7) cut = null }
    } else if (cut.type === 'wake') {
      const p = e - (cut.wasAsleep ? 1.1 : 0.2)
      if (p < 0.5) { bodyY = Math.sin((p / 0.5) * Math.PI) * 0.42; armRx = armLx = -2.5; armRz = -0.3; armLz = -0.3; headX = -0.15 }
      else { armRx = -2.7; armRz = -0.2 + Math.sin(t * 11) * 0.3; headX = -0.05 }
      if (p > 1.1) { cut.c.state = 'leave'; setSign('See you!', cut.c.canvas, cut.c.tex); cut = null }
    }
  }
  w.armL.rotation.set(armLx, 0, -armLz); w.armR.rotation.set(armRx, 0, armRz + 0.08)
  w.body.position.y = bodyY; w.body.rotation.x = tilt
  w.head.rotation.set(headX, headY, 0)
  const blink = t % 3.7 > 3.58 || at === 'idle' ? 0.12 : 1.25
  w.eyes.forEach(e => (e.scale.y = blink))
  w.book.visible = at === 'read'; w.pen.visible = at === 'write'; w.wrench.visible = at === 'run'
  // Sign above the head
  sign.position.set(pos.x + (at === 'web' ? 0.6 : 0), (at === 'web' ? 2.55 : 2.85) + bodyY * 0.3 + (at === 'idle' ? -0.3 : 0), pos.z)
  // Thought bubble
  const thinking = at === 'think'
  bubble.visible = thinking
  if (thinking) { bubble.position.set(pos.x + 0.42, 2.0, pos.z + 0.1); dots.forEach((m, i) => m.scale.setScalar(0.55 + 0.75 * Math.max(0, Math.sin(t * 5 - i * 0.9)))) }
  // Sleep letters
  zs.forEach((z, i) => {
    z.visible = at === 'idle'; if (!z.visible) return
    const f = (t * 0.32 + i / 3) % 1
    z.position.set(pos.x + 0.35 + f * 0.7, 1.6 + f * 1.2, pos.z); z.scale.setScalar(0.18 + f * 0.26); z.material.opacity = Math.sin(f * Math.PI)
  })
  // Machine, telescope, fire
  const busy = at === 'run'
  const machBusy = busy || crew.some(c => c.state === 'work')
  crew.forEach((c, i) => {
    if (c.state === 'free') return
    const cp = c.root.position
    let tx = c.spot.x, tz = c.spot.z, running = true
    if (c.state === 'run-back') { const main = w.root.position; const side = main.x > px(960) ? 1 : -1; tx = main.x + side * 0.95; tz = main.z + 0.12 }
    if (c.state === 'leave') { tx = OFF_LEFT; tz = 0.2 }
    if (c.state === 'wake-wait' || c.state === 'work') running = false
    if (running) {
      const dx = tx - cp.x, dist = Math.abs(dx)
      if (dist > 0.06) cp.x += Math.sign(dx) * Math.min(CREW_SPEED * dt, dist)
      const zGoal = dist < 2.2 ? tz : 0.2
      cp.z += (zGoal - cp.z) * Math.min(1, dt * 7)
      c.body.rotation.y = lerpAngle(c.body.rotation.y, dist > 0.06 ? Math.sign(dx) * 1.35 : 0, Math.min(1, dt * 12))
      const sw = Math.sin(t * 19 + i) * 1.05
      c.legL.rotation.x = sw; c.legR.rotation.x = -sw; c.armL.rotation.x = -sw * 0.85; c.armR.rotation.x = sw * 0.85; c.armR.rotation.z = 0
      c.body.position.y = Math.abs(Math.sin(t * 19 + i)) * 0.13; c.body.rotation.x = 0.17
      c.wrench.visible = false; c.book.visible = c.pen.visible = false
      if (dist <= 0.06) {
        if (c.state === 'run-in') c.state = 'work'
        else if (c.state === 'run-back') { c.state = 'wake-wait'; actions.push({ type: 'wake', c }) }
        else if (c.state === 'leave') { c.state = 'free'; c.root.visible = false; c.tag.visible = false; c.tether.visible = false }
      }
    } else if (c.state === 'work') {
      const hit = Math.sin(t * 9 + i * 1.7)
      c.body.rotation.y = lerpAngle(c.body.rotation.y, c.spot.face, Math.min(1, dt * 8))
      c.wrench.visible = true; c.book.visible = c.pen.visible = false
      c.legL.rotation.x = c.legR.rotation.x = 0; c.armL.rotation.x = -0.3; c.armR.rotation.x = -1.7 + (hit + 1) * 0.7
      c.body.position.y = Math.abs(hit) * 0.03; c.body.rotation.x = 0.05 + hit * 0.04
      if (sparkAcc > 0.16 && hit < -0.7) emit(cp.x + c.spot.dir * 0.5, 0.75, cp.z, 0xffc65c, (Math.random() - 0.5) * 1.6, 0.8 + Math.random(), 0.4, 0.3)
    } else {
      // Tapping the sleeping worker's shoulder until they are up
      c.wrench.visible = false; c.legL.rotation.x = c.legR.rotation.x = 0
      const toMain = w.root.position.x - cp.x
      c.body.rotation.y = lerpAngle(c.body.rotation.y, Math.sign(toMain) * 1.25, Math.min(1, dt * 9))
      c.armR.rotation.x = -1.75 + Math.sin(t * 15) * 0.45; c.armL.rotation.x = -1.75 + Math.sin(t * 15 + 1.2) * 0.45
      c.body.position.y = Math.abs(Math.sin(t * 7.5)) * 0.1; c.body.rotation.x = 0.06
    }
    const atWork = c.state === 'work'
    const tagGoalX = atWork ? Math.max(TAG_MIN_X, Math.min(cp.x, TAG_MAX_X)) : Math.min(cp.x, TAG_MAX_X)
    c.tagX = atWork ? c.tagX + (tagGoalX - c.tagX) * Math.min(1, dt * 8) : tagGoalX
    c.tagY += ((atWork ? c.spot.tagY : 1.78 + c.body.position.y * 0.4) - c.tagY) * Math.min(1, dt * 8)
    c.tag.position.set(c.tagX, c.tagY, cp.z + 0.1)
    c.tether.visible = atWork
    if (atWork) {
      const a = c.tether.geometry.attributes.position
      a.setXYZ(0, c.tagX, c.tagY - 0.24 * TAG, cp.z + 0.1); a.setXYZ(1, cp.x, 1.72, cp.z + 0.1); a.needsUpdate = true
    }
  })
  gear.rotation.z -= dt * (machBusy ? 7 : 0.35)
  lamps.forEach((l, i) => (l.material.emissiveIntensity = 0.5 + 1.8 * (Math.sin(t * (machBusy ? 13 : 1.8) + i * 1.4) + 1) * 0.5))
  tubes.forEach((m, i) => (m.material.emissiveIntensity = (machBusy ? 1.1 : 0.42) + 0.3 * Math.sin(t * (machBusy ? 8 : 1.4) + i)))
  machLight.intensity = machBusy ? 9 + Math.sin(t * 13) * 3 : 5
  const looking = at === 'web'
  stars.forEach((m, i) => { m.visible = looking; m.material.opacity = 0.45 + 0.55 * (0.5 + 0.5 * Math.sin(t * 4 + i * 2.1)) })
  const flick = 0.75 + 0.25 * Math.sin(t * 11) * Math.sin(t * 7.3)
  fire.material.emissiveIntensity = 1.4 * flick; fireLight.intensity = 9 * flick
  lampLight.intensity = at === 'write' || at === 'read' ? 11 : 7
  // Particles
  steamAcc += dt; sparkAcc += dt
  if (machBusy && steamAcc > 0.16) { steamAcc = 0; emit(machX - 0.72 + Math.floor(Math.random() * 3) * 0.72, 2.6, -0.5, 0xe4f2ee, (Math.random() - 0.5) * 0.25, 1, 1.2, 0.8, 1.7) }
  if (busy && sparkAcc > 0.18 && Math.sin(t * 11) < -0.6) { sparkAcc = 0; for (let i = 0; i < 3; i++) emit(pos.x + 0.75, 0.9, pos.z + 0.1, 0xffc65c, (Math.random() - 0.3) * 2.2, 1 + Math.random() * 1.5, 0.45, 0.4) }
  if (at === 'write' && sparkAcc > 0.28) { sparkAcc = 0; emit(deskX - 0.45 + Math.random() * 0.4, 1.2, -0.2, 0xffe08f, (Math.random() - 0.5) * 0.4, 0.8, 0.8, 0.45) }
  for (const p of parts) {
    if (p.life <= 0) continue
    p.life -= dt; p.m.position.x += p.vx * dt; p.m.position.y += p.vy * dt
    p.m.scale.multiplyScalar(1 + p.grow * dt); p.m.material.opacity = Math.max(0, (p.life / p.max) * 0.65)
    if (p.life <= 0) p.m.visible = false
  }
  // Helpers trot behind the worker
  helpers.forEach((h, i) => {
    const on = i < wantHelpers
    h.pop += ((on ? 1 : 0) - h.pop) * Math.min(1, dt * 7)
    h.root.visible = h.pop > 0.02; if (!h.root.visible) return
    h.root.scale.setScalar(0.5 * h.pop)
    const side = i % 2 ? 1 : -1, tx = pos.x + side * (0.82 + i * 0.32) , tz = pos.z + 0.28
    const hx = tx - h.root.position.x, hz = tz - h.root.position.z, hd = Math.hypot(hx, hz)
    if (h.pop < 0.1) h.root.position.set(tx, 0, tz)
    const moving = hd > 0.1
    if (moving) { const st = Math.min((SPEED + 1) * dt, hd); h.root.position.x += (hx / hd) * st; h.root.position.z += (hz / hd) * st; h.body.rotation.y = Math.atan2(hx, hz) }
    else h.body.rotation.y = lerpAngle(h.body.rotation.y, 0, dt * 5)
    const sw = Math.sin(t * 20 + i) * (moving ? 1 : 0.35)
    h.legL.rotation.x = sw; h.legR.rotation.x = -sw; h.armL.rotation.x = -sw; h.armR.rotation.x = sw
    h.body.position.y = Math.abs(Math.sin(t * (moving ? 20 : 8) + i)) * 0.14
    h.book.visible = h.pen.visible = h.wrench.visible = false
  })
  if (ZOOM > 1) {
    const half = W / PX / 2, goalX = Math.max(SPAN.l + half - 0.3, Math.min(pos.x, SPAN.r - half + 0.3))
    camX += (goalX - camX) * Math.min(1, dt * 1.4); aimCam(camX)
  }
  return walking || machBusy || cut || wantHelpers > 0 || crew.some(c => c.state !== 'free') ? 1 : at === 'idle' ? 3 : 2
}
function animate() {
  if (paused) { looping = false; return }
  requestAnimationFrame(animate)
  const every = step(Math.min(clock.getDelta(), 0.05))
  drawTick++
  if (drawTick % every === 0) { r.render(s, cam); frames++ }
  if (simT - lastFps > 5) { console.log('fps', Math.round(frames / (simT - lastFps))); frames = 0; lastFps = simT }
}
if (REPLAY) import('./replay.js').then(m => m.run({ step, now: () => simT, handle, render: () => r.render(s, cam), canvas: r.domElement, FRAME, BAND, ipcRenderer }))
else animate()
console.log('ready', W, H, 'px/unit', PX.toFixed(1))
