// Turns one Claude Code chat log into a timed script for the workshop time-lapse.
// Like the live workshop, it reads tool names, turn markers and background-job descriptions only.
const fs = require('fs')
const path = require('path')
const readline = require('readline')
const { stationFor, shortLabel, home } = require('./shared')

const PROJECTS = path.join(home, '.claude', 'projects')
const GAP_CAP_MS = 90 * 1000 // a quiet stretch longer than this is squeezed, so the video skips the waiting
const WORK_CAP_MS = 5 * 60 * 1000 // for the "hours of work" title, breaks longer than this do not count
const BREAK_MS = 2 * 60 * 60 * 1000 // "latest session" starts after the last break this long
const MIN_WORK_MS = 20 * 60 * 1000 // ...as long as that leaves at least this much work
const THINK_AFTER_MS = 2500, STAY_AT_TELESCOPE_MS = 15000, REST_AFTER_MS = 1500

const CATEGORY = { read: 'read', write: 'write', run: 'run', web: 'web' }

// Every chat on this Mac, newest first, with its title when it has one.
function recentChats(limit = 8) {
  const out = []
  let dirs = []
  try { dirs = fs.readdirSync(PROJECTS) } catch { return out }
  for (const d of dirs) {
    const dir = path.join(PROJECTS, d)
    let names = []
    try { names = fs.readdirSync(dir) } catch { continue }
    for (const n of names) {
      if (!n.endsWith('.jsonl')) continue
      const f = path.join(dir, n)
      try { const st = fs.statSync(f); if (st.size > 20000) out.push({ file: f, mtime: st.mtimeMs, size: st.size, project: d }) } catch {}
    }
  }
  // Restarting Claude touches old logs, so sort by when Claude last actually worked in each chat.
  out.sort((a, b) => b.mtime - a.mtime)
  const list = out.slice(0, limit * 3)
  for (const c of list) { const info = tailInfo(c.file); c.title = info.title || c.project.replace(/^-Users-[^-]+-/, '').replace(/-/g, ' '); c.lastActive = info.lastActive || c.mtime }
  return list.sort((a, b) => b.lastActive - a.lastActive).slice(0, limit)
}

// The chat's title and last activity sit near the end; read only the tail to find them.
function tailInfo(file) {
  const info = { title: null, lastActive: null }
  try {
    const st = fs.statSync(file), len = Math.min(st.size, 4 * 1024 * 1024)
    const fd = fs.openSync(file, 'r'), buf = Buffer.alloc(len)
    fs.readSync(fd, buf, 0, len, st.size - len); fs.closeSync(fd)
    const text = buf.toString('utf8')
    const m = [...text.matchAll(/"customTitle":"((?:[^"\\]|\\.)*)"/g)].pop()
    if (m) info.title = JSON.parse(`"${m[1]}"`)
    const lines = text.split('\n')
    for (let i = lines.length - 1; i >= 0 && !info.lastActive; i--) {
      if (!lines[i].includes('"type":"assistant"')) continue
      const t = lines[i].match(/"timestamp":"([^"]+)"/)
      if (t) info.lastActive = Date.parse(t[1])
    }
  } catch {}
  return info
}
const chatTitle = file => tailInfo(file).title

function resolveChat(arg) {
  if (!arg) return recentChats(1)[0]?.file
  if (fs.existsSync(arg)) return arg
  for (const c of recentChats(500)) if (path.basename(c.file).startsWith(arg)) return c.file
  return null
}

// Read the log into a flat list of moments, in time order.
async function readChat(file) {
  const moments = []
  const rl = readline.createInterface({ input: fs.createReadStream(file, { encoding: 'utf8' }), crlfDelay: Infinity })
  for await (const l of rl) {
    const isA = l.includes('"type":"assistant"'), isU = l.includes('"type":"user"')
    const isDone = l.includes('<tool-use-id>') && (l.includes('"queue-operation"') || l.includes('"type":"attachment"'))
    if (!isA && !isU && !isDone) continue
    let r
    try { r = JSON.parse(l) } catch { continue }
    if (r.isSidechain || !r.timestamp) continue
    const t = Date.parse(r.timestamp)
    const content = r.message && r.message.content
    if (r.type === 'queue-operation' || r.type === 'attachment') {
      const text = r.content || (r.attachment && r.attachment.prompt) || ''
      const m = typeof text === 'string' && text.match(/<tool-use-id>([^<]+)<\/tool-use-id>/)
      if (m) moments.push({ t, kind: 'jobEnd', id: m[1] })
      continue
    }
    if (r.type === 'user') {
      if (typeof content === 'string' || (Array.isArray(content) && content.some(b => b.type === 'text'))) {
        if (!(r.origin && r.origin.kind === 'task-notification')) moments.push({ t, kind: 'prompt' })
      }
      if (Array.isArray(content)) for (const b of content) if (b.type === 'tool_result') moments.push({ t, kind: 'result', id: b.tool_use_id })
    }
    if (r.type === 'assistant' && Array.isArray(content)) {
      for (const b of content) if (b.type === 'tool_use') {
        const input = b.input || {}
        if (input.run_in_background && !/electron/.test(input.command || '')) moments.push({ t, kind: 'jobStart', id: b.id, label: shortLabel(input) })
        else if (b.name === 'Agent') moments.push({ t, kind: 'helper', id: b.id })
        else moments.push({ t, kind: 'tool', station: stationFor(b.name) })
      }
      if (r.message.stop_reason === 'end_turn') moments.push({ t, kind: 'end' })
    }
  }
  moments.sort((a, b) => a.t - b.t)
  return moments
}

// Replays the live workshop's rules in real time: where the worker would be, and when.
function stations(moments) {
  const changes = [], helperChanges = []
  let pending = null, lastStation = null
  const helpers = new Set()
  const go = (t, station) => changes.push({ t, station })
  const flush = t => { if (pending && pending.t <= t) { go(pending.t, pending.station); pending = null } }
  for (const m of moments) {
    flush(m.t)
    if (m.kind === 'prompt') { pending = null; go(m.t, 'think') }
    if (m.kind === 'tool' && m.station) { pending = null; lastStation = m.station; go(m.t, m.station) }
    if (m.kind === 'helper') { helpers.add(m.id); helperChanges.push({ t: m.t, count: helpers.size }) }
    if (m.kind === 'result') {
      if (helpers.delete(m.id)) helperChanges.push({ t: m.t, count: helpers.size })
      pending = { t: m.t + (lastStation === 'web' ? STAY_AT_TELESCOPE_MS : THINK_AFTER_MS), station: 'think' }
    }
    if (m.kind === 'end') pending = { t: m.t + REST_AFTER_MS, station: 'idle' }
  }
  if (pending) go(pending.t, pending.station)
  return { changes, helperChanges }
}

// Squeezed time: every quiet stretch counts for at most GAP_CAP_MS.
function squeezer(times, cap) {
  const eff = [0]
  for (let i = 1; i < times.length; i++) eff.push(eff[i - 1] + Math.min(times[i] - times[i - 1], cap))
  const at = t => {
    if (t <= times[0]) return 0
    let lo = 0, hi = times.length - 1
    while (lo < hi) { const mid = (lo + hi + 1) >> 1; if (times[mid] <= t) lo = mid; else hi = mid - 1 }
    return eff[lo] + Math.min(t - times[lo], cap)
  }
  return { at, total: eff[eff.length - 1] }
}

const fmtDuration = ms => {
  const min = Math.round(ms / 60000)
  if (min < 60) return `${Math.max(1, min)} min`
  const h = Math.floor(min / 60), m = min % 60
  return m ? `${h} h ${m} min` : `${h} hours`
}

async function buildPlan(file, opts = {}) {
  const seconds = opts.seconds || 25, fps = opts.fps || 30, speed = opts.speed || 2.2
  const LEAD = 0.5, TAIL = 1.6, SLOT = 2.6
  let moments = await readChat(file)
  if (!moments.length) throw new Error('This chat has no activity to replay.')
  // Pick the stretch: the latest session (after the last long break), the whole chat, or the last few hours.
  const last = moments[moments.length - 1].t
  let from = moments[0].t
  if (opts.hours) from = last - opts.hours * 3600 * 1000
  else if (!opts.whole) {
    // Go back break by break until the stretch holds at least MIN_WORK_MS of work.
    for (let i = moments.length - 1; i > 0; i--) {
      if (moments[i].t - moments[i - 1].t <= BREAK_MS) continue
      const part = moments.slice(i).map(m => m.t)
      if (squeezer(part, WORK_CAP_MS).total >= MIN_WORK_MS) { from = moments[i].t; break }
    }
  }
  moments = moments.filter(m => m.t >= from)
  const begin = moments[0].t

  const { changes, helperChanges } = stations(moments)
  const times = [...new Set(moments.map(m => m.t).concat(changes.map(c => c.t)))].sort((a, b) => a - b)
  const sq = squeezer(times, GAP_CAP_MS)
  const simTotal = (seconds - TAIL) * speed
  const sim = t => LEAD + (sq.total ? sq.at(t) / sq.total : 0) * (simTotal - LEAD)
  const events = []

  // The worker goes to whichever station took up most of each short slot, so the story reads clearly.
  const mapped = changes.map(c => ({ at: sim(c.t), station: c.station }))
  let prev = 'idle'
  for (let a = LEAD; a < simTotal; a += SLOT) {
    const b = Math.min(simTotal, a + SLOT), share = {}
    let cur = 'idle'
    for (let i = 0; i < mapped.length; i++) if (mapped[i].at <= a) cur = mapped[i].station
    let x = a
    for (const c of mapped) {
      if (c.at <= a) continue
      if (c.at >= b) break
      share[cur] = (share[cur] || 0) + (c.at - x); x = c.at; cur = c.station
    }
    share[cur] = (share[cur] || 0) + (b - x)
    const best = Object.entries(share).sort((p, q) => q[1] - p[1])[0][0]
    if (best !== prev) { events.push({ at: a, msg: { kind: 'go', station: best } }); prev = best }
  }
  for (const h of helperChanges) events.push({ at: sim(h.t), msg: { kind: 'helpers', count: Math.min(3, h.count) } })

  // Background jobs: keep the longest ten, and give each one enough screen time for the crew to arrive.
  const starts = new Map()
  const jobs = []
  for (const m of moments) {
    if (m.kind === 'jobStart') starts.set(m.id, m)
    if (m.kind === 'jobEnd' && starts.has(m.id)) { const s = starts.get(m.id); starts.delete(m.id); jobs.push({ ...s, end: m.t }) }
  }
  for (const s of starts.values()) jobs.push({ ...s, end: last + 3600 * 1000 }) // still running when the log ends
  jobs.sort((a, b) => (b.end - b.t) - (a.end - a.t))
  const kept = jobs.slice(0, 10).filter(j => sim(j.t) < simTotal - 4)
  for (const j of kept) {
    const s = sim(j.t), e = Math.max(sim(Math.min(j.end, last)), s + 7)
    events.push({ at: s, msg: { kind: 'jobStart', id: j.id, label: j.label } })
    if (j.end <= last && e < simTotal + TAIL * speed) events.push({ at: e, msg: { kind: 'jobEnd', id: j.id } })
  }
  events.sort((a, b) => a.at - b.at)

  // Counters on screen and the clock, both in video time.
  const counters = []
  for (const m of moments) {
    if (m.kind === 'tool' && CATEGORY[m.station]) counters.push({ at: sim(m.t), cat: CATEGORY[m.station] })
    if (m.kind === 'jobStart') counters.push({ at: sim(m.t), cat: 'job' })
    if (m.kind === 'helper') counters.push({ at: sim(m.t), cat: 'helper' })
  }
  counters.sort((a, b) => a.at - b.at)
  const clock = { sim: times.map(sim), real: times }
  const work = squeezer(times, WORK_CAP_MS).total
  const totals = counters.reduce((o, c) => ((o[c.cat] = (o[c.cat] || 0) + 1), o), {})
  return {
    fps, speed, seconds, frames: Math.round(seconds * fps), simTotal,
    events, counters, clock, totals,
    title: opts.title || `${fmtDuration(work)} of Claude work`,
    subtitle: opts.subtitle || `in ${seconds} seconds`,
    multiDay: new Date(begin).toDateString() !== new Date(last).toDateString(),
    from: begin, to: last, workMs: work, chat: chatTitle(file),
  }
}

module.exports = { buildPlan, recentChats, resolveChat, chatTitle, tailInfo }

// Quick check from the command line: node timeline.js <chat file or id>
if (require.main === module) {
  buildPlan(resolveChat(process.argv[2]), { whole: process.argv.includes('--whole') }).then(p => {
    console.log(p.title, '|', p.chat, '|', new Date(p.from).toLocaleString(), '->', new Date(p.to).toLocaleString())
    console.log('totals', p.totals, 'events', p.events.length)
    for (const e of p.events.slice(0, 40)) console.log(e.at.toFixed(1), JSON.stringify(e.msg))
  })
}
