// Small pieces both the live workshop and the time-lapse use.
const os = require('os')
const { execSync } = require('child_process')

function stationFor(name) {
  if (/^(Read|Grep|Glob|NotebookRead)$/.test(name)) return 'read'
  if (/^(Edit|Write|NotebookEdit)$/.test(name)) return 'write'
  if (/^(WebFetch|WebSearch)$/.test(name) || /browser|chrome/i.test(name)) return 'web'
  if (/update_plan|wrap_up|mark_chapter|ToolSearch|AskUserQuestion/.test(name)) return null
  return 'run'
}

// Words of the account's full name, except the first name, never appear in a label.
// Mac: the full name from `id -F`. Elsewhere: the login name (Windows and Linux have no simple full-name lookup).
let hidden = null
function hiddenWords() {
  if (hidden) return hidden
  hidden = []
  try {
    if (process.platform === 'darwin') {
      const full = execSync('id -F', { encoding: 'utf8' }).trim()
      hidden = full.split(/\s+/).slice(1).filter(w => w.length > 2)
    } else {
      const u = os.userInfo().username
      if (u && u.length > 2) hidden = [u]
    }
  } catch {}
  return hidden
}
// Labels can show on screen or in a video: drop file paths and the account's surname.
function clean(text) {
  let s = String(text).replace(/(~|\/Users|\/Volumes|\/private|\/tmp|\/home)\/\S*/g, '').replace(/[A-Za-z]:\\\S*/g, '').replace(/\s+/g, ' ').trim()
  for (const w of hiddenWords()) s = s.replace(new RegExp(w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi'), '')
  return s.replace(/\s+/g, ' ').trim()
}
const shortLabel = input => {
  const text = clean(input.description || input.prompt || '') || 'Background job'
  return text.length > 30 ? `${text.slice(0, 29).trimEnd()}…` : text
}

module.exports = { stationFor, clean, shortLabel, home: os.homedir() }
