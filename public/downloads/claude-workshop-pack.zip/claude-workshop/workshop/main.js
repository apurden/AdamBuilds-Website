// Living Workshop test: a see-through, click-through window that follows a Claude Code session log.
// It reads only tool names and turn markers from the log, never the conversation text.
const { app, BrowserWindow, Tray, Menu, nativeImage, screen, ipcMain, shell, Notification } = require('electron')
const { spawn } = require('child_process')
const fs = require('fs')
const path = require('path')
const os = require('os')
const { stationFor, shortLabel } = require('./shared')
const { recentChats } = require('./timeline')

const HEIGHT = 350
const MAC = process.platform === 'darwin'
const LOWER = MAC ? 24 : 0 // Mac: reaches below the work area so the floor meets the Dock and the beam sits under Claude's model row
const IDLE_HIDE_MS = Number(process.env.WORKSHOP_IDLE_MS || 5 * 60 * 1000) // fade out after this long with nothing happening
const FADE_MS = 700
const THINK_AFTER_MS = 2500
const STAY_AT_TELESCOPE_MS = 15000 // web lookups come in runs, so stay put between them
const REST_AFTER_MS = 1500
let win, tray
// Showing and hiding: fade out when Claude has been idle a while, come back on the next prompt or activity.
let shown = true, alwaysShow = false, lastActive = Date.now(), fadeTimer = null, home = null
function fadeTo(target, done) {
  clearInterval(fadeTimer)
  const start = win.getOpacity(), t0 = Date.now()
  fadeTimer = setInterval(() => {
    const k = Math.min(1, (Date.now() - t0) / FADE_MS)
    win.setOpacity(start + (target - start) * k)
    if (k >= 1) { clearInterval(fadeTimer); if (done) done() }
  }, 16)
}
function showWorkshop() {
  if (shown || !win) return
  shown = true; console.log('show')
  send({ kind: 'pause', on: false })
  win.setOpacity(0); win.showInactive(); if (home) win.setBounds(home); console.log('shown at', JSON.stringify(win.getBounds())); fadeTo(1)
}
function hideWorkshop() {
  if (!shown || !win) return
  shown = false; console.log('hide')
  fadeTo(0, () => { if (!shown) { win.hide(); send({ kind: 'pause', on: true }) } })
}
const markActive = () => { lastActive = Date.now(); showWorkshop() }
const send = msg => win && !win.isDestroyed() && win.webContents.send('activity', msg)

function newestSession() {
  const root = path.join(os.homedir(), '.claude', 'projects')
  let best = null
  for (const dir of fs.readdirSync(root)) {
    const full = path.join(root, dir)
    if (!fs.statSync(full).isDirectory()) continue
    for (const f of fs.readdirSync(full)) {
      if (!f.endsWith('.jsonl')) continue
      const p = path.join(full, f)
      const t = fs.statSync(p).mtimeMs
      if (!best || t > best.t) best = { p, t }
    }
  }
  return best && best.p
}

// Background jobs start with run_in_background on a tool call and end with a queued completion notice.
const bgJobs = new Map()
function trackBackground(r, onStart = () => {}, onEnd = () => {}) {
  const content = r.message && r.message.content
  if (r.type === 'assistant' && Array.isArray(content)) {
    for (const b of content) {
      const input = b.input || {}
      // The workshop's own launch is a background command; it should not count as a job.
      if (b.type === 'tool_use' && input.run_in_background && !/electron/.test(input.command || '') && !bgJobs.has(b.id)) { bgJobs.set(b.id, shortLabel(input)); onStart(b.id, bgJobs.get(b.id)) }
    }
  }
  if (r.type === 'queue-operation' || r.type === 'attachment') {
    const text = r.content || (r.attachment && r.attachment.prompt) || ''
    const m = typeof text === 'string' && text.match(/<tool-use-id>([^<]+)<\/tool-use-id>/)
    if (m && bgJobs.delete(m[1])) onEnd(m[1])
  }
}
const jobStarted = (id, label) => { console.log('job start', label); send({ kind: 'jobStart', id, label }) }
const jobEnded = id => { console.log('job end'); send({ kind: 'jobEnd', id }) }

// Following chats. With WORKSHOP_SESSION set it follows that one log; otherwise it follows every
// Claude Code chat on this Mac that has been written to recently, so any project or chat drives it.
const PROJECTS = process.env.WORKSHOP_PROJECTS || path.join(os.homedir(), '.claude', 'projects')
const FRESH_MS = 10 * 60 * 1000 // a chat written to this recently is followed
const DROP_MS = 2 * 60 * 60 * 1000 // stop following a chat after this long with no writes
const CATCH_UP_MS = 3 * 60 * 60 * 1000 // on launch, only jobs started this recently can still be running
const STALE_JOB_MS = 60 * 60 * 1000 // a job whose chat has been silent this long was most likely closed with Claude
const followers = new Map() // log file -> { offset, partial, lastWrite }
const jobFile = new Map() // background job -> log file it came from
const seenSize = new Map() // quiet chats' last known size, so the first lines of a new prompt are not missed
let thinkTimer = null, restTimer = null, lastStation = null
const helpers = new Set()
const clear = () => { clearTimeout(thinkTimer); clearTimeout(restTimer) }
const started = file => (id, label) => { jobFile.set(id, file); jobStarted(id, label) }
const ended = id => { jobFile.delete(id); jobEnded(id) }

function onRecord(r, file) {
  trackBackground(r, started(file), ended)
  if (r.type === 'user' || r.type === 'assistant' || r.type === 'queue-operation') markActive()
  const content = r.message && r.message.content
  if (r.type === 'user') {
    if (typeof content === 'string' || (Array.isArray(content) && content.some(b => b.type === 'text'))) {
      clear()
      send({ kind: 'go', station: 'think' })
    }
    if (Array.isArray(content)) for (const b of content) if (b.type === 'tool_result') {
      if (helpers.delete(b.tool_use_id)) send({ kind: 'helpers', count: helpers.size })
      clear()
      thinkTimer = setTimeout(() => send({ kind: 'go', station: 'think' }), lastStation === 'web' ? STAY_AT_TELESCOPE_MS : THINK_AFTER_MS)
    }
  }
  if (r.type === 'assistant' && Array.isArray(content)) {
    for (const b of content) if (b.type === 'tool_use') {
      if (b.name === 'Agent' && !(b.input && b.input.run_in_background)) { helpers.add(b.id); send({ kind: 'helpers', count: helpers.size }); continue }
      const station = stationFor(b.name)
      if (station) { clear(); lastStation = station; send({ kind: 'go', station }) }
    }
    if (r.message.stop_reason === 'end_turn') {
      clear()
      restTimer = setTimeout(() => send({ kind: 'go', station: 'idle' }), REST_AFTER_MS)
    }
  }
}

function addFile(file, catchUp, startAt) {
  if (followers.has(file)) return
  let st
  try { st = fs.statSync(file) } catch { return }
  // Catch up on jobs already running in this chat when the window opens.
  if (catchUp) for (const l of fs.readFileSync(file, 'utf8').split('\n')) {
    if (!l.includes('run_in_background') && !l.includes('<tool-use-id>')) continue
    try {
      const r = JSON.parse(l)
      // A job started hours ago is long gone: Claude closing stops it without writing a finish line.
      if (r.type === 'assistant' && r.timestamp && Date.now() - Date.parse(r.timestamp) > CATCH_UP_MS) continue
      trackBackground(r, id => jobFile.set(id, file), id => jobFile.delete(id))
    } catch {}
  }
  followers.set(file, { offset: startAt !== undefined && startAt <= st.size ? startAt : st.size, partial: '', lastWrite: st.mtimeMs })
  console.log('following', path.basename(path.dirname(file)), path.basename(file))
}

function scanChats(catchUp) {
  let dirs = []
  try { dirs = fs.readdirSync(PROJECTS) } catch { return }
  const now = Date.now()
  for (const d of dirs) {
    const dir = path.join(PROJECTS, d)
    let names = []
    try { names = fs.readdirSync(dir) } catch { continue }
    for (const n of names) {
      if (!n.endsWith('.jsonl')) continue
      const f = path.join(dir, n)
      if (followers.has(f)) continue
      try {
        const st = fs.statSync(f)
        if (now - st.mtimeMs < FRESH_MS) addFile(f, catchUp, catchUp ? undefined : seenSize.has(f) ? seenSize.get(f) : st.size < 200000 ? 0 : undefined)
        else seenSize.set(f, st.size)
      } catch {}
    }
  }
}

function readNew() {
  for (const [file, fo] of followers) {
    let size
    try { size = fs.statSync(file).size } catch { followers.delete(file); continue }
    if (size < fo.offset) fo.offset = size
    if (size === fo.offset) continue
    const fd = fs.openSync(file, 'r')
    const buf = Buffer.alloc(size - fo.offset)
    fs.readSync(fd, buf, 0, buf.length, fo.offset)
    fs.closeSync(fd)
    fo.offset = size; fo.lastWrite = Date.now()
    const lines = (fo.partial + buf.toString('utf8')).split('\n')
    fo.partial = lines.pop()
    for (const l of lines) { try { onRecord(JSON.parse(l), file) } catch {} }
  }
}

function tidy() {
  const now = Date.now()
  // Jobs from a chat that has gone quiet for an hour were most likely stopped when Claude closed.
  for (const [id, file] of jobFile) {
    const fo = followers.get(file)
    if (!fo || now - fo.lastWrite > STALE_JOB_MS) { bgJobs.delete(id); console.log('dropping stale job'); ended(id) }
  }
  for (const [file, fo] of followers) {
    if (now - fo.lastWrite > DROP_MS && ![...jobFile.values()].includes(file)) followers.delete(file)
  }
}

function followChats() {
  const one = process.env.WORKSHOP_SESSION
  if (one) addFile(one, true)
  else scanChats(true)
  for (const [id, label] of bgJobs) send({ kind: 'jobStart', id, label, instant: true })
  setInterval(readNew, 250)
  if (!one) setInterval(() => scanChats(false), 3000)
  setInterval(tidy, 60000)
}

// Badges: count every chat in a separate process (the first count reads all logs) and refresh often.
let counting = false
function countBadges() {
  if (counting) return
  counting = true
  const p = spawn(process.execPath, [path.join(__dirname, 'stats.js')], { env: { ...process.env, ELECTRON_RUN_AS_NODE: '1' }, stdio: ['ignore', 'pipe', 'inherit'] })
  p.stdout.on('data', d => process.stdout.write(d))
  p.on('close', () => { counting = false })
}

// Time-lapse: replay a chat into MP4s in Movies (Mac) or Videos (Windows, Linux) / Workshop Time-lapses, then show them.
const LAPSE_DIR = path.join(os.homedir(), MAC ? 'Movies' : 'Videos', 'Workshop Time-lapses')
// Mac shows a wrench as text in the menu bar; Windows and Linux need a picture in the tray, so the state goes in the tooltip there.
const trayState = busy => { if (MAC) tray.setTitle(busy ? '🔧🎬' : '🔧'); else tray.setToolTip(busy ? 'Claude Workshop: making a time-lapse…' : 'Claude Workshop') }
let rendering = null
function makeTimelapse(chat, extra = []) {
  if (rendering) return
  rendering = chat.title; trayState(true); buildMenu()
  const saved = []
  const p = spawn(process.execPath, [path.join(__dirname, 'timelapse.js'), '--chat', chat.file, ...extra], { env: Object.fromEntries(Object.entries(process.env).filter(([k]) => k !== 'ELECTRON_RUN_AS_NODE')), stdio: ['ignore', 'pipe', 'pipe'] })
  const read = d => { for (const l of String(d).split('\n')) { console.log('[time-lapse]', l); const m = l.match(/^saved (.+\.mp4)/); if (m) saved.push(m[1]) } }
  p.stdout.on('data', read); p.stderr.on('data', read)
  p.on('close', code => {
    rendering = null; trayState(false); buildMenu()
    const ok = code === 0 && saved.length
    if (Notification.isSupported()) new Notification({ title: ok ? 'Time-lapse ready' : 'Time-lapse failed', body: ok ? `${chat.title}: a Short and a wide version` : (MAC ? 'See ~/Library/Logs/claude-workshop.log' : 'Ask Claude to check the workshop log'), silent: true }).show()
    if (ok) { shell.showItemInFolder(saved[0]) }
  })
}

let testJob = 0, h = 0
const openTests = []
function buildMenu() {
  const go = (label, station) => ({ label, click: () => send({ kind: 'go', station }) })
  const ago = t => { const m = Math.round((Date.now() - t) / 60000); return m < 60 ? `${m} min ago` : m < 1440 ? `${Math.round(m / 60)} h ago` : `${Math.round(m / 1440)} d ago` }
  let chats = []
  try { chats = recentChats(6) } catch {}
  const chatItems = extra => chats.length ? chats.map(c => ({ label: `${c.title.slice(0, 44)}  ·  ${ago(c.lastActive)}`, enabled: !rendering, click: () => makeTimelapse(c, extra) })) : [{ label: 'No chats found', enabled: false }]
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: 'Claude Workshop', enabled: false },
    { label: rendering ? `Making a time-lapse of “${rendering.slice(0, 30)}”…` : 'Make a time-lapse (latest stretch of work)', submenu: rendering ? undefined : chatItems([]), enabled: !rendering },
    { label: 'Make a time-lapse (whole chat)', submenu: chatItems(['--whole']), enabled: !rendering },
    { label: 'Open time-lapses folder', click: () => { fs.mkdirSync(LAPSE_DIR, { recursive: true }); shell.openPath(LAPSE_DIR) } },
    { type: 'separator' },
    go('Read at the desk', 'read'), go('Walk to desk', 'write'), go('Walk to machine', 'run'),
    go('Walk to telescope', 'web'), go('Think', 'think'), go('Rest by the stove', 'idle'),
    { label: 'Add or remove helpers', click: () => { h = (h + 1) % 4; send({ kind: 'helpers', count: h }) } },
    { label: 'Start a test background job', click: () => { const id = `test-${++testJob}`; openTests.push(id); send({ kind: 'jobStart', id, label: `Test job ${testJob}` }) } },
    { label: 'Finish a test background job', click: () => { const id = openTests.shift(); if (id) send({ kind: 'jobEnd', id }) } },
    { type: 'separator' },
    { label: 'Move up a little', click: () => { const [x, y] = win.getPosition(); win.setPosition(x, y - 4) } },
    { label: 'Move down a little', click: () => { const [x, y] = win.getPosition(); win.setPosition(x, y + 4) } },
    { label: 'Hide now (comes back on your next prompt)', click: () => hideWorkshop() },
    { label: 'Show now', click: () => markActive() },
    { label: 'Always show (for recording)', type: 'checkbox', checked: alwaysShow, click: item => { alwaysShow = item.checked; if (alwaysShow) markActive() } },
    { label: 'Quit', click: () => app.quit() },
  ]))
}
function makeTray() {
  const icon = path.join(__dirname, 'tray.png')
  tray = new Tray(MAC || !fs.existsSync(icon) ? nativeImage.createEmpty() : nativeImage.createFromPath(icon))
  trayState(false)
  if (!MAC) tray.on('click', () => tray.popUpContextMenu()) // Windows opens tray menus on right-click only; make left-click work too
  buildMenu()
  setInterval(() => { if (!rendering) buildMenu() }, 60000) // keep the chat list fresh
}

app.whenReady().then(() => {
  if (app.dock) app.dock.hide()
  const d = screen.getPrimaryDisplay()
  const wa = d.workArea
  console.log('displays', screen.getAllDisplays().map(x => `${x.size.width}x${x.size.height}@${x.scaleFactor}`).join(' '), 'using', JSON.stringify(wa))
  win = new BrowserWindow({
    x: wa.x, y: wa.y + wa.height - HEIGHT + LOWER, width: wa.width, height: HEIGHT,
    transparent: true, frame: false, hasShadow: false, resizable: false, movable: false, enableLargerThanScreen: true,
    focusable: false, skipTaskbar: true, alwaysOnTop: true, type: 'panel', show: false,
    backgroundColor: '#00000000',
    webPreferences: { nodeIntegration: true, contextIsolation: false, backgroundThrottling: false },
  })
  win.setAlwaysOnTop(true, 'screen-saver')
  win.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true })
  win.setIgnoreMouseEvents(true)
  win.loadFile('index.html')
  win.webContents.on('console-message', (_e, _l, m) => console.log('[page]', m))
  win.webContents.once('did-finish-load', () => {
    win.showInactive()
    // macOS keeps new windows inside the work area, so place it again once it is showing
    home = { x: wa.x, y: wa.y + wa.height - HEIGHT + LOWER, width: wa.width, height: HEIGHT }
    win.setBounds(home)
    console.log('bounds', JSON.stringify(win.getBounds()))
    // Running background jobs keep it on screen, so the wake-up at the end is never missed.
    setInterval(() => { if (shown && !alwaysShow && bgJobs.size === 0 && Date.now() - lastActive > IDLE_HIDE_MS) hideWorkshop() }, 5000)
    followChats()
    
    if (process.env.WORKSHOP_DEMO === 'web') setTimeout(() => send({ kind: 'go', station: 'web' }), 300)
    else if (process.env.WORKSHOP_DEMO) {
      const at = (ms, msg) => setTimeout(() => { console.log('demo', JSON.stringify(msg)); send(msg) }, ms)
      at(500, { kind: 'jobStart', id: 'd1', label: 'Copying videos to the drive' })
      at(800, { kind: 'go', station: 'idle' })
      at(9000, { kind: 'jobStart', id: 'd2', label: 'Rendering the final cut' })
      at(16000, { kind: 'jobStart', id: 'd3', label: 'Checking every file' })
      at(26000, { kind: 'jobEnd', id: 'd2' })
      at(36000, { kind: 'jobEnd', id: 'd1' })
      at(46000, { kind: 'jobEnd', id: 'd3' })
    }
    const dir = process.env.WORKSHOP_CAPTURE
    if (dir) {
      fs.mkdirSync(dir, { recursive: true })
      let n = 0
      const t = setInterval(async () => {
        const img = await win.webContents.capturePage()
        fs.writeFileSync(path.join(dir, `f${String(n++).padStart(3, '0')}.png`), img.toPNG())
        if (n >= Number(process.env.WORKSHOP_FRAMES || 12)) clearInterval(t)
      }, Number(process.env.WORKSHOP_CAPTURE_MS || 3000))
    }
  })
  makeTray()
})
app.on('window-all-closed', () => app.quit())
