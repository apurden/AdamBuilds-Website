// Video mode: plays a chat's script through the workshop one frame at a time and hands each
// finished frame (workshop plus title, clock and counters) to the main process for the MP4.
const ACCENT = '#e8743b', INK = '#fff4e4', MUTED = 'rgba(255,244,228,0.58)'
const FONT = '"SF Pro Display", -apple-system, system-ui, sans-serif'
const ROUNDED = '"SF Pro Rounded", "SF Pro Display", -apple-system, system-ui, sans-serif'
const COUNTERS = [
  { cat: 'read', icon: '📖', label: 'Files read' },
  { cat: 'write', icon: '✏️', label: 'Edits' },
  { cat: 'run', icon: '⚙️', label: 'Commands' },
  { cat: 'web', icon: '🔭', label: 'Web lookups' },
  { cat: 'job', icon: '👷', label: 'Background jobs' },
  { cat: 'helper', icon: '🤝', label: 'Helpers' },
]

export async function run({ step, now, handle, render, canvas, FRAME, BAND, ipcRenderer }) {
  const plan = await ipcRenderer.invoke('plan')
  const tall = FRAME.h > FRAME.w
  const out = document.createElement('canvas'); out.width = FRAME.w; out.height = FRAME.h
  const g = out.getContext('2d', { willReadFrequently: true })
  // Only show counters that happen in this chat, so the grid has no dead zeros.
  const shown = COUNTERS.filter(c => plan.totals[c.cat]).slice(0, 6)
  const counts = Object.fromEntries(COUNTERS.map(c => [c.cat, 0])), bumped = {}
  let ei = 0, ci = 0
  step(1 / 60)
  for (let f = 0; f < plan.frames; f++) {
    const target = (f * plan.speed) / plan.fps
    while (ei < plan.events.length && plan.events[ei].at <= target) handle(plan.events[ei++].msg)
    while (ci < plan.counters.length && plan.counters[ci].at <= target) { const c = plan.counters[ci++].cat; counts[c]++; bumped[c] = f }
    let guard = 0
    while (target - now() > 1e-6 && guard++ < 100) step(Math.min(1 / 30, target - now()))
    render()
    draw(g, { plan, f, target, tall, FRAME, BAND, canvas, shown, counts, bumped })
    const img = g.getImageData(0, 0, FRAME.w, FRAME.h)
    await ipcRenderer.invoke('frame', img.data)
  }
  await ipcRenderer.invoke('done')
}

function realTimeAt(plan, sim) {
  const { sim: S, real: R } = plan.clock
  if (sim <= S[0]) return R[0]
  for (let i = 1; i < S.length; i++) if (S[i] >= sim) {
    const k = S[i] === S[i - 1] ? 1 : (sim - S[i - 1]) / (S[i] - S[i - 1])
    return R[i - 1] + k * (R[i] - R[i - 1])
  }
  return R[R.length - 1]
}

function text(g, s, x, y, size, color, weight = 600, align = 'left', font = FONT) {
  g.font = `${weight} ${size}px ${font}`; g.fillStyle = color; g.textAlign = align; g.textBaseline = 'alphabetic'; g.fillText(s, x, y)
}

function draw(g, { plan, f, target, tall, FRAME, BAND, canvas, shown, counts, bumped }) {
  const { w, h } = FRAME
  // Background: deep blue-black with a warm glow behind the workshop
  const bg = g.createLinearGradient(0, 0, 0, h); bg.addColorStop(0, '#0a0c11'); bg.addColorStop(1, '#141824')
  g.fillStyle = bg; g.fillRect(0, 0, w, h)
  const cx = w / 2, cy = BAND.y + BAND.h * 0.62
  const glow = g.createRadialGradient(cx, cy, 10, cx, cy, w * 0.62)
  glow.addColorStop(0, 'rgba(232,116,59,0.16)'); glow.addColorStop(1, 'rgba(232,116,59,0)')
  g.fillStyle = glow; g.fillRect(0, 0, w, h)
  g.drawImage(canvas, BAND.x, BAND.y, BAND.w, BAND.h)

  const real = new Date(realTimeAt(plan, target))
  const time = real.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })
  const day = real.toLocaleDateString([], { weekday: 'short' })
  const clock = plan.multiDay ? `${day} ${time}` : time
  const progress = f / (plan.frames - 1)

  if (tall) {
    text(g, 'WORKSHOP TIME-LAPSE', 80, 230, 34, ACCENT, 700)
    const lines = wrapText(g, plan.title, 80, 320, w - 160, 84, INK, 800)
    text(g, plan.subtitle, 80, 320 + lines * 94 - 10, 48, MUTED, 600)
    // Clock pill above the workshop
    g.font = `700 50px ${ROUNDED}`
    const cw = g.measureText(clock).width + 120
    g.fillStyle = 'rgba(255,244,228,0.08)'; g.beginPath(); g.roundRect(80, BAND.y - 20, cw, 84, 42); g.fill()
    text(g, '🕒', 108, BAND.y + 39, 38, INK, 400)
    text(g, clock, 162, BAND.y + 40, 50, INK, 700, 'left', ROUNDED)
    bar(g, 80, BAND.y + BAND.h + 24, w - 160, 8, progress)
    // Counters, two columns
    const top = BAND.y + BAND.h + 140, colW = (w - 160) / 2, rowH = 165
    shown.forEach((c, i) => counter(g, c, 80 + (i % 2) * colW, top + Math.floor(i / 2) * rowH, counts, bumped, f, 96))
  } else {
    text(g, 'WORKSHOP TIME-LAPSE', 70, 70, 26, ACCENT, 700)
    text(g, plan.title, 70, 135, 60, INK, 800)
    g.font = `800 60px ${FONT}`; const tw = g.measureText(plan.title).width
    text(g, plan.subtitle, 70 + tw + 22, 135, 40, MUTED, 600)
    text(g, clock, w - 70, 125, 56, INK, 700, 'right', ROUNDED)
    bar(g, 70, BAND.y + BAND.h - 6, w - 140, 6, progress)
    const colW = (w - 140) / Math.max(1, shown.length)
    shown.forEach((c, i) => counter(g, c, 70 + i * colW, BAND.y + BAND.h + 70, counts, bumped, f, 64))
  }
  // Short fade at the start and the end
  const fade = Math.max(0, 1 - f / 8, (f - (plan.frames - 12)) / 12)
  if (fade > 0) { g.fillStyle = `rgba(6,7,10,${Math.min(1, fade)})`; g.fillRect(0, 0, w, h) }
}

function counter(g, c, x, y, counts, bumped, f, size) {
  const pop = bumped[c.cat] !== undefined ? Math.max(0, 1 - (f - bumped[c.cat]) / 6) : 0
  text(g, c.icon, x, y, size * 0.62, INK, 400)
  const n = counts[c.cat].toLocaleString()
  g.save(); g.translate(x + size * 0.82, y); g.scale(1 + pop * 0.08, 1 + pop * 0.08)
  text(g, n, 0, 0, size, pop > 0 ? '#ffd9a8' : INK, 800, 'left', ROUNDED)
  g.restore()
  text(g, c.label, x + size * 0.82, y + size * 0.48, size * 0.34, MUTED, 600)
}

function bar(g, x, y, w, h, k) {
  g.fillStyle = 'rgba(255,244,228,0.12)'; g.beginPath(); g.roundRect(x, y, w, h, h / 2); g.fill()
  g.fillStyle = ACCENT; g.beginPath(); g.roundRect(x, y, Math.max(h, w * k), h, h / 2); g.fill()
}

function wrapText(g, s, x, y, maxW, size, color, weight) {
  g.font = `${weight} ${size}px ${FONT}`
  const words = s.split(' '), lines = []
  let line = ''
  for (const word of words) { const t = line ? `${line} ${word}` : word; if (g.measureText(t).width > maxW && line) { lines.push(line); line = word } else line = t }
  lines.push(line)
  lines.slice(0, 2).forEach((l, i) => text(g, l, x, y + i * size * 1.12, size, color, weight))
  return Math.min(2, lines.length)
}
