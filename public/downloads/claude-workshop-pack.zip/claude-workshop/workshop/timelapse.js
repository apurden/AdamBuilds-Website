// Workshop time-lapse: replays one Claude Code chat through the workshop and saves MP4s.
//   electron timelapse.js [--chat <file or id>] [--whole | --hours N] [--seconds 25] [--formats tall,wide] [--out <folder>]
// With no --chat it uses the chat Claude worked in most recently. Prints "saved <path>" for each file.
const { app, BrowserWindow, ipcMain } = require('electron')
const { spawn } = require('child_process')
const fs = require('fs')
const path = require('path')
const os = require('os')
const { buildPlan, resolveChat } = require('./timeline')

const argv = process.argv.slice(process.argv.findIndex(a => a.endsWith('timelapse.js')) + 1)
const arg = (name, def) => { const i = argv.indexOf(`--${name}`); return i >= 0 ? argv[i + 1] : def }
const flag = name => argv.includes(`--${name}`)
// Mac keeps videos in Movies; Windows and Linux in Videos.
const OUT = arg('out', path.join(os.homedir(), process.platform === 'darwin' ? 'Movies' : 'Videos', 'Workshop Time-lapses'))
const FORMATS = arg('formats', 'tall,wide').split(',')
const SIZES = { tall: [1080, 1920], wide: [1920, 1080] }

function findFfmpeg() {
  // The free pack installs ffmpeg-static, which ships a ready ffmpeg for Mac, Windows and Linux.
  try { const p = require('ffmpeg-static'); if (p && fs.existsSync(p)) return p } catch {}
  for (const p of [path.join(os.homedir(), '.local/bin/ffmpeg'), '/opt/homebrew/bin/ffmpeg', '/usr/local/bin/ffmpeg', '/usr/bin/ffmpeg']) if (fs.existsSync(p)) return p
  return 'ffmpeg'
}

const slug = s => String(s || 'chat').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 40)
const stamp = d => { const p = n => String(n).padStart(2, '0'); return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}${p(d.getMinutes())}` }

let plan, current = null
ipcMain.handle('plan', () => plan)
ipcMain.handle('frame', (_e, data) => new Promise(res => {
  const buf = Buffer.from(data.buffer, data.byteOffset, data.byteLength)
  if (current.ff.stdin.write(buf)) res(); else current.ff.stdin.once('drain', res)
}))
ipcMain.handle('done', () => { current.ff.stdin.end() })

function render(format, file) {
  return new Promise((resolve, reject) => {
    const [w, h] = SIZES[format]
    const t0 = Date.now()
    const ff = spawn(findFfmpeg(), ['-y', '-loglevel', 'error', '-f', 'rawvideo', '-pix_fmt', 'rgba', '-s', `${w}x${h}`, '-r', String(plan.fps), '-i', '-',
      '-c:v', 'libx264', '-preset', 'medium', '-crf', '17', '-pix_fmt', 'yuv420p', '-movflags', '+faststart', file], { stdio: ['pipe', 'inherit', 'inherit'] })
    const win = new BrowserWindow({ show: false, width: w, height: h, webPreferences: { nodeIntegration: true, contextIsolation: false, backgroundThrottling: false } })
    current = { ff, win }
    win.webContents.on('console-message', (_e, _l, m) => { if (process.env.WORKSHOP_DEBUG) console.log('[page]', m) })
    win.webContents.on('render-process-gone', (_e, d) => reject(new Error(`renderer stopped: ${d.reason}`)))
    ff.on('close', code => {
      win.destroy()
      if (code === 0) { console.log(`saved ${file} (${((Date.now() - t0) / 1000).toFixed(0)} s to make)`); resolve(file) }
      else reject(new Error(`ffmpeg exited with ${code}`))
    })
    win.loadFile(path.join(__dirname, 'index.html'), { query: { replay: format } })
  })
}

app.whenReady().then(async () => {
  if (app.dock) app.dock.hide()
  try {
    const chat = resolveChat(arg('chat'))
    if (!chat) throw new Error('Could not find that chat.')
    plan = await buildPlan(chat, { whole: flag('whole'), hours: Number(arg('hours', 0)) || 0, seconds: Number(arg('seconds', 25)), title: arg('title'), subtitle: arg('subtitle') })
    console.log(`chat: ${plan.chat || path.basename(chat)} | ${plan.title} | ${new Date(plan.from).toLocaleString()} to ${new Date(plan.to).toLocaleString()}`)
    fs.mkdirSync(OUT, { recursive: true })
    const base = path.join(OUT, `${stamp(new Date(plan.to))} ${slug(plan.chat)}`)
    for (const f of FORMATS) await render(f, `${base} ${f === 'tall' ? 'short' : 'wide'}.mp4`)
    app.exit(0)
  } catch (e) {
    console.error('time-lapse failed:', e.message)
    app.exit(1)
  }
})
app.on('window-all-closed', () => {})
