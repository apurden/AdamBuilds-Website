// Badges: counts what Claude has done across every chat on this Mac and writes
// ~/.claude/living-workshop/badges.json, which the badges mod shows above the prompt.
// Only tool names, timestamps and background-job start/finish markers are read.
// It keeps a cache, so after the first full read it only reads what is new.
const fs = require('fs')
const path = require('path')
const { stationFor, home } = require('./shared')

const PROJECTS = path.join(home, '.claude', 'projects')
const DIR = path.join(home, '.claude', 'living-workshop')
const CACHE = path.join(DIR, 'stats-cache.json')
const OUT = path.join(DIR, 'badges.json')
const TIMELAPSES = path.join(home, 'Movies', 'Workshop Time-lapses')
const CHUNK = 64 * 1024 * 1024

const BADGES = [
  { id: 'read-1k', icon: '📖', name: 'Bookworm', desc: '1,000 files read', goal: 1000, value: s => s.totals.read },
  { id: 'read-5k', icon: '🗂️', name: 'Archivist', desc: '5,000 files read', goal: 5000, value: s => s.totals.read },
  { id: 'read-10k', icon: '📚', name: 'Library card', desc: '10,000 files read', goal: 10000, value: s => s.totals.read },
  { id: 'edit-100', icon: '✏️', name: 'First drafts', desc: '100 edits', goal: 100, value: s => s.totals.write },
  { id: 'edit-1k', icon: '🖋️', name: 'Ink-stained', desc: '1,000 edits', goal: 1000, value: s => s.totals.write },
  { id: 'edit-5k', icon: '📝', name: 'Rewrite king', desc: '5,000 edits', goal: 5000, value: s => s.totals.write },
  { id: 'run-1k', icon: '⚙️', name: 'Machine operator', desc: '1,000 commands run', goal: 1000, value: s => s.totals.run },
  { id: 'run-10k', icon: '🏭', name: 'Factory floor', desc: '10,000 commands run', goal: 10000, value: s => s.totals.run },
  { id: 'run-25k', icon: '🚀', name: 'Power plant', desc: '25,000 commands run', goal: 25000, value: s => s.totals.run },
  { id: 'web-100', icon: '🔭', name: 'Stargazer', desc: '100 web lookups', goal: 100, value: s => s.totals.web },
  { id: 'web-1k', icon: '🌌', name: 'Astronomer', desc: '1,000 web lookups', goal: 1000, value: s => s.totals.web },
  { id: 'web-10k', icon: '🛰️', name: 'Mission control', desc: '10,000 web lookups', goal: 10000, value: s => s.totals.web },
  { id: 'jobs-day', icon: '👷', name: 'Crew boss', desc: '10 background jobs in one day', goal: 10, value: s => maxDay(s, 'job') },
  { id: 'jobs-day-25', icon: '🦺', name: 'Site manager', desc: '25 background jobs in one day', goal: 25, value: s => maxDay(s, 'job') },
  { id: 'jobs-4', icon: '🏗️', name: 'Full crew', desc: '4 background jobs at once', goal: 4, value: s => s.maxConcurrent },
  { id: 'job-hour', icon: '⏳', name: 'Long haul', desc: 'A background job that ran over an hour', goal: 60, value: s => Math.floor(s.longestJobMs / 60000) },
  { id: 'helpers-25', icon: '🤝', name: 'Team player', desc: '25 helpers sent out', goal: 25, value: s => s.totals.helper },
  { id: 'helpers-100', icon: '🎪', name: 'Ringmaster', desc: '100 helpers sent out', goal: 100, value: s => s.totals.helper },
  { id: 'marathon', icon: '🏃', name: 'Marathon', desc: '1,000 tool calls in one chat', goal: 1000, value: s => maxChat(s) },
  { id: 'ultra', icon: '🏔️', name: 'Ultramarathon', desc: '5,000 tool calls in one chat', goal: 5000, value: s => maxChat(s) },
  { id: 'busy-day', icon: '⚡', name: 'Busy day', desc: '500 tool calls in one day', goal: 500, value: s => maxDay(s, 'tools') },
  { id: 'whirlwind', icon: '🌪️', name: 'Whirlwind', desc: '1,500 tool calls in one day', goal: 1500, value: s => maxDay(s, 'tools') },
  { id: 'night', icon: '🌙', name: 'Night shift', desc: 'Claude worked between midnight and 4 a.m.', goal: 1, value: s => (s.night ? 1 : 0) },
  { id: 'early', icon: '🌅', name: 'Early bird', desc: 'Claude worked between 4 and 6 a.m.', goal: 1, value: s => (s.early ? 1 : 0) },
  { id: 'streak-7', icon: '🔥', name: 'On a roll', desc: 'Claude every day for 7 days', goal: 7, value: s => streak(s) },
  { id: 'streak-30', icon: '🗓️', name: 'Habit', desc: 'Claude every day for 30 days', goal: 30, value: s => streak(s) },
  { id: 'streak-100', icon: '💯', name: 'Century', desc: 'Claude every day for 100 days', goal: 100, value: s => streak(s) },
  { id: 'prompts-1k', icon: '💬', name: 'Regular', desc: '1,000 prompts sent', goal: 1000, value: s => s.totals.prompt },
  { id: 'prompts-5k', icon: '🗣️', name: 'Old friends', desc: '5,000 prompts sent', goal: 5000, value: s => s.totals.prompt },
  { id: 'timelapse', icon: '🎬', name: 'Director', desc: 'Made a workshop time-lapse', goal: 1, value: s => s.timelapses },
  { id: 'timelapse-10', icon: '🎞️', name: 'Film festival', desc: 'Made 10 workshop time-lapses', goal: 10, value: s => s.timelapses },
]

const maxChat = s => Math.max(0, ...Object.values(s.files).map(f => f.tools))
const maxDay = (s, k) => Math.max(0, ...Object.values(s.days).map(d => d[k] || 0))
function streak(s) {
  const days = Object.keys(s.days).sort()
  let best = 0, run = 0, prev = null
  for (const d of days) {
    const t = Date.parse(`${d}T12:00:00`)
    run = prev !== null && Math.round((t - prev) / 86400000) === 1 ? run + 1 : 1
    best = Math.max(best, run); prev = t
  }
  return best
}
const dayKey = t => { const d = new Date(t), p = n => String(n).padStart(2, '0'); return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}` }

function load() {
  try { const c = JSON.parse(fs.readFileSync(CACHE, 'utf8')); if (c.version === 1) return c } catch {}
  return { version: 1, files: {}, ids: {}, totals: { read: 0, write: 0, run: 0, web: 0, job: 0, helper: 0, prompt: 0, tools: 0 }, days: {}, maxConcurrent: 0, longestJobMs: 0, night: false, early: false, timelapses: 0 }
}

function count(s, t, k) {
  s.totals[k] = (s.totals[k] || 0) + 1
  const d = (s.days[dayKey(t)] ||= {}); d[k] = (d[k] || 0) + 1
}

function onLine(s, f, l) {
  const isA = l.includes('"type":"assistant"'), isU = l.includes('"type":"user"')
  const isDone = l.includes('<tool-use-id>') && (l.includes('"queue-operation"') || l.includes('"type":"attachment"'))
  if (!isA && !isU && !isDone) return
  let r
  try { r = JSON.parse(l) } catch { return }
  if (r.isSidechain || !r.timestamp) return
  const t = Date.parse(r.timestamp)
  const content = r.message && r.message.content
  if (r.type === 'queue-operation' || r.type === 'attachment') {
    const text = r.content || (r.attachment && r.attachment.prompt) || ''
    const m = typeof text === 'string' && text.match(/<tool-use-id>([^<]+)<\/tool-use-id>/)
    if (m && f.open[m[1]] !== undefined) {
      s.longestJobMs = Math.max(s.longestJobMs, t - f.open[m[1]])
      delete f.open[m[1]]
    }
    return
  }
  if (r.type === 'user' && !(r.origin && r.origin.kind === 'task-notification') && r.uuid && !s.ids[r.uuid]) {
    if (typeof content === 'string' || (Array.isArray(content) && content.some(b => b.type === 'text'))) { s.ids[r.uuid] = 1; count(s, t, 'prompt') }
  }
  if (r.type === 'assistant' && Array.isArray(content)) {
    const h = new Date(t).getHours()
    if (h < 4) s.night = true; else if (h < 6) s.early = true
    for (const b of content) {
      if (b.type !== 'tool_use' || s.ids[b.id]) continue
      s.ids[b.id] = 1; f.tools++
      count(s, t, 'tools')
      const input = b.input || {}
      if (input.run_in_background) {
        count(s, t, 'job'); f.open[b.id] = t
        // A job left open for a day never got a finish line (Claude was closed), so it stops counting
        for (const [id, st] of Object.entries(f.open)) if (t - st > 86400000) delete f.open[id]
        s.maxConcurrent = Math.max(s.maxConcurrent, Object.keys(f.open).length)
      } else if (b.name === 'Agent') count(s, t, 'helper')
      else { const st = stationFor(b.name); if (st) count(s, t, st) }
    }
  }
}

function readFile(s, file) {
  let st
  try { st = fs.statSync(file) } catch { return false }
  const f = (s.files[file] ||= { offset: 0, tools: 0, open: {} })
  if (st.size < f.offset) Object.assign(f, { offset: 0 }) // the log was replaced; its tool ids are already counted
  if (st.size === f.offset) return false
  const fd = fs.openSync(file, 'r')
  let pos = f.offset, carry = Buffer.alloc(0)
  while (pos < st.size) {
    const len = Math.min(CHUNK, st.size - pos), buf = Buffer.alloc(len)
    fs.readSync(fd, buf, 0, len, pos); pos += len
    // Split on whole lines in bytes, so a character cut at a chunk edge is never broken
    const all = carry.length ? Buffer.concat([carry, buf]) : buf, cut = all.lastIndexOf(10)
    if (cut < 0) { carry = all; continue }
    for (const l of all.subarray(0, cut).toString('utf8').split('\n')) onLine(s, f, l)
    carry = all.subarray(cut + 1)
  }
  fs.closeSync(fd)
  f.offset = st.size - carry.length // an unfinished last line is read next time
  return true
}

function run() {
  const s = load()
  let changed = false
  for (const d of fs.existsSync(PROJECTS) ? fs.readdirSync(PROJECTS) : []) {
    let names = []
    try { names = fs.readdirSync(path.join(PROJECTS, d)) } catch { continue }
    for (const n of names) if (n.endsWith('.jsonl') && readFile(s, path.join(PROJECTS, d, n))) changed = true
  }
  try { s.timelapses = fs.readdirSync(TIMELAPSES).filter(n => n.endsWith('.mp4')).length } catch { s.timelapses = 0 }
  fs.mkdirSync(DIR, { recursive: true })
  if (changed) fs.writeFileSync(CACHE, JSON.stringify(s))

  // Badges keep the time they were first earned; ones earned before the first count are marked old.
  let before = null
  try { before = JSON.parse(fs.readFileSync(OUT, 'utf8')) } catch {}
  const prev = Object.fromEntries(((before && before.badges) || []).map(b => [b.id, b]))
  const now = Date.now()
  const badges = BADGES.map(b => {
    const value = b.value(s), earned = value >= b.goal
    const p = prev[b.id]
    return { id: b.id, icon: b.icon, name: b.name, desc: b.desc, goal: b.goal, value: Math.min(value, b.goal), earned,
      earnedAt: earned ? (p && p.earnedAt) || now : null, old: earned ? (p ? !!p.old : !before) : false }
  })
  const out = { updated: now, totals: s.totals, badges }
  const text = JSON.stringify(out, null, 1)
  const same = before && JSON.stringify({ ...before, updated: 0 }) === JSON.stringify({ ...out, updated: 0 })
  if (!same) fs.writeFileSync(OUT, text)
  return out
}

module.exports = { run, BADGES }
if (require.main === module) {
  const t0 = Date.now(), out = run()
  console.log(`badges: ${out.badges.filter(b => b.earned).length} of ${out.badges.length} earned in ${((Date.now() - t0) / 1000).toFixed(1)} s`, JSON.stringify(out.totals))
  if (process.argv.includes('--list')) for (const b of out.badges) console.log(b.earned ? '✔' : ' ', b.icon, b.name, `${b.value}/${b.goal}`)
}
