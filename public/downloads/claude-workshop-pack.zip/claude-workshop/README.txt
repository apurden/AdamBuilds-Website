CLAUDE WORKSHOP PACK (free from Adam Builds, adambuilds.io/workshop)

What's inside:
- The workshop: a little 3D workshop along the bottom of your screen. A worker acts out what Claude Code is doing, and helpers run in for background jobs. It has a one-click time-lapse.
- The usage bar: how full your chat is, your 5-hour limit and your week, right above the chat box.
- The badges: 31 badges for what Claude does for you, plus /badges.

Install it in one sentence:
1. Leave this folder (claude-workshop) in your Downloads folder.
2. Open the Claude desktop app, go to the Code tab, start a new chat and paste:
   Install the Claude Workshop pack from the claude-workshop folder in my Downloads: the workshop, the usage bar and the badges.

Claude reads the files first, then sets everything up on your computer. You need Node 18 or newer; if you don't have it, Claude will offer to help.

To remove it, tell Claude: Remove the Claude Workshop pack.

Privacy: it reads only the names of Claude's actions and the short labels on background jobs, never your conversation. Nothing is sent anywhere.
