---
name: claude-workshop
description: Install, use and remove the Claude Workshop pack from Adam Builds. It has three parts. First, a tiny 3D workshop window along the bottom of the screen, where a worker acts out what Claude Code is doing (reading, writing, thinking, web, commands, resting) and helpers run in for background jobs. Second, a usage bar above the chat box (context, 5-hour and weekly use). Third, 31 badges. Use this skill when the user asks to install or set up the workshop, the usage bar or the badges; to make a time-lapse of a chat; to show the workshop or explain what the worker is doing; to fix the workshop not showing; or to remove or uninstall any of it.
---

# Claude Workshop pack

Free from Adam Builds (adambuilds.io/workshop). There are three parts:
- **The workshop:** a see-through window that sits along the bottom of the screen and acts out what Claude Code is doing.
- **The usage bar:** a mod above the chat box.
- **The badges:** a mod with a `/badges` command.

Everything runs on the user's own computer.

**Before running anything,** read `scripts/install.mjs` (or `uninstall.mjs`) yourself. Tell the user in one or two plain sentences what it will do. It never sends data anywhere.

## Install (when the user says "install the workshop" or similar)

1. **Find the pack folder.** It's the folder that contains this `SKILL.md`, usually `~/Downloads/claude-workshop`. If it isn't there, ask the user where they unzipped it.
2. **Check Node:** run `node -v`. The installer needs Node 18 or newer, because the workshop is a small Electron app.
   - **If Node is missing or old,** explain that in plain words and offer to install the LTS version.
   - **On a Mac with Homebrew:** `brew install node`.
   - **On Windows:** `winget install OpenJS.NodeJS.LTS`.
   - **Otherwise,** the user downloads the LTS installer from nodejs.org.
   - **Ask before installing it.**
3. **Run the installer:** `node "<pack>/scripts/install.mjs"`.
   - **What it does:** copies the app to a fixed folder (Mac: `~/Library/Application Support/Claude Workshop`; Windows: `%APPDATA%\Claude Workshop`; Linux: `~/.local/share/claude-workshop`), downloads about 200 MB of parts with npm, starts the workshop at login and right now, and adds the two mods through `claude plugin` commands.
   - **If the user already has a usage bar,** it skips ours, so two don't stack.
4. **Install this skill for later:** copy the pack folder to `~/.claude/skills/claude-workshop`, so "make a time-lapse" and "remove the workshop" work in any chat.
5. **Tell the user what to expect**, in plain words:
   - The workshop appears along the bottom of the screen and follows Claude Code chats, the Code tab. It doesn't follow chats in a web browser.
   - It fades away after five quiet minutes and comes back on the next prompt.
   - The usage bar and badges show in new chats; in an open chat, type `/reload-plugins`.
   - The first badges unlock from past chats.
   - **The tray icon:** on a Mac, a 🔧 in the menu bar; on Windows or Linux, a small orange wrench in the tray. It holds the time-lapse and the other options.

## Reading the workshop

| Where the worker is | What Claude is doing |
|---|---|
| The desk with the stack of books | reading files |
| The desk under the lamp | writing or editing |
| The rug, with a thought bubble | thinking |
| The telescope | searching the web |
| The machine with blinking lights | running a command |
| Sitting by the stove, maybe asleep | done, waiting on the user |

**Helpers** that run in carrying a sign are background jobs. There are up to three at once, and each sign names its job. When a job ends, its helper runs back and wakes the worker.

## Make a time-lapse

- **From the tray:** the tray icon → Make a time-lapse → pick a chat. About a minute later, two 25-second MP4s open: one tall for Shorts and one wide, with a clock and counters. They're saved in Movies (Mac) or Videos (Windows, Linux) → `Workshop Time-lapses`.
- **From a chat:** run `"<electron>" "<app>/timelapse.js" --chat "<path to the chat's .jsonl>"`, where:
  - `<app>` is the installed `workshop` folder,
  - `<electron>` is the Electron binary inside its `node_modules` (`node -e "console.log(require('<app>/node_modules/electron'))"` prints it),
  - the chat logs are in `~/.claude/projects/<project>/`, and the newest `.jsonl` is the current chat.
- **Options:** add `--whole` for the whole chat (the default is the latest stretch of work).
- **The Director badge** unlocks on the first one.

## Badges

- Type `/badges` for the full list, `/badges show` to keep a badge row above the prompt, and `/badges hide` to remove it.
- The workshop counts once a minute and writes `~/.claude/living-workshop/badges.json`. The mod only reads that file.

## Not showing?

- **Is it running?**
  - **Mac:** `launchctl print gui/$(id -u)/io.adambuilds.claude-workshop`. The log is `~/Library/Logs/claude-workshop.log`.
  - **Windows and Linux:** look for the tray icon.
- **The tray menu** has "Show now" and "Always show (for recording)".
- **It's tied to Claude Code chats from the last 10 minutes.** Start a Code-tab chat and send a prompt.
- **To restart it,** run the installer again. It updates the copy and restarts.

## Remove (when the user says "remove", "uninstall" or "turn off the workshop")

Run `node "<pack>/scripts/uninstall.mjs"`.
- **It removes:** the workshop, its login item, the two mods and the badge counts.
- **It leaves alone:** chats, Claude settings and time-lapse videos.
- **Then** delete `~/.claude/skills/claude-workshop` if the user wants the skill gone too.

## Privacy, in plain words

- **What it reads:** only the names of Claude's actions (like "read a file" or "run a command"), the time they happened, and the short label on each background job. Labels have file paths and the account's surname stripped out.
- **What it never reads:** the conversation.
- **It never sends anything anywhere,** and it changes none of the user's Claude settings.
