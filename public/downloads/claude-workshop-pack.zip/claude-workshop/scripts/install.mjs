#!/usr/bin/env node
// Claude Workshop pack installer (Mac, Windows, Linux). No extra packages needed: plain Node 18+.
// What it does, in order:
//   1. copies the workshop app and the usage bar mod to a fixed folder for this computer,
//   2. downloads the workshop's parts with npm (Electron, three.js, ffmpeg-static; about 200 MB),
//   3. makes the workshop start when you log in, and starts it now,
//   4. adds the usage bar mod to Claude Code (skips it if you already have a usage bar).
// Flags: --no-start (don't start or register autostart), --no-mods (don't touch Claude Code), --test (both, for a dry install).
import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'
import { spawn, spawnSync } from 'node:child_process'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'

const args = new Set(process.argv.slice(2))
const TEST = args.has('--test')
const NO_START = TEST || args.has('--no-start')
const NO_MODS = TEST || args.has('--no-mods')
const PACK = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const HOME = os.homedir()
const OS = process.platform
const say = s => console.log(`• ${s}`)
const fail = (s, code = 1) => { console.error(`✗ ${s}`); process.exit(code) }

const DEST = OS === 'darwin' ? path.join(HOME, 'Library', 'Application Support', 'Claude Workshop')
  : OS === 'win32' ? path.join(process.env.APPDATA || path.join(HOME, 'AppData', 'Roaming'), 'Claude Workshop')
  : path.join(process.env.XDG_DATA_HOME || path.join(HOME, '.local', 'share'), 'claude-workshop')
const APP = path.join(DEST, 'workshop')
const MODS = path.join(DEST, 'mods')

// 1. Node version
if (Number(process.versions.node.split('.')[0]) < 18) fail(`Node 18 or newer is needed (this computer has ${process.version}).`, 2)

// 2. Copy the app and the mods (a fresh copy each time, so re-running updates it)
fs.mkdirSync(DEST, { recursive: true })
for (const d of ['workshop', 'mods']) {
  fs.rmSync(path.join(DEST, d), { recursive: true, force: true })
  fs.cpSync(path.join(PACK, d), path.join(DEST, d), { recursive: true })
}
say(`Copied the workshop to ${DEST}`)

// 3. Download the parts
say('Downloading the workshop parts (about 200 MB, one time)…')
const npm = OS === 'win32' ? 'npm.cmd' : 'npm'
const r = spawnSync(npm, ['install', '--omit=dev', '--no-audit', '--no-fund', '--loglevel=error'], { cwd: APP, stdio: 'inherit', shell: OS === 'win32' })
if (r.status !== 0) fail('npm install failed. Check the internet connection and run the installer again.', 3)
let ELECTRON
try { ELECTRON = createRequire(path.join(APP, 'package.json'))('electron') } catch { fail('Electron did not install.', 3) }
if (!fs.existsSync(ELECTRON)) fail(`Electron is missing at ${ELECTRON}.`, 3)
say('Parts downloaded')

// 4. Start at login, and start now
if (NO_START) say('Skipped autostart and start (--no-start / --test)')
else if (OS === 'darwin') {
  const LABEL = 'io.adambuilds.claude-workshop'
  const plist = path.join(HOME, 'Library', 'LaunchAgents', `${LABEL}.plist`)
  const log = path.join(HOME, 'Library', 'Logs', 'claude-workshop.log')
  fs.mkdirSync(path.dirname(plist), { recursive: true }); fs.mkdirSync(path.dirname(log), { recursive: true })
  const x = s => s.replace(/&/g, '&amp;').replace(/</g, '&lt;')
  fs.writeFileSync(plist, `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key><string>${LABEL}</string>
  <key>ProgramArguments</key><array><string>${x(ELECTRON)}</string><string>${x(APP)}</string></array>
  <key>WorkingDirectory</key><string>${x(APP)}</string>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><dict><key>SuccessfulExit</key><false/></dict>
  <key>ProcessType</key><string>Interactive</string>
  <key>LimitLoadToSessionType</key><string>Aqua</string>
  <key>StandardOutPath</key><string>${x(log)}</string>
  <key>StandardErrorPath</key><string>${x(log)}</string>
</dict>
</plist>
`)
  const uid = process.getuid()
  spawnSync('launchctl', ['bootout', `gui/${uid}/${LABEL}`])
  for (let i = 0; i < 20 && spawnSync('launchctl', ['print', `gui/${uid}/${LABEL}`]).status === 0; i++) spawnSync('sleep', ['0.5'])
  const b = spawnSync('launchctl', ['bootstrap', `gui/${uid}`, plist], { encoding: 'utf8' })
  if (b.status !== 0) fail(`Could not start it: ${b.stderr}`, 4)
  say('It starts now and every time you log in')
} else {
  if (OS === 'win32') {
    const startup = path.join(process.env.APPDATA || path.join(HOME, 'AppData', 'Roaming'), 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup')
    fs.mkdirSync(startup, { recursive: true })
    // A tiny script in the Startup folder runs the workshop at login with no console window.
    fs.writeFileSync(path.join(startup, 'Claude Workshop.vbs'), `CreateObject("WScript.Shell").Run """${ELECTRON}"" ""${APP}""", 0, False\r\n`)
  } else {
    const dir = path.join(process.env.XDG_CONFIG_HOME || path.join(HOME, '.config'), 'autostart')
    fs.mkdirSync(dir, { recursive: true })
    fs.writeFileSync(path.join(dir, 'claude-workshop.desktop'), `[Desktop Entry]\nType=Application\nName=Claude Workshop\nExec="${ELECTRON}" "${APP}"\nX-GNOME-Autostart-enabled=true\n`)
  }
  spawn(ELECTRON, [APP], { cwd: APP, detached: true, stdio: 'ignore' }).unref()
  say('It starts now and every time you log in (if an older copy is open, quit it from its tray icon first)')
}

// 5. The usage bar mod through Claude Code's own plugin commands
function findClaude() {
  const tries = []
  if (OS === 'darwin') {
    const base = path.join(HOME, 'Library', 'Application Support', 'Claude', 'claude-code')
    try {
      for (const a of fs.readdirSync(base)) for (const b of fs.readdirSync(path.join(base, a))) {
        const p = path.join(base, a, b, 'claude.app', 'Contents', 'MacOS', 'claude'); if (fs.existsSync(p)) tries.push(p)
      }
    } catch {}
    tries.sort((p, q) => p.localeCompare(q, undefined, { numeric: true })).reverse()
  }
  if (OS === 'win32') {
    for (const base of [process.env.LOCALAPPDATA, process.env.APPDATA].filter(Boolean)) {
      const walk = (d, depth) => { if (depth > 5) return; let es = []; try { es = fs.readdirSync(d, { withFileTypes: true }) } catch { return }
        for (const e of es) { const p = path.join(d, e.name); if (e.isFile() && e.name.toLowerCase() === 'claude.exe' && /claude-code/i.test(p)) tries.push(p); else if (e.isDirectory() && /claude|anthropic|code|\d/i.test(e.name)) walk(p, depth + 1) } }
      walk(base, 0)
    }
  }
  tries.push('claude')
  for (const c of tries) { const v = spawnSync(c, ['--version'], { encoding: 'utf8', shell: OS === 'win32' && c === 'claude' }); if (v.status === 0) return c }
  return null
}
if (NO_MODS) say('Skipped the mods (--no-mods / --test)')
else {
  const claude = findClaude()
  if (!claude) say('Could not find Claude Code from here, so the usage bar was not added. Ask Claude to run: claude plugin marketplace add "' + MODS + '", then install usage-bar from it.')
  else {
    const run = (...a) => spawnSync(claude, a, { cwd: os.tmpdir(), encoding: 'utf8', shell: OS === 'win32' && claude === 'claude' })
    const list = run('plugin', 'list').stdout || ''
    if (run('plugin', 'marketplace', 'add', MODS).status !== 0) run('plugin', 'marketplace', 'update', 'claude-workshop-mods')
    const otherBar = /usage-bar@(?!claude-workshop-mods)/.test(list)
    if (otherBar) say('You already have a usage bar installed, so this one was skipped (two would stack).')
    else run('plugin', 'install', 'usage-bar@claude-workshop-mods')
    if (!otherBar) say('Added the usage bar. New chats show it; in an open chat, type /reload-plugins')
  }
}

console.log(`\nDone. The workshop follows your Claude Code chats (the Code tab) and sits along the bottom of your screen.`)
console.log(`Time-lapses are saved in ${path.join(HOME, OS === 'darwin' ? 'Movies' : 'Videos', 'Workshop Time-lapses')}.`)
