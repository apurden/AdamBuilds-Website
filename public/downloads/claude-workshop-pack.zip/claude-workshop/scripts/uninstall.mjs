#!/usr/bin/env node
// Flags: --no-mods / --test leave Claude Code's plugins alone.
// Removes the Claude Workshop pack: stops the workshop, removes its autostart, its folder, the usage bar mod and its saved data.
// (It also removes the badges mod that an earlier version of the pack added, if it is there.)
// Your chats, your Claude settings and your time-lapse videos are left alone.
import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'
import { spawnSync } from 'node:child_process'

const NO_MODS = process.argv.includes('--no-mods') || process.argv.includes('--test')
const HOME = os.homedir()
const OS = process.platform
const say = s => console.log(`• ${s}`)
const DEST = OS === 'darwin' ? path.join(HOME, 'Library', 'Application Support', 'Claude Workshop')
  : OS === 'win32' ? path.join(process.env.APPDATA || path.join(HOME, 'AppData', 'Roaming'), 'Claude Workshop')
  : path.join(process.env.XDG_DATA_HOME || path.join(HOME, '.local', 'share'), 'claude-workshop')

if (OS === 'darwin') {
  const LABEL = 'io.adambuilds.claude-workshop'
  spawnSync('launchctl', ['bootout', `gui/${process.getuid()}/${LABEL}`])
  fs.rmSync(path.join(HOME, 'Library', 'LaunchAgents', `${LABEL}.plist`), { force: true })
  say('Stopped the workshop and removed it from login')
} else if (OS === 'win32') {
  fs.rmSync(path.join(process.env.APPDATA || path.join(HOME, 'AppData', 'Roaming'), 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup', 'Claude Workshop.vbs'), { force: true })
  say('Removed it from login. If the workshop is still on screen, right-click its tray icon and choose Quit')
} else {
  fs.rmSync(path.join(process.env.XDG_CONFIG_HOME || path.join(HOME, '.config'), 'autostart', 'claude-workshop.desktop'), { force: true })
  say('Removed it from login. If the workshop is still on screen, choose Quit from its tray icon')
}

// The mods, through Claude Code's plugin commands (the installer explains how it finds Claude Code)
const tries = ['claude']
if (OS === 'darwin') {
  const base = path.join(HOME, 'Library', 'Application Support', 'Claude', 'claude-code')
  try { for (const a of fs.readdirSync(base)) for (const b of fs.readdirSync(path.join(base, a))) { const p = path.join(base, a, b, 'claude.app', 'Contents', 'MacOS', 'claude'); if (fs.existsSync(p)) tries.unshift(p) } } catch {}
}
const claude = NO_MODS ? null : tries.find(c => spawnSync(c, ['--version'], { shell: OS === 'win32' && c === 'claude' }).status === 0)
if (claude) {
  const run = (...a) => spawnSync(claude, a, { cwd: os.tmpdir(), shell: OS === 'win32' && claude === 'claude' })
  run('plugin', 'uninstall', 'usage-bar@claude-workshop-mods')
  run('plugin', 'uninstall', 'workshop-badges@claude-workshop-mods')
  run('plugin', 'marketplace', 'remove', 'claude-workshop-mods')
  say('Removed the usage bar mod')
} else say(NO_MODS ? 'Skipped the mods (--no-mods / --test)' : 'Could not find Claude Code from here: ask Claude to uninstall usage-bar from claude-workshop-mods')

fs.rmSync(DEST, { recursive: true, force: true })
fs.rmSync(path.join(HOME, '.claude', 'living-workshop'), { recursive: true, force: true })
say('Removed the workshop folder and its saved data')
console.log('\nDone. Your chats, settings and time-lapse videos were not touched.')
