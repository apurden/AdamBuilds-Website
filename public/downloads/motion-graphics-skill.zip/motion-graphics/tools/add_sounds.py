"""Adds motion sounds to a rendered MP4 using the free sounds in ../sounds (only Python 3 and ffmpeg needed).

sounds.json is a list of cues, one per sound, with times in seconds on the video's timeline:
  [[0.40, "whoosh", 1.0], [1.20, "pop", 0.8], [2.00, "key", 0.6], ...]
Roles: key, tick, pop, click, swipe, hit, boom, ding, chime, whoosh, riser (see ../sounds/kit.json).
Each cue picks a different take of its sound, so repeated pops and keys don't sound robotic.

Usage: python3 tools/add_sounds.py renders/intro.mp4 sounds.json renders/intro_sound.mp4 [--level -20]
--level is the loudness of the sounds alone in LUFS: -20 is clearly audible on a phone and still sits under a voice.
If the video already has audio (a voice), it is kept at its own level and the sounds go underneath it."""
import argparse, glob, json, os, random, re, subprocess, tempfile

HERE = os.path.dirname(os.path.abspath(__file__)); SOUNDS = os.path.join(HERE, '..', 'sounds')
ap = argparse.ArgumentParser(); ap.add_argument('video'); ap.add_argument('cues'); ap.add_argument('out')
ap.add_argument('--level', type=float, default=-20.0); a = ap.parse_args()

def run(cmd): return subprocess.run(cmd, capture_output=True, text=True)
def lufs(path):
    err = run(['ffmpeg', '-hide_banner', '-nostats', '-i', path, '-af', 'ebur128', '-f', 'null', '-']).stderr
    return float(re.findall(r'I:\s+(-?[\d.]+) LUFS', err)[-1])
def has_audio(path):
    return bool(run(['ffprobe', '-v', 'error', '-select_streams', 'a', '-show_entries', 'stream=index', '-of', 'csv=p=0', path]).stdout.strip())
dur = float(run(['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', a.video]).stdout)

cues = json.load(open(a.cues)); rng = random.Random(7); last = {}; inputs, chains = [], []
for t, role, gain in sorted(cues):
    takes = sorted(glob.glob(os.path.join(SOUNDS, role, '*.wav')))
    if not takes: raise SystemExit('unknown sound role: %s (see sounds/kit.json)' % role)
    k = rng.randrange(len(takes))
    if len(takes) > 1 and k == last.get(role): k = (k + 1) % len(takes)
    last[role] = k; n = len(inputs); inputs += ['-i', takes[k]]
    ms = max(0, int(round((t + (rng.uniform(-0.012, 0.012) if role == 'key' else 0)) * 1000)))
    vol = gain * 10 ** (rng.uniform(-2, 2) / 20)
    chains.append('[%d:a]aformat=sample_rates=48000:channel_layouts=stereo,volume=%.3f,adelay=%d|%d[s%d]' % (n // 2, vol, ms, ms, n // 2))
with tempfile.TemporaryDirectory() as tmp:
    raw = os.path.join(tmp, 'sounds_raw.wav'); bed = os.path.join(tmp, 'sounds.wav')
    graph = ';'.join(chains) + ';' + ''.join('[s%d]' % i for i in range(len(chains))) + \
        'amix=inputs=%d:normalize=0:duration=longest,apad,atrim=0:%.3f[out]' % (len(chains), dur)
    script = os.path.join(tmp, 'graph.txt'); open(script, 'w').write(graph)
    r = run(['ffmpeg', '-y', '-hide_banner', *inputs, '-filter_complex_script', script, '-map', '[out]', raw])
    if r.returncode: raise SystemExit(r.stderr[-2000:])
    gain_db = a.level - lufs(raw)  # set the sounds to the target loudness, then catch stray peaks at -1.5 dBFS
    run(['ffmpeg', '-y', '-hide_banner', '-i', raw, '-af', 'volume=%.2fdB,alimiter=limit=0.84:level=false' % gain_db, bed])
    if has_audio(a.video):  # keep the voice as it is and lay the sounds under it
        mix = ['-filter_complex', '[0:a]aformat=sample_rates=48000:channel_layouts=stereo[v];[v][1:a]amix=inputs=2:normalize=0:duration=first,alimiter=limit=0.89:level=false[a]', '-map', '0:v', '-map', '[a]']
    else:
        mix = ['-map', '0:v', '-map', '1:a']
    r = run(['ffmpeg', '-y', '-hide_banner', '-i', a.video, '-i', bed, *mix, '-c:v', 'copy', '-c:a', 'aac', '-b:a', '192k', '-ar', '48000', '-shortest', '-movflags', '+faststart', a.out])
    if r.returncode: raise SystemExit(r.stderr[-2000:])
print('%d sounds added -> %s (sounds at %.0f LUFS; whole file %.1f LUFS)' % (len(cues), a.out, a.level, lufs(a.out)))
