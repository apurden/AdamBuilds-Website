"""Turn frames + Apple Vision person masks into the two layers the "text behind you" scene stacks:
   bg/b_NNN.jpg  the full original frame (bottom layer)
   cut/c_NNN.png just the person, cropped to the union box of all masks, alpha = mask (top layer)
Title text goes between the two layers, so it reads as if it sits behind the person.
Usage: python3 cutout_compose.py FRAMES_DIR MASKS_DIR OUT_DIR [--feather 1.2] [--choke 1]
Writes OUT_DIR/box.json with the crop box (x, y, w, h in source pixels) the page needs to place the cut layer.
Edge limits (seen on Adam's footage): hair and fast-moving hands get a soft or late edge; motion blur on hands can
leave a faint halo; anything the person holds may be cut off. Keep text away from moving hands and use a short clip."""
import sys, os, json
import numpy as np
from PIL import Image, ImageFilter
fr, mk, out = sys.argv[1:4]
feather = float(sys.argv[sys.argv.index('--feather') + 1]) if '--feather' in sys.argv else 1.2
choke = int(sys.argv[sys.argv.index('--choke') + 1]) if '--choke' in sys.argv else 1
os.makedirs(out + '/bg', exist_ok=True); os.makedirs(out + '/cut', exist_ok=True)
files = sorted(f for f in os.listdir(fr) if f.endswith('.png'))
masks = []
for f in files:
    m = Image.open(os.path.join(mk, f)).convert('L')
    if choke: m = m.filter(ImageFilter.MinFilter(2 * choke + 1))      # pull the edge in a little to drop background fringe
    if feather: m = m.filter(ImageFilter.GaussianBlur(feather))
    masks.append(m)
union = np.zeros(np.asarray(masks[0]).shape, bool)
for m in masks: union |= np.asarray(m) > 16
ys, xs = np.where(union); pad = 12
x0, y0 = max(0, xs.min() - pad), max(0, ys.min() - pad); x1, y1 = min(union.shape[1], xs.max() + pad), min(union.shape[0], ys.max() + pad)
for i, (f, m) in enumerate(zip(files, masks)):
    im = Image.open(os.path.join(fr, f)).convert('RGB')
    im.save('%s/bg/b_%03d.jpg' % (out, i), quality=90)
    rgba = im.copy(); rgba.putalpha(m); rgba.crop((x0, y0, x1, y1)).save('%s/cut/c_%03d.png' % (out, i), optimize=True)
json.dump({'x': int(x0), 'y': int(y0), 'w': int(x1 - x0), 'h': int(y1 - y0), 'frames': len(files), 'src_w': union.shape[1], 'src_h': union.shape[0]}, open(out + '/box.json', 'w'))
print('frames', len(files), 'box', x0, y0, x1 - x0, y1 - y0)
