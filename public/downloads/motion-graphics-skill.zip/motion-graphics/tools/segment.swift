// Person masks for every frame in a folder, using Apple Vision (on-device).
import Foundation
import Vision
import CoreImage
import ImageIO
import UniformTypeIdentifiers
let args = CommandLine.arguments
let inDir = URL(fileURLWithPath: args[1]), outDir = URL(fileURLWithPath: args[2])
let ctx = CIContext()
let files = try FileManager.default.contentsOfDirectory(atPath: inDir.path).filter { $0.hasSuffix(".png") }.sorted()
for f in files {
  let req = VNGeneratePersonSegmentationRequest()
  req.qualityLevel = .accurate
  req.outputPixelFormat = kCVPixelFormatType_OneComponent8
  let h = VNImageRequestHandler(url: inDir.appendingPathComponent(f))
  try h.perform([req])
  guard let buf = req.results?.first?.pixelBuffer else { print("no mask", f); continue }
  var m = CIImage(cvPixelBuffer: buf)
  let src = CIImage(contentsOf: inDir.appendingPathComponent(f))!
  m = m.transformed(by: CGAffineTransform(scaleX: src.extent.width / m.extent.width, y: src.extent.height / m.extent.height))
  let cg = ctx.createCGImage(m, from: src.extent)!
  let dst = CGImageDestinationCreateWithURL(outDir.appendingPathComponent(f) as CFURL, UTType.png.identifier as CFString, 1, nil)!
  CGImageDestinationAddImage(dst, cg, nil); CGImageDestinationFinalize(dst)
}
print("masks:", files.count)
