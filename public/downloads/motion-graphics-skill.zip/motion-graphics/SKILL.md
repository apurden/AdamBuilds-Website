---
name: motion-graphics
description: Make polished motion graphics and short animated videos (title intros, animated charts, stat cards, how-it-works diagrams, quote cards, 3D card carousels, gallery walls, titles behind a person in real footage) as real MP4 files, with optional real motion sounds, by writing HTML and GSAP animation code and rendering it with HyperFrames. Use when the user asks for motion graphics, an animated intro, an animated chart, a kinetic-text clip, or "make this move" and wants an MP4 they can drop into a video editor.
---

# Motion graphics with Claude Code

You build motion graphics as a small web page (HTML + CSS + GSAP) and render it to an MP4 with HyperFrames. No design app and no Team plan needed.

## Before you start
1. Ask for: the one-sentence idea, length in seconds (default 8), size (default 1920x1080, 30 fps), and any brand colors. If they give none, use the Aurora style below.
2. Make a new empty folder for the project. Never write into a folder that holds other work.
3. Check that Node.js and ffmpeg are installed (`node -v`, `ffmpeg -version`). If one is missing, install it yourself rather than sending the user to a website: on a Mac use `brew install node ffmpeg` if Homebrew is present; on Windows use `winget install OpenJS.NodeJS.LTS` and `winget install Gyan.FFmpeg`. If neither package manager is available, or an install asks for a password, explain in one sentence what you need and let the user type the password themselves. Never type a password for them. Check both commands again before going on.

## Project layout
```
my-motion/
  index.html        the animation (exactly one root HTML file)
  hyperframes.json  {"paths":{"blocks":"compositions","components":"compositions/components","assets":"assets"}}
  meta.json         {"id":"my-motion","name":"my-motion"}
  recipes.js        reusable scene builders (copy from this skill folder)
  renders/          output MP4 files
```

## How the page must be written
- The root element: `<div id="root" data-composition-id="main" data-start="0" data-duration="8" data-width="1920" data-height="1080">`.
- Load GSAP from `https://cdn.jsdelivr.net/npm/gsap@3.14.2/dist/gsap.min.js`.
- Build ONE paused GSAP timeline: `const tl = gsap.timeline({paused:true})`, then at the end `window.__timelines = {main: tl}`.
- Everything must be driven by the timeline (tweens and `tl.set`). No `setTimeout`, no callbacks, no `Math.random()`, no CSS animations: the renderer jumps to any moment, so every frame must be reproducible.
- Counters step through pre-made text layers (see `recipes.js`) instead of using `onUpdate`.

## Aurora style (the default look)
- Background `#030408`, text `#f4f6fb`, one accent teal `#35e0cf`, amber `#ffd23c` only for numbers.
- A slow-turning colored glow behind a dark rounded panel inset 20 px. Interior must stay darker than the glow.
- Headlines: system sans, weight 800 to 900. No outlined fonts.
- Motion: rise 24 to 40 px with `power3.out` over 0.45 to 0.6 s, pops with `back.out(1.7)`. Something changes every 3 to 6 seconds; nothing sits still longer than 6 s.
- Only one accent color per scene. Never scale up from zero (start at 0.82 to 0.94 with opacity).

## Recipes in recipes.js
`RC.kinetic` (big words slam in, one accent word, optional underline that draws in), `RC.chart` (line draws with a counter), `RC.pipe` (steps connected by traveling dots), `RC.plan` (a prompt and a task list that ticks), `RC.razor` (a cut flash), `RC.carousel` (3D cards on a ring, one step at a time), `RC.wall` (a tilted wall of playing clips that pushes into one), `RC.behind` (a title between a footage frame and the person cut out of it). Read the top of `recipes.js` and each recipe's comment for its options. Copy `recipes.js` into the project and paste it into a `<script>` in `index.html` before your own code (one root HTML file).

## Title behind a person in real footage (Mac only)
Use a short, complete spoken line (2 to 5 seconds), never a clip that starts or ends mid-sentence.
1. Frames: `ffmpeg -ss START -t SECONDS -i clip.mov -vf fps=30 work/frames/f_%03d.png`, and the audio: `ffmpeg -ss START -t SECONDS -i clip.mov -vn work/clip_audio.wav`.
2. Person masks on this Mac with Apple Vision (on-device): `swift tools/segment.swift work/frames work/masks`.
3. Layers: `python3 tools/cutout_compose.py work/frames work/masks assets/foot` (needs Pillow and NumPy). It writes the background frames, the cut-out person cropped to one box, and `box.json`.
4. `RC.behind` with that box and your words. Mix `clip_audio.wav` into the final video at the scene start.
Edge limits: hair and fast hands get soft edges, a faint fringe can stay beside glasses, motion blur leaves a halo, held objects may be cut off. Keep words away from hands and look at every 10th frame before rendering.

## Motion sounds (real recorded sounds included)
`sounds/` holds free sounds you may use anywhere, including monetised videos. Every role has several takes, and `sounds/LICENSES.md` says where each came from (CC0 public domain, or made by us):
- `key`: a real keyboard
- `tick` and `click`: UI clicks
- `pop`, `ding` and `chime`
- `hit`: a soft thud
- `boom`: a low boom to layer under a hit
- `swipe`: real air swishes
- `whoosh`: for scene changes
- `riser`: a build before a reveal

1. After the final render, write `sounds.json` with one cue per sound, using the same times as the timeline: `[[0.4,"whoosh",1.0],[1.2,"pop",0.8],[2.0,"key",0.6]]`.
2. Run `python3 tools/add_sounds.py renders/final.mp4 sounds.json renders/final_sound.mp4`. It needs only Python 3 and ffmpeg.
3. Keep the sounds sparse:
   - a whoosh on scene changes
   - one pop per group of things appearing, not one per item
   - a hit or boom only on the big reveal
   - keys about every 0.1 s while text types
   Around 20 to 30 sounds a minute is plenty. More turns into clutter under a voice.
4. The sounds alone come out at -20 LUFS: clearly audible on a phone, and still under a voice. If the video already has a voice track, it is kept and the sounds go underneath.
5. Check the result has sound: `ffmpeg -i renders/final_sound.mp4 -af ebur128 -f null -` should show an integrated loudness (I:) between -22 and -14 LUFS. Never hand over a silent or near-silent file.

## Steps
1. Write `index.html` for the idea.
2. Lint: `npx --yes hyperframes@0.8.184 lint` (must show 0 errors).
3. Look at it before the full render: render a short draft, then pull frames with `ffmpeg -ss 2.5 -i renders/draft.mp4 -frames:v 1 frame.png` and LOOK at them. Check text is not cut off, not overlapping, readable at phone size.
4. Fix, then final render: `npx --yes hyperframes@0.8.184 render --workers 1 --output renders/final.mp4`.
5. If the user wants sound, add it (see Motion sounds).
6. Tell the user the file path, length, size and what each scene shows. If anything looks wrong, say so.

## Honesty rules
- Never invent data. If you use placeholder numbers, label them "Sample data" on screen. Label made-up businesses, websites and widgets as examples ("Example widget · not real weather").
- Do not claim it works in places you did not test.
- Free disk space matters: renders write temporary frames. Check there are at least 4 GB free before a long render.
