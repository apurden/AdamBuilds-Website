/* Adam Builds Aurora recipes: reusable scene builders for the HyperFrames template (template_v5.html includes this file at __RECIPES__).
   Every recipe takes the GSAP timeline `tl`, a parent scene element (1766x924 scene coordinates), and an options object, and only uses timeline tweens and sets
   (no callbacks), so seeking stays exact. Styles follow systems/styles/adam-builds-aurora/STYLE.md. Show only real data in these.
   RC.pipe   packets travel along wires between one-word cards (how a process works)
   RC.chart  a line draws segment by segment with a rider dot, ring pulses and a stepped count-up (real numbers over time)
   RC.plan   a prompt bubble and a task list whose rows spin, then tick (Claude's real plan)
   RC.kinetic big words slam in one by one, one accent word (hooks, verdicts, Shorts)
   RC.razor  a cut flash on a timeline (trims)
   RC.carousel 3D cards on a ring that turns one card at a time, each with a label (a short roadmap of real steps)
   RC.wall   a tilted wall of playing clips that cascades in, then pushes into one tile (hook: "all of these were made by...")
   RC.behind title text between a footage frame and a person cut out of it, stepped one frame at a time (needs cut-out frames)
   Units: carousel, wall and behind take explicit sizes and centres, so they work in any scene size (1766x924 or the 1880x1040 panel).
*/
const RC = (function () {
  const NS = 'http://www.w3.org/2000/svg', TEAL = '#35e0cf', AMBER = '#ffd23c', INK = '#f4f6fb', MUT = '#8a93a6', PANEL = '#0b0d13', LINE = 'rgba(255,255,255,.14)';
  function el(tag, css, html, parent) { const e = document.createElement(tag); if (css) e.style.cssText = css; if (html != null) e.innerHTML = html; parent.appendChild(e); return e; }
  function svg(parent, w, h) { const s = document.createElementNS(NS, 'svg'); s.setAttribute('viewBox', '0 0 ' + w + ' ' + h); s.style.cssText = 'position:absolute;left:0;top:0;width:' + w + 'px;height:' + h + 'px;overflow:visible'; parent.appendChild(s); return s; }
  function sn(tag, attrs, parent) { const e = document.createElementNS(NS, tag); for (const k in attrs) e.setAttribute(k, attrs[k]); parent.appendChild(e); return e; }
  function rise(tl, e, t, o) { o = o || {}; gsap.set(e, { opacity: 0 }); tl.fromTo(e, { opacity: 0, y: o.y == null ? 40 : o.y, scale: o.s || .92 }, { opacity: 1, y: 0, scale: 1, duration: o.d || .55, ease: o.e || 'power3.out', immediateRender: false }, t); }
  function steps(tl, host, t, d, from, to, fmt) { // stepped count-up inside `host` (no callbacks)
    const n = 16; host.textContent = ''; const f = fmt || (v => Math.round(v)); let last = null;
    for (let i = 0; i <= n; i++) {
      const p = 1 - Math.pow(1 - i / n, 2.4); const s = document.createElement('span'); s.textContent = f(from + (to - from) * p);
      s.style.cssText = 'position:absolute;left:0;top:0;opacity:0;white-space:nowrap'; host.appendChild(s); tl.set(s, { opacity: 1 }, t + d * i / n); if (i < n) tl.set(s, { opacity: 0 }, t + d * (i + 1) / n); last = s;
    }
    const g = document.createElement('span'); g.textContent = f(to); g.style.visibility = 'hidden'; host.appendChild(g);
  }

  /* ---- PIPE: {nodes:[{label,sub}], t0, hop:1.0, y:330, cardW:300, cardH:150, gap:110, font:46, loop:{from,to,label,at}} ---- */
  function pipe(tl, parent, o) {
    const n = o.nodes.length, cw = o.cardW || 300, ch = o.cardH || 150, gap = o.gap || 110, hop = o.hop || 1.0, y0 = o.y || 330;
    const W = n * cw + (n - 1) * gap, x0 = o.x != null ? o.x : (1766 - W) / 2;
    const root = el('div', 'position:absolute;left:0;top:0;width:1766px;height:924px', null, parent), s = svg(root, 1766, 924);
    const cards = o.nodes.map((nd, i) => {
      const c = el('div', 'position:absolute;left:' + (x0 + i * (cw + gap)) + 'px;top:' + y0 + 'px;width:' + cw + 'px;height:' + ch + 'px;border-radius:30px;background:' + PANEL + ';border:1px solid ' + LINE + ';box-shadow:0 24px 60px rgba(0,0,0,.6);display:flex;flex-direction:column;align-items:center;justify-content:center;font-weight:900;font-size:' + (o.font || 46) + 'px;color:' + INK + ';opacity:0;z-index:2',
        nd.label + (nd.sub ? '<div style="font-size:24px;font-weight:600;color:' + MUT + ';margin-top:8px">' + nd.sub + '</div>' : ''), root);
      rise(tl, c, o.t0 + i * .22, { y: -50 }); return c;
    });
    const ts = o.t0 + n * .22 + .35, cy = y0 + ch / 2, arrive = [];
    for (let i = 0; i < n - 1; i++) {
      const xa = x0 + i * (cw + gap) + cw, xb = xa + gap, st = ts + i * hop;
      sn('line', { x1: xa, y1: cy, x2: xb, y2: cy, stroke: '#2a3140', 'stroke-width': 5, 'stroke-linecap': 'round' }, s);
      const lit = sn('line', { x1: xa, y1: cy, x2: xb, y2: cy, stroke: TEAL, 'stroke-width': 5, 'stroke-linecap': 'round', 'stroke-dasharray': gap, 'stroke-dashoffset': gap }, s);
      tl.fromTo(lit, { strokeDashoffset: gap }, { strokeDashoffset: 0, duration: .4, ease: 'power2.inOut', immediateRender: false }, st);
      [[0, 11, 1], [.07, 7, .4]].forEach(p => { const c = sn('circle', { cx: xa, cy: cy, r: p[1], fill: TEAL, opacity: 0 }, s);
        tl.set(c, { opacity: p[2] }, st + .3 + p[0]); tl.fromTo(c, { attr: { cx: xa } }, { attr: { cx: xb }, duration: .5, ease: 'power2.inOut', immediateRender: false }, st + .3 + p[0]); tl.set(c, { opacity: 0 }, st + .82 + p[0]); });
      tl.to(cards[i + 1], { scale: 1.035, borderColor: TEAL, boxShadow: '0 0 40px rgba(53,224,207,.5)', duration: .12, ease: 'power2.out' }, st + .82).to(cards[i + 1], { scale: 1, duration: .5, ease: 'back.out(3)' }, st + .94);
      arrive.push(st + .82);
    }
    if (o.loop) { // a "Fix" note travelling back under the cards
      const a = o.loop.from, b = o.loop.to, xa = x0 + a * (cw + gap) + cw / 2, xb = x0 + b * (cw + gap) + cw / 2, yb = y0 + ch, dy = 110, st = o.loop.at != null ? o.loop.at : ts + (n - 1) * hop + .3;
      const d = 'M' + xa + ',' + yb + ' C' + xa + ',' + (yb + dy) + ' ' + xb + ',' + (yb + dy) + ' ' + xb + ',' + yb, len = Math.abs(xa - xb) * 1.25 + dy;
      const p = sn('path', { d: d, fill: 'none', stroke: AMBER, 'stroke-width': 5, 'stroke-linecap': 'round', 'stroke-dasharray': len, 'stroke-dashoffset': len }, s);
      tl.fromTo(p, { strokeDashoffset: len }, { strokeDashoffset: 0, duration: .9, ease: 'power2.inOut', immediateRender: false }, st);
      const tag = el('div', 'position:absolute;left:' + ((xa + xb) / 2 - 60) + 'px;top:' + (yb + dy + 14) + 'px;width:120px;text-align:center;font-size:30px;font-weight:800;color:#021613;background:' + AMBER + ';border-radius:12px;padding:6px 0;opacity:0', o.loop.label || 'Fix', root); rise(tl, tag, st + .6, { y: 14, d: .4 });
    }
    return { root, cards, arrive };
  }

  /* ---- CHART: {title, x:200,y:260,w:1300,h:520, pts:[[x,y]...] (0..1 each), t0, dur:3, ticks:['Day 1',...], from, to, fmt, unit, marks:[{i:pointIndex,label}], color} ---- */
  function chart(tl, parent, o) {
    const X = o.x == null ? 200 : o.x, Y = o.y == null ? 260 : o.y, Wd = o.w || 1300, Ht = o.h || 520, dur = o.dur || 3, col = o.color || TEAL;
    const root = el('div', 'position:absolute;left:0;top:0;width:1766px;height:924px', null, parent), s = svg(root, 1766, 924);
    if (o.title) { const t = el('div', 'position:absolute;left:' + X + 'px;top:' + (Y - 120) + 'px;font-size:62px;font-weight:900;color:' + INK + ';letter-spacing:-1px;opacity:0', o.title, root); rise(tl, t, o.t0, { y: 24, d: .5 }); }
    for (let g = 0; g <= 3; g++) { const yy = Y + Ht - g * Ht / 3, ln = sn('line', { x1: X, y1: yy, x2: X + Wd, y2: yy, stroke: g ? 'rgba(255,255,255,.10)' : 'rgba(255,255,255,.35)', 'stroke-width': g ? 2 : 3, 'stroke-dasharray': Wd, 'stroke-dashoffset': Wd }, s);
      tl.fromTo(ln, { strokeDashoffset: Wd }, { strokeDashoffset: 0, duration: .7, ease: 'expo.out', immediateRender: false }, o.t0 + .1 + g * .07); }
    (o.ticks || []).forEach((tk, i, a) => { const lb = el('div', 'position:absolute;left:' + (X + i * Wd / Math.max(a.length - 1, 1) - 60) + 'px;top:' + (Y + Ht + 16) + 'px;width:120px;text-align:center;font-size:26px;font-weight:600;color:' + MUT + ';opacity:0', tk, root); rise(tl, lb, o.t0 + .5 + i * .06, { y: 10, d: .4 }); });
    const P = o.pts.map(p => [X + p[0] * Wd, Y + Ht - p[1] * Ht]); const L = []; let tot = 0;
    for (let i = 0; i < P.length - 1; i++) { const l = Math.hypot(P[i + 1][0] - P[i][0], P[i + 1][1] - P[i][1]); L.push(l); tot += l; }
    const dot = sn('circle', { cx: P[0][0], cy: P[0][1], r: 13, fill: col, opacity: 0 }, s), t1 = o.t0 + 1.0; tl.set(dot, { opacity: 1 }, t1);
    let tc = t1; const hit = [];
    for (let i = 0; i < P.length - 1; i++) {
      const dt = dur * L[i] / tot, seg = sn('line', { x1: P[i][0], y1: P[i][1], x2: P[i + 1][0], y2: P[i + 1][1], stroke: col, 'stroke-width': 8, 'stroke-linecap': 'round', 'stroke-dasharray': L[i] + 1, 'stroke-dashoffset': L[i] + 1 }, s);
      tl.fromTo(seg, { strokeDashoffset: L[i] + 1 }, { strokeDashoffset: 0, duration: dt, ease: 'none', immediateRender: false }, tc);
      tl.fromTo(dot, { attr: { cx: P[i][0], cy: P[i][1] } }, { attr: { cx: P[i + 1][0], cy: P[i + 1][1] }, duration: dt, ease: 'none', immediateRender: false }, tc);
      tc += dt; hit[i + 1] = tc;
    }
    (o.marks || []).forEach(m => { const p = P[m.i], t = hit[m.i] != null ? hit[m.i] : t1;
      const ring = sn('circle', { cx: p[0], cy: p[1], r: 14, fill: 'none', stroke: col, 'stroke-width': 4, opacity: 0 }, s);
      tl.fromTo(ring, { attr: { r: 14 }, opacity: .9 }, { attr: { r: 52 }, opacity: 0, duration: .7, ease: 'power2.out', immediateRender: false }, t);
      if (m.label) { const lb = el('div', 'position:absolute;left:' + (p[0] + 24) + 'px;top:' + (p[1] - 70) + 'px;font-size:34px;font-weight:800;color:' + INK + ';background:' + PANEL + ';border:1px solid ' + LINE + ';border-radius:14px;padding:8px 18px;opacity:0;white-space:nowrap', m.label, root); rise(tl, lb, t + .1, { y: 12, d: .4 }); } });
    if (o.to != null) { const host = el('div', 'position:absolute;left:' + (X + Wd - 360) + 'px;top:' + (Y - 130) + 'px;width:360px;height:130px;text-align:right;font-size:120px;font-weight:900;line-height:1;color:' + (o.numColor || AMBER) + ';direction:rtl', '', root);
      const inner = el('div', 'position:absolute;right:0;top:0;direction:ltr;text-align:right;width:360px;height:130px', '', host); steps(tl, inner, t1, dur, o.from || 0, o.to, o.fmt);
      if (o.unit) { const u = el('div', 'position:absolute;left:' + (X + Wd - 360) + 'px;top:' + (Y - 6) + 'px;width:360px;text-align:right;font-size:28px;font-weight:600;color:' + MUT + ';opacity:0', o.unit, root); rise(tl, u, t1 + .3, { y: 8, d: .4 }); } }
    return { root, end: tc };
  }

  /* ---- PLAN: {prompt, rows:['step',...], t0, step:.9, x:330, y:150, w:1100} ---- */
  function plan(tl, parent, o) {
    const x = o.x == null ? 330 : o.x, y = o.y == null ? 150 : o.y, w = o.w || 1100, step = o.step || .9;
    const root = el('div', 'position:absolute;left:0;top:0;width:1766px;height:924px', null, parent);
    if (o.prompt) { const b = el('div', 'position:absolute;left:' + x + 'px;top:' + y + 'px;width:' + w + 'px;padding:26px 34px;border-radius:30px 30px 30px 8px;background:#1d2433;border:1px solid ' + LINE + ';font-size:40px;font-weight:700;line-height:1.25;color:' + INK + ';opacity:0', o.prompt, root); rise(tl, b, o.t0, { y: 30 }); }
    const y1 = y + (o.prompt ? 190 : 0), rows = [];
    o.rows.forEach((txt, i) => {
      const r = el('div', 'position:absolute;left:' + x + 'px;top:' + (y1 + i * 84) + 'px;width:' + w + 'px;height:68px;border-radius:18px;background:' + PANEL + ';border:1px solid ' + LINE + ';display:flex;align-items:center;gap:22px;padding:0 24px;font-size:34px;font-weight:700;color:' + INK + ';opacity:0', '', root);
      const ic = el('div', 'position:relative;width:38px;height:38px;flex:none', '', r);
      const sp = el('div', 'position:absolute;inset:0;border-radius:50%;border:5px solid rgba(53,224,207,.25);border-top-color:' + TEAL, '', ic);
      const ck = el('div', 'position:absolute;inset:0;border-radius:50%;background:' + TEAL + ';color:#021613;font-size:26px;font-weight:900;display:flex;align-items:center;justify-content:center;opacity:0', '&#10003;', ic);
      el('div', 'flex:1', txt, r);
      const t = o.t0 + .6 + i * step; rise(tl, r, t, { y: 20, d: .4 });
      tl.fromTo(sp, { rotation: 0 }, { rotation: 720, duration: step * .85, ease: 'none', immediateRender: false }, t + .2);
      tl.set(sp, { opacity: 0 }, t + .2 + step * .85); tl.fromTo(ck, { opacity: 0, scale: .3 }, { opacity: 1, scale: 1, duration: .4, ease: 'back.out(2.6)', immediateRender: false }, t + .2 + step * .85);
      tl.to(r, { borderColor: 'rgba(53,224,207,.5)', duration: .3 }, t + .2 + step * .85); rows.push(r);
    });
    return { root, end: o.t0 + .6 + o.rows.length * step + .5 };
  }

  /* ---- KINETIC: {words:['THAT'S','NOT','ME'], accent:1, t0, size:170, x:230, y:300, stagger:.18, width:1300} ---- */
  function kinetic(tl, parent, o) {
    const size = o.size || 170, rootWidth = o.width || 1300, root = el('div', 'position:absolute;left:' + (o.x == null ? 230 : o.x) + 'px;top:' + (o.y == null ? 300 : o.y) + 'px;width:' + rootWidth + 'px;display:flex;flex-wrap:wrap;gap:0 ' + Math.round(size * .28) + 'px;line-height:1.02', null, parent);
    o.words.forEach((w, i) => {
      const box = el('div', 'overflow:hidden;padding-bottom:' + Math.round(size * .12) + 'px', '', root), t = el('div', 'font-size:' + size + 'px;font-weight:900;letter-spacing:-' + Math.round(size * .02) + 'px;color:' + (i === o.accent ? TEAL : INK), w, box);
      gsap.set(t, { y: size * 1.1 }); tl.fromTo(t, { y: size * 1.1 }, { y: 0, duration: .5, ease: 'power4.out', immediateRender: false }, o.t0 + i * (o.stagger || .18));
    });
    if (o.underline) { const u = el('div', 'height:10px;width:100%;border-radius:5px;background:' + TEAL + ';margin-top:10px;flex-basis:100%;transform:scaleX(0);transform-origin:left center', '', root); tl.fromTo(u, { scaleX: 0 }, { scaleX: o.underline / rootWidth, duration: .6, ease: 'power3.out', immediateRender: false }, o.t0 + o.words.length * (o.stagger || .18) + .1); }
    return { root, end: o.t0 + o.words.length * (o.stagger || .18) + .6 };
  }

  /* ---- RAZOR: {x, y0, y1, t, label} a cut flash on a timeline ---- */
  function razor(tl, parent, o) {
    const ln = el('div', 'position:absolute;left:' + o.x + 'px;top:' + o.y0 + 'px;width:4px;height:' + (o.y1 - o.y0) + 'px;background:#ff6a5c;box-shadow:0 0 24px #ff6a5c;opacity:0;transform-origin:50% 0', '', parent);
    tl.fromTo(ln, { opacity: 1, scaleY: 0 }, { scaleY: 1, duration: .12, ease: 'power2.out', immediateRender: false }, o.t).to(ln, { opacity: 0, duration: .35, ease: 'power1.in' }, o.t + .22);
    if (o.label) { const tg = el('div', 'position:absolute;left:' + (o.x + 14) + 'px;top:' + (o.y0 - 44) + 'px;padding:6px 14px;border-radius:10px;background:#ff6a5c;color:#2a0804;font-size:26px;font-weight:800;opacity:0;white-space:nowrap', o.label, parent); rise(tl, tg, o.t + .1, { y: 10, d: .35 }); }
    return ln;
  }
  /* ---- CAROUSEL: {cards:[{img, label}], t0, step:1.45, cx:883, cy:440, w:800, h:430, angle:38, radius:1250, labelY:800, labelSize:52, fit:'right top', out:true}
     The parent gets perspective; cards sit on a ring (rotateY then translateZ, set directly because the order matters). ---- */
  function carousel(tl, parent, o) {
    const n = o.cards.length, step = o.step || 1.45, ang = o.angle || 38, R = o.radius || 1250, w = o.w || 800, h = o.h || 430;
    parent.style.perspective = (o.perspective || 1900) + 'px';
    const wrap = el('div', 'position:absolute;left:' + (o.cx == null ? 883 : o.cx) + 'px;top:' + (o.cy == null ? 440 : o.cy) + 'px;width:0;height:0;transform-style:preserve-3d', null, parent);
    const ring = el('div', 'position:absolute;left:0;top:0;transform-style:preserve-3d', null, wrap);
    o.cards.forEach((c, i) => {
      const d = el('div', 'position:absolute;left:' + (-w / 2) + 'px;top:' + (-h / 2) + 'px;width:' + w + 'px;height:' + h + 'px;border-radius:26px;overflow:hidden;background:' + PANEL + ';border:2px solid rgba(255,255,255,.10);box-shadow:0 40px 90px rgba(0,0,0,.65);backface-visibility:hidden;transform:rotateY(' + (i * ang) + 'deg) translateZ(' + R + 'px)',
        '<img src="' + c.img + '" style="width:100%;height:100%;object-fit:cover;object-position:' + (o.fit || 'right top') + '"/><div style="position:absolute;inset:0;background:linear-gradient(180deg,rgba(3,4,8,0) 55%,rgba(3,4,8,.55))"></div>' +
        '<div style="position:absolute;left:22px;top:20px;width:64px;height:64px;border-radius:18px;background:' + TEAL + ';color:#03130f;font-size:36px;font-weight:900;display:flex;align-items:center;justify-content:center;box-shadow:0 10px 30px rgba(53,224,207,.45)">' + (i + 1) + '</div>', ring);
    });
    gsap.set(wrap, { rotationX: -7, z: -R, scale: 1.2 });
    tl.fromTo(ring, { rotationY: 60, y: 60 }, { rotationY: 0, y: 0, duration: 1.2, ease: 'power3.out', immediateRender: false }, o.t0 + .15);
    const stops = o.cards.map((c, i) => o.t0 + .4 + i * step), labels = [];
    o.cards.forEach((c, i) => {
      const lb = el('div', 'position:absolute;left:0;right:0;top:' + (o.labelY == null ? 800 : o.labelY) + 'px;text-align:center;font-size:' + (o.labelSize || 52) + 'px;font-weight:900;letter-spacing:-1px;color:' + INK + ';opacity:0', '<span style="color:' + TEAL + '">' + (i + 1) + '</span> · ' + c.label, parent);
      if (i > 0) tl.to(ring, { rotationY: -ang * i, duration: .85, ease: 'power3.inOut' }, stops[i] - .45);
      tl.fromTo(lb, { y: 26, opacity: 0 }, { y: 0, opacity: 1, duration: .4, ease: 'power3.out', immediateRender: false }, stops[i] + .3);
      if (i < n - 1) tl.to(lb, { y: -16, opacity: 0, duration: .25 }, stops[i + 1] - .45);
      labels.push(lb);
    });
    const end = stops[n - 1] + step;
    if (o.out !== false) tl.to(wrap, { scale: 1.7, y: -30, duration: 1, ease: 'power2.in' }, end - .3);
    return { wrap, ring, labels, stops, end };
  }

  /* ---- WALL: {tiles:[{src, ms}], a, b (composition start/end of the clips), cols:3, tileW:560, tileH:315, gap:30, x:70, y:18, focus:index, pushAt}
     Clips are <video class="clip"> elements, so HyperFrames plays them; every tile needs a real render. ---- */
  let wallN = 0;
  function wall(tl, parent, o) {
    const cols = o.cols || 3, tw = o.tileW || 560, th = o.tileH || 315, g = o.gap || 30, rows = Math.ceil(o.tiles.length / cols);
    parent.style.perspective = (o.perspective || 1600) + 'px';
    const W = el('div', 'position:absolute;left:' + (o.x == null ? 70 : o.x) + 'px;top:' + (o.y == null ? 18 : o.y) + 'px;width:' + (cols * tw + (cols - 1) * g) + 'px;height:' + (rows * th + (rows - 1) * g) + 'px;transform-style:preserve-3d;transform-origin:50% 50%', null, parent);
    const tiles = o.tiles.map((t, i) => {
      const d = el('div', 'position:absolute;left:' + (i % cols) * (tw + g) + 'px;top:' + Math.floor(i / cols) * (th + g) + 'px;width:' + tw + 'px;height:' + th + 'px;border-radius:18px;overflow:hidden;background:' + PANEL + ';border:2px solid rgba(255,255,255,.10);box-shadow:0 26px 60px rgba(0,0,0,.6);opacity:0', null, W);
      const v = document.createElement('video'); v.id = 'rcw' + (wallN++); v.className = 'clip'; v.src = t.src; v.muted = true; v.setAttribute('playsinline', '');
      v.setAttribute('data-start', o.a.toFixed(3)); v.setAttribute('data-duration', (o.b - o.a).toFixed(3)); v.setAttribute('data-media-start', (t.ms || 0).toFixed(3));
      v.style.cssText = 'position:absolute;left:0;top:0;width:100%;height:100%;object-fit:cover'; d.appendChild(v); return d;
    });
    const span = o.b - o.a, push = o.pushAt == null ? o.b - 1.3 : o.pushAt;
    tl.fromTo(W, { rotationX: 26, rotationZ: -9, scale: .74, y: 70 }, { rotationX: 12, rotationZ: -4, scale: .86, y: 40, duration: push - o.a, ease: 'sine.inOut', immediateRender: false }, o.a);
    const order = o.order || tiles.map((t, i) => i);
    order.forEach((k, j) => tl.fromTo(tiles[k], { opacity: 0, scale: .86, z: -120 }, { opacity: 1, scale: 1, z: 0, duration: .55, ease: 'back.out(1.6)', immediateRender: false }, o.a + .2 + j * .12));
    if (o.focus != null) tl.to(W, { rotationX: 0, rotationZ: 0, scale: o.pushScale || 2.9, y: 0, duration: Math.min(1.3, o.b - push), ease: 'power3.inOut' }, push);
    return { wall: W, tiles };
  }

  /* ---- BEHIND: {bg:'assets/foot/bg/b_', cut:'assets/foot/cut/c_', frames, fps:30, t0, src:{w:1920,h:1080}, view:{w:1880,h:1040}, box:{x,y,w,h},
     words:[{html, css}] } . Background frame, then the words, then the cut-out person, stepped one picture per video frame so they never drift.
     Make the frames with reel/src/segment.swift (Apple Vision, on-device) and video3/src/cutout_compose.py; see RECIPES.md for the edge limits. ---- */
  function behind(tl, parent, o) {
    const fps = o.fps || 30, sw = o.src ? o.src.w : 1920, sh = o.src ? o.src.h : 1080, vw = o.view ? o.view.w : 1880, vh = o.view ? o.view.h : 1040;
    const k = Math.max(vw / sw, vh / sh), ox = (vw - sw * k) / 2, oy = (vh - sh * k) / 2, pad = n => String(n).padStart(3, '0');
    const fg = el('div', 'position:absolute;left:0;top:0;width:' + vw + 'px;height:' + vh + 'px;transform-origin:50% 40%', null, parent);
    const bgs = el('div', '', null, fg), mid = el('div', 'position:absolute;inset:0', null, fg), cuts = el('div', '', null, fg);
    for (let f = 0; f < o.frames; f++) {
      const b = el('img', 'position:absolute;left:' + ox + 'px;top:' + oy + 'px;width:' + sw * k + 'px;height:' + sh * k + 'px;opacity:0', null, bgs); b.src = o.bg + pad(f) + '.jpg';
      const c = el('img', 'position:absolute;left:' + (ox + o.box.x * k) + 'px;top:' + (oy + o.box.y * k) + 'px;width:' + o.box.w * k + 'px;height:' + o.box.h * k + 'px;opacity:0', null, cuts); c.src = o.cut + pad(f) + '.png';
      tl.set([b, c], { opacity: 1 }, o.t0 + f / fps); if (f < o.frames - 1) tl.set([b, c], { opacity: 0 }, o.t0 + (f + 1) / fps);
    }
    const words = (o.words || []).map((w, i) => {
      const box = el('div', 'position:absolute;font-size:150px;font-weight:900;letter-spacing:-4px;line-height:.92;white-space:nowrap;' + (w.css || ''), '<span style="display:inline-block;overflow:hidden;vertical-align:top;padding:0 6px 12px"><i style="display:inline-block;font-style:normal">' + w.html + '</i></span>', mid);
      tl.fromTo(box.querySelector('i'), { yPercent: 105 }, { yPercent: 0, duration: .55, ease: 'power3.out', immediateRender: false }, o.t0 + .25 + i * .16); return box;
    });
    const len = o.frames / fps;
    tl.fromTo(fg, { scale: 1 }, { scale: 1.06, duration: len, ease: 'none', immediateRender: false }, o.t0);
    tl.fromTo(mid, { x: 0 }, { x: 18, duration: len, ease: 'none', immediateRender: false }, o.t0);
    return { fg, words, end: o.t0 + len };
  }
  return { pipe, chart, plan, kinetic, razor, carousel, wall, behind };
})();
