# Sound library (Adam Builds)

Real recorded sound effects for motion graphics, all free to use in monetised videos and free to give away inside the motion-graphics skill.

- `kit/`: the curated set the videos and the skill use. One folder per role, several takes each. `kit.json` lists every file and where it came from. Rebuild with `~/.cache/adam-builds-video/voice/venv/bin/python assets/sfx-library/build_kit.py`.
- `packs/`: the full downloaded packs (about 400 sounds), kept so we can pick different ones later.
- `_downloads/`: the original zip files.

| Role | What it is | Source | Licence |
|---|---|---|---|
| key | 32 single keypresses, Cherry KC 1000 keyboard, Shure SM7B mic | [Keyboard Soundpack #1](https://opengameart.org/content/keyboard-soundpack-1-typing-and-single-keystrokes) (unicaegames, OpenGameArt) | CC0 |
| tick, click | soft UI clicks, mouse click | [Kenney UI Audio](https://kenney.nl/assets/ui-audio), [Kenney Interface Sounds](https://kenney.nl/assets/interface-sounds) | CC0 |
| pop, ding, chime | drops, selects, confirmation tones | [Kenney Interface Sounds](https://kenney.nl/assets/interface-sounds) | CC0 |
| hit | soft heavy thud | [Kenney Impact Sounds](https://kenney.nl/assets/impact-sounds) | CC0 |
| swipe | the six lightest real swishes (a hanger and sticks swung past a mic) | [Swishes Sound Pack](https://opengameart.org/content/swishes-sound-pack) (OpenGameArt) | CC0 |
| whoosh, riser, boom | scene-change whoosh, build-up, low boom | synthesized by our own `video3/audio/sfx_lib.py` | ours |

CC0 means public domain: no attribution required, commercial use allowed, and we may redistribute the files. Crediting Kenney is optional and appreciated.

Checked Oct 26, 2026 and not used:
- Mixkit has better transition whooshes, but I could not read its sound licence text. Its licences usually forbid giving the files away, so they can't go in the free skill.
- Sonniss GDC bundles are royalty-free but 27 GB or more, and can't be redistributed.
- Freesound needs an account to download.
- Descript's stock sounds are only reachable through Underlord (AI credits) or by clicking through the app.

If we want better whooshes later, Freesound (filtered to CC0, Adam signs in) is the next place to look.
