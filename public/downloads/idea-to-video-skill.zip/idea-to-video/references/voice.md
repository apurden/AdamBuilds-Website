# Voice

The voice comes first. Every scene is then timed to the real spoken words.

## Path A: the user records their own voice
1. Copy `templates/teleprompter.html` into the video folder and paste the spoken text where it says `PASTE SCRIPT HERE`. Open it in a browser: it scrolls the script at an adjustable speed (arrow keys change speed, space pauses).
2. The user reads it aloud into any recorder (phone, laptop, voice memo app) and saves the file as `videos/<name>/voice_raw.<ext>`. Small mistakes are fine: they can repeat a line and keep going.
3. Remove repeated takes: transcribe it (`tools/transcribe_words.py`), compare with `voice.txt`, and cut the earlier take of any repeated line.

## Path B: free text-to-speech
`python3 -m edge_tts --voice en-US-AndrewMultilingualNeural --file voice.txt --write-media voice_raw.mp3`
List voices with `python3 -m edge_tts --list-voices`. Save the chosen voice in `my-preferences.md`. (It needs an internet connection.)

## Path C: a HeyGen avatar
- Use the avatar and look named in `my-setup.md`. Default to **Avatar 3 (V3)** for the whole video: nearly the quality of Avatar 5 for a small fraction of the credits. Avoid Avatar 4 if the user saw a grainy look.
- In HeyGen (through the browser connection): choose the avatar, look and voice, put in the script, 1080p, generate, and download as `voice_raw.mp4`.
- HeyGen's quick "create video" wizard may only offer its newest avatar models. To pick the cheaper lip-sync model, open the full studio editor instead (for example "New revision in AI Studio" on an earlier video, then swap the look and script), and choose the lip-sync mode.
- Pasting the whole script (clipboard, then paste) into the studio script box is reliable; check the pasted text matches `voice.txt` before generating.
- Credit costs change by look and over time. Never put a credit number in the script before the render; read the real cost afterwards, and if a line became untrue, cut it or generate a one-line patch clip with the same avatar and voice and splice it in.
- Log the credits used in `videos/<name>/credits.md`.

## Then, for every path
1. **Tighten:** `python3 tools/tighten_pauses.py voice_raw.<ext>` cuts every pause longer than 0.3 s (picture and sound together for an avatar, so lips stay in sync). Output: `voice_tight.wav` (and `voice_tight.mp4` for an avatar).
2. **Word times:** `python3 tools/transcribe_words.py voice_tight.wav` then `python3 tools/match_script.py voice.txt voice_tight.wav.words.json` writes `script_words.json`: a start and end time for every word of the script. Read the mismatch list it prints: a misheard name is fine; a missing sentence means the voice skipped it.
