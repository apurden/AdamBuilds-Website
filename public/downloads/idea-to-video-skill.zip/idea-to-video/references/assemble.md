# Assemble, sound, captions, checks

1. **Join and mix:** `python3 tools/join_scenes.py sections.json voice_tight.wav final.mp4 [--avatar voice_tight.mp4]`. `sections.json` lists each section id with its start and end time. It joins the scenes on exact frame counts (so the picture never drifts from the voice), lays the voice under them, adds the avatar as a round bubble in the bottom-right corner if given (hidden for any time ranges listed under `"hide"`), and sets the loudness to -14 LUFS with peaks under -1 dB.
2. **Sound effects:** write `sounds.json` with cues at the same times as the animation (`[[time, "whoosh", 1.0], ...]`), then `python3 tools/add_sounds.py final.mp4 sounds.json final_sfx.mp4`. Keep them sparse: a whoosh on scene changes, keys while text types, one pop per group, a hit on the big reveal. About 20 to 30 a minute. No background music bed unless the user asks.
3. **Captions:** `python3 tools/make_srt.py script_words.json final.srt`. Read the whole file: fix product names and numbers, and flag any repeated or missing lines.
4. **Ending:** if the user always adds a closing clip, join it after the body with a hard cut, its own sound at full level.
5. **Checks before handing over:**
   - `python3 tools/pacing_check.py final.mp4`: no still stretch over 6 seconds.
   - Look at a still every 10 seconds (`ffmpeg -i final.mp4 -vf fps=1/10 sheet_%03d.png`): text readable at phone size, nothing cut off, nothing private, every visual matches what's being said.
   - Loudness: `ffmpeg -i final.mp4 -af ebur128 -f null -` shows I: about -14 LUFS.
   - Length, size and that the file plays with sound.
