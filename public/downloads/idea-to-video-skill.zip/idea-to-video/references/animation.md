# Picture: dynamic full-screen scenes

Viewers stay when the screen keeps changing and shows exactly what's being said.

## The look
- Full screen. No borders or frames around the picture.
- Every sentence shows its own thing, appearing on the word that names it.
- Something new every 3 to 6 seconds; nothing still for more than 6 seconds.
- Use **real** things: real logos (download from the brand's own site), real screens recorded from the real app, real results. Never invent an interface or a number.
- Turn claims into objects that act them out (cards stacking, logos joining, a counter running up, checkmarks landing), not a dark background with text.
- Characters made from a logo need a face that moves (blink, look, smile), not a blob.
- Text stays inside its box and never sits on top of another object.
- Colors and logo from `my-preferences.md`. One accent color per scene.

## Real screens
- Record the real app window with a screen recorder, or let the browser connection take page recordings. Make the app's text big first (zoom the app itself), because enlarging a recording later blurs it.
- Blur or crop anything private before using the footage (see the privacy rule in `SKILL.md`).

## Building scenes with HyperFrames
- One folder per section: `scenes/<id>/` containing `index.html`, `hyperframes.json` (copy from this skill) and `meta.json` (`{"id":"<id>","name":"<id>"}`). Start from `templates/scene/index.html` and the builders in `recipes.js` (kinetic words, charts, step pipelines, task lists, carousels, gallery walls).
- The root: `<div id="root" data-composition-id="main" data-start="0" data-duration="<seconds>" data-width="1920" data-height="1080">`, GSAP from `https://cdn.jsdelivr.net/npm/gsap@3.14.2/dist/gsap.min.js`, one paused timeline, `window.__timelines = {main: tl}`.
- Everything is driven by the timeline (tweens and `tl.set`). No timers, callbacks, random numbers or CSS animations: the renderer jumps to any moment.
- **Timing:** read `script_words.json`. A section runs from its first word's start to the next section's first word. Place every effect at the start time of the word it illustrates, measured from the section start.
- Real footage inside a scene: a `<video>` element with `muted` and `playsinline`, its source in the scene's `assets/` folder.
- Check: `npx --yes hyperframes@0.8.184 lint` (0 errors), then render one section and look at stills from it (`ffmpeg -ss 2 -i out.mp4 -frames:v 1 still.png`) before rendering the rest.
- Render: `npx --yes hyperframes@0.8.184 render --workers 1 --output ../../out/<id>.mp4` from inside the scene folder.
