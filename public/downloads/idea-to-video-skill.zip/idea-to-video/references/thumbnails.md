# Ten thumbnails in ChatGPT Images

Make every thumbnail entirely in ChatGPT Images (the newest version available). Don't assemble or "photoshop" them with code: the image generator gives a finished, cinematic look that gets more clicks.

## Plan 10 different options first
- Look at the thumbnails that rank for the video's main search words, and do something visibly different.
- Each option gets a different hook (proof, transformation, curiosity, plain "says what it is", the free offer), a different layout and a different main color. Write down why each color was chosen.
- 0 to 4 words, huge, readable at phone size. One main idea per thumbnail.
- If the user has a face reference, put them in most options (big face, strong expression). Keep one or two without a face as a test.

## Making them
- Gather real files: the real logos (from the brands' own sites), 2 or 3 real frames from the finished video, and the user's face reference (a saved ChatGPT reference name from `my-preferences.md`, typed with `@`, or a photo). If the video uses an avatar, attach a still of that avatar look too so the face and outfit match.
- In ChatGPT (through the browser connection): one new chat, attach the files, and send one prompt per thumbnail: 16:9, 1280x720 or larger, the exact words, where the face goes, "use this exact logo, do not redraw it", "place this exact frame in the screen, do not change it". Wait for each image (about a minute) and download it into `videos/<name>/thumbnails/` right away: the chat unloads older images as it grows, so download the newest image after each one instead of counting them at the end.
- A saved face reference is inserted by typing `@` plus its name and picking it from the menu that opens; type it once at the start of each prompt.
- If the browser connection isn't available, write the ten prompts into `thumbnails/prompts.md` with the list of files to attach, and give them to the user to paste.

## Check every image
Face matches the reference (redo if it drifted), spelling exact, logo correct and big enough (a logo in a circle fills about 80% of it), placed frames not redrawn into fake screens, nothing cut off at the edges, readable at phone size. Fix any problem with a ChatGPT edit or a new generation, never with local editing.

## Pick
Recommend one plus one different backup, with one line each on why. The user makes the final choice.
