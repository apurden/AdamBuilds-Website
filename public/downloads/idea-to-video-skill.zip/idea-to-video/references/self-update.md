# How this skill updates itself

The skill should get better every time it's used, without the user having to ask.

## When to update

- The user corrects something ("too slow", "don't use that word", "the logo was too small").
- The user states a preference ("always end with...", "I prefer blue").
- You did something new that worked and will be needed again (a new kind of scene, a new tool, a fix for a problem).
- A step changed (a website moved its buttons, a tool needs a new setting, a price or plan changed).
- The setup changed (new tool installed, new account, new avatar look).

Don't update for one-off requests that only apply to this video. If unsure, save it as a note in `my-preferences.md` rather than a rule.

## How to update

1. Copy the file you are about to change into `.backup/<file name>.<YYYY-MM-DD-HHMM>`.
2. Make the smallest clear change in the right place:
   - taste and style go in `my-preferences.md`,
   - tools and accounts go in `my-setup.md`,
   - how a step is done goes in that step's reference file,
   - a change to the overall flow goes in `SKILL.md`.
3. Write it as a plain rule with the reason: "Pauses under 0.3 s (the user finds longer ones slow)."
4. Add one line to the top of `CHANGELOG.md`: `- YYYY-MM-DD: <what changed> (<why>)`.
5. Tell the user in one sentence: "I saved that: ...".

## Never

- Never write passwords, API keys, tokens, account numbers or private data into any skill file.
- Never delete the user's preferences to make room. Merge or rewrite them.
- Never change the honesty or privacy rules to be weaker.
