# Setup interview (first run, and whenever the setup changes)

Goal: learn the user's setup and taste once, so every later video starts from them. Keep it friendly and quick: ask in small groups, offer a sensible default for each question, and accept "use the defaults".

## 1. Check the computer yourself first (don't ask what you can find out)

Run these and note the results in `my-setup.md`:
- Operating system.
- `python3 --version` (or `python --version`), `ffmpeg -version`, `node -v`.
- If something is missing, install it for the user (on a Mac with Homebrew: `brew install ffmpeg node python`; on Windows: `winget install Gyan.FFmpeg`, `winget install OpenJS.NodeJS.LTS`, `winget install Python.Python.3.12`). Say what you are installing. If an install needs a password or admin approval, ask the user to do that one step.
- `npx --yes hyperframes@0.8.184 --version` (the free animation renderer).
- Transcription: `python3 -m pip install --user faster-whisper` (gives a time for every spoken word).
- Free text-to-speech: `python3 -m pip install --user edge-tts`.
- Whether you can use a browser on the user's behalf (for example Claude in Chrome). If yes, note it: thumbnails, HeyGen and the YouTube upload can then be done for them.

## 2. Ask the user (defaults in brackets)

**About the videos**
1. What kind of videos do you make, and who are they for? [practical how-to videos for smart, non-technical people]
2. Your channel name and link, and any website or newsletter link to put in descriptions. [none]
3. Usual length? [5 to 10 minutes; never padded]

**Your voice and style**
4. How do you talk? Paste a script or caption file you've written, or describe it. I'll copy your style: words you use, words you never use. [friendly, short sentences, plain words]
5. Do you want to approve the script before the voice is made? [no, I'll go straight through and you review the finished video]
6. Anything you always say at the end, or a closing segment you always add? [like, subscribe, comment]

**Voice**
7. Which voice? (a) record your own voice while a teleprompter scrolls the script, (b) a free text-to-speech voice, (c) a HeyGen avatar if you have one. [a]
8. If HeyGen: which avatar look? I recommend Avatar 3 (V3) for the whole video: in our tests it looks nearly as good as Avatar 5 for far fewer credits. Avatar 4 showed a grainy look in our tests.

**Look**
9. Brand colors and logo files? [a dark background with one bright accent color]
10. For thumbnails: is there a face to use? If you use ChatGPT Images, a saved reference of yourself (type `@` in ChatGPT to see its name) keeps your face consistent. [no face]

**Privacy**
11. Anything that must never appear on screen? (full name, home city, kids' names, client names, email.) [full name, address, email]

**Upload**
12. Should I upload the finished video to YouTube Studio as Private with everything filled in, so you only review and publish? [yes, if the browser connection works; otherwise I give you the file and the package]

## 3. Save and confirm

- Replace the `NOT SET UP YET` line in `my-setup.md` and `my-preferences.md` with the answers (plain bullet lists).
- Turn steps on or off to match: no HeyGen means voice option (a) or (b); no browser connection means thumbnails come as ten paste-ready ChatGPT prompts with the files to attach, and the upload is done by the user with the package file.
- Add a line to `CHANGELOG.md`: "Setup done: <one-line summary>".
- Tell the user, in two or three sentences, how their videos will be made.

## Re-checking later

At the start of every run, spend a few seconds re-checking the tools and the browser connection. If anything changed (a tool installed, a new account mentioned, a new avatar look), update `my-setup.md`, log it in `CHANGELOG.md`, and say so in one sentence.
