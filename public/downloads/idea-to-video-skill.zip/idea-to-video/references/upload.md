# Private upload to YouTube Studio

Only if `my-setup.md` says the browser connection works and the user said yes to uploads.

1. Open studio.youtube.com in the user's browser and confirm the right channel is selected (the channel name in `my-preferences.md`). If it's a different channel, stop and ask.
2. Create, then Upload videos, and choose `final.mp4`.
3. Fill in the title (the recommended one), description, thumbnail (the recommended one), tags (under Show more), and captions (upload `final.srt`, language English).
4. Audience: "No, it's not made for kids" unless it is. Altered content: leave it for the user (note it in the hand-over).
5. Visibility: **Private**. Save. Never choose Public or Schedule.
6. Copy the video link into `package.md` and tell the user: "It's uploaded as Private with everything filled in. Watch it, pick your thumbnail, and publish when you're happy."
