# Idea, facts and script

## The idea
- Restate the user's sentence as one promise a viewer would click on: what they'll see, learn or get.
- If the idea needs facts (prices, features, dates, numbers), look each one up on the official source today. Keep the link in `videos/<name>/facts.md`. Anything you can't confirm is left out or said as the user's opinion ("in my experience...").

## The script
- Write in the user's voice from `my-preferences.md`. Contractions, short sentences, plain words. Define any technical word in the sentence where it first appears.
- **Shape:** a 5 to 10 second opening that shows or says the most impressive result first; why it matters; the steps, each opened with its number ("Step one, ..."); the result; one positive line from the user as reviewer; the ending they always use.
- **Format:** sections headed `## id | Label` (short lowercase id, one word), one sentence per line, no bullet points in the spoken text, no stage directions in the spoken text. Put scene notes in a separate `scene-notes.md` keyed by section id.
- **Length:** about 150 spoken words a minute. Don't pad.
- Every claim on screen must be something the footage or a real source shows.
- Save as `videos/<name>/script.md` and a plain `voice.txt` (spoken words only, in order) for the voice step.
