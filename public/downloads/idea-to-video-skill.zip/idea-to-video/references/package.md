# The YouTube package

Write everything into `videos/<name>/package.md`, ready to paste.

- **Titles (3 options):** each makes one honest promise. One search-style (the exact words people type, for example "How to make a video with Claude"), one result-style ("Claude Made This Entire Video"), one question or curiosity. Under about 60 characters. Say which you recommend and why.
- **Description:** the first two lines are the hook and the main search words. Then the channel link from `my-preferences.md` on its own line, the links (free download, website, newsletter), the tools used with links, chapters (`0:00 Title`, one per section, first at 0:00, at least 3), and two or three relevant hashtags at most.
- **Tags:** 10 to 20 short phrases people would search.
- **Pinned comment:** one sentence, pointing to the free resource or asking one question.
- **Settings:** made for kids (no, unless it is), category, captions file, and the altered or synthetic content question if an AI voice or avatar was used (the user decides how to answer it; note it for them).
