# My setup

NOT SET UP YET. Run the setup interview in `references/setup-interview.md`.

<!-- After setup this file lists: operating system; Python, ffmpeg, Node versions; whether HyperFrames renders; transcription tool; browser connection (yes/no); voice path (own / text-to-speech / HeyGen); HeyGen avatar look name; ChatGPT image access (yes/no); YouTube upload by browser (yes/no); last checked date. -->
