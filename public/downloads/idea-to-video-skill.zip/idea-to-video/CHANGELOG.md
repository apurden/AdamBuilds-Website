# Changelog

Newest first. One line per change: date, what changed, why.

- 2026-11-11: Voice: use the studio editor for the cheaper lip-sync avatar, paste the script, and never quote credit costs before the render (the first real run cost more than earlier runs).
- 2026-11-11: Thumbnails: download each image right after it's made (older images unload), pick the face reference from the @ menu.

- First version.
