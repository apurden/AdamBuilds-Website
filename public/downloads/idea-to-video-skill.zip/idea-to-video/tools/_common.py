"""Shared helpers: run ffmpeg/ffprobe, read durations, find silences."""
import re, subprocess

def ff(*args):
    subprocess.run(['ffmpeg', '-v', 'error', '-y', *args], check=True)

def duration(path):
    out = subprocess.run(['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', path],
                         capture_output=True, text=True, check=True).stdout
    return float(out.strip())

def has_video(path):
    out = subprocess.run(['ffprobe', '-v', 'error', '-select_streams', 'v', '-show_entries', 'stream=index', '-of', 'csv=p=0', path],
                         capture_output=True, text=True).stdout
    return bool(out.strip())

def silences(wav, min_len, level='-38dB'):
    err = subprocess.run(['ffmpeg', '-hide_banner', '-i', wav, '-af', f'silencedetect=n={level}:d={min_len}', '-f', 'null', '-'],
                         capture_output=True, text=True).stderr
    st = [float(v) for v in re.findall(r'silence_start: ([\d.]+)', err)]
    en = [float(v) for v in re.findall(r'silence_end: ([\d.]+)', err)]
    return list(zip(st, en))
