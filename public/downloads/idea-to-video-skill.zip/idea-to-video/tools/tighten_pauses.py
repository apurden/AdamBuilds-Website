"""Cut every pause longer than 0.3 s out of a voice recording (audio, or an avatar video with picture and sound together).
python3 tighten_pauses.py voice_raw.mp4 [--max 0.3]  ->  voice_tight.wav (and voice_tight.mp4 for a video)"""
import os, sys
from _common import ff, duration, has_video, silences

src = sys.argv[1]
MAXGAP = float(sys.argv[sys.argv.index('--max') + 1]) if '--max' in sys.argv else 0.30
PAD = MAXGAP / 2
folder = os.path.dirname(os.path.abspath(src))
raw_wav = os.path.join(folder, '_voice_raw.wav')
ff('-i', src, '-vn', '-ac', '1', '-ar', '48000', raw_wav)
total = duration(raw_wav)
keep, cur = [], 0.0
for a, b in silences(raw_wav, MAXGAP):
    keep.append([cur, a + PAD]); cur = b - PAD     # leave half the max pause on each side
keep.append([cur, total])
keep = [(round(a * 30) / 30, round(b * 30) / 30) for a, b in keep if b - a > .05]   # whole frames, so picture and sound match
video = has_video(src)
ve = '+'.join(f'between(t,{a - 1e-4:.4f},{b - 1e-4:.4f})' for a, b in keep)
ae = '+'.join(f'between(t,{a:.4f},{b - 1e-5:.5f})' for a, b in keep)
fc = os.path.join(folder, '_tight.fc')
graph = f"[0:a]aresample=48000,asetnsamples=n=48:p=0,aselect='{ae}',asetpts=N/SR/TB[a]"
if video:
    graph = f"[0:v]fps=30,select='{ve}',setpts=N/30/TB[v];" + graph
open(fc, 'w').write(graph)
out_wav = os.path.join(folder, 'voice_tight.wav')
if video:
    out_mp4 = os.path.join(folder, 'voice_tight.mp4')
    ff('-i', src, '-filter_complex_script', fc, '-map', '[v]', '-map', '[a]', '-c:v', 'libx264', '-crf', '16', '-preset', 'fast', '-r', '30', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '256k', out_mp4)
    ff('-i', out_mp4, '-vn', '-ac', '1', '-ar', '48000', out_wav)
else:
    ff('-i', src, '-filter_complex_script', fc, '-map', '[a]', '-ac', '1', out_wav)
os.remove(raw_wav); os.remove(fc)
kept = sum(b - a for a, b in keep)
print(f'{len(keep)} pieces: {total:.1f} s -> {kept:.1f} s ({total - kept:.1f} s of pauses removed)')
