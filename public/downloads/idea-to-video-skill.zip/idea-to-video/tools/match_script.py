"""Give every word of the script a start and end time, by lining it up with the transcript.
python3 match_script.py voice.txt voice_tight.wav.words.json  ->  script_words.json (next to voice.txt)
Prints anything that didn't line up: a misheard name is fine; a missing sentence means the voice skipped it."""
import difflib, json, os, re, sys

ONES = 'zero one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen sixteen seventeen eighteen nineteen'.split()
def norm(w):
    w = re.sub(r"[^a-z0-9]", '', w.lower().replace('’', "'"))
    return ONES[int(w)] if w.isdigit() and int(w) < 20 else w

script_path, words_path = sys.argv[1], sys.argv[2]
script = open(script_path, encoding='utf-8').read().split()
heard = json.load(open(words_path))
A = [norm(x) for x in script]; B = [norm(w['w']) for w in heard]
times = [None] * len(A)
sm = difflib.SequenceMatcher(None, A, B, autojunk=False)
for blk in sm.get_matching_blocks():
    for i in range(blk.size):
        times[blk.a + i] = (heard[blk.b + i]['s'], heard[blk.b + i]['e'])
known = [i for i, t in enumerate(times) if t]
print(f'matched {len(known)} of {len(A)} script words')
for op, a, b, c, d in sm.get_opcodes():
    if op != 'equal':
        print(f'  {op}: script "{" ".join(script[a:b])[:60]}"  heard "{" ".join(w["w"] for w in heard[c:d])[:60]}"')
end = heard[-1]['e'] if heard else 0.0
for i in range(len(times)):          # spread any unmatched words evenly between their matched neighbours
    if times[i] is None:
        lo = max([j for j in known if j < i], default=None); hi = min([j for j in known if j > i], default=None)
        t0 = times[lo][1] if lo is not None else 0.0; t1 = times[hi][0] if hi is not None else end
        n = (hi if hi is not None else len(times)) - (lo if lo is not None else -1)
        f = (i - (lo if lo is not None else -1)) / n
        times[i] = (t0 + (t1 - t0) * f, t0 + (t1 - t0) * f + (t1 - t0) / n)
out = [dict(w=w, s=round(t[0], 3), e=round(t[1], 3)) for w, t in zip(script, times)]
dest = os.path.join(os.path.dirname(os.path.abspath(script_path)), 'script_words.json')
json.dump(out, open(dest, 'w'))
print('wrote', dest)
