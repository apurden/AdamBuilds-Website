"""Lists every stretch where the picture stays still for more than 6 seconds (viewers leave).
python3 pacing_check.py final.mp4 [--max 6]"""
import re, subprocess, sys
from _common import duration

src = sys.argv[1]; mx = float(sys.argv[sys.argv.index('--max') + 1]) if '--max' in sys.argv else 6.0
err = subprocess.run(['ffmpeg', '-hide_banner', '-i', src, '-vf', f'freezedetect=n=0.003:d={mx}', '-map', '0:v', '-f', 'null', '-'],
                     capture_output=True, text=True).stderr
starts = [float(v) for v in re.findall(r'freeze_start: ([\d.]+)', err)]
ends = [float(v) for v in re.findall(r'freeze_end: ([\d.]+)', err)]
ends += [duration(src)] * (len(starts) - len(ends))      # a still that lasts to the very end has no end line
if not starts: print(f'PASS: nothing still for more than {mx:.0f} s')
for a, b in zip(starts, ends): print(f'STILL {b - a:.1f} s from {int(a) // 60}:{a % 60:04.1f}')
