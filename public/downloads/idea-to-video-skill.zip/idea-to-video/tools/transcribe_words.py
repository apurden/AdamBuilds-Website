"""Time for every spoken word, using faster-whisper (free, runs on your computer).
python3 -m pip install --user faster-whisper
python3 transcribe_words.py voice_tight.wav [--model small.en]  ->  voice_tight.wav.words.json"""
import json, sys
from faster_whisper import WhisperModel

src = sys.argv[1]
name = sys.argv[sys.argv.index('--model') + 1] if '--model' in sys.argv else 'small.en'
model = WhisperModel(name, device='auto', compute_type='int8')
segments, _ = model.transcribe(src, word_timestamps=True, vad_filter=False)
words = [dict(w=w.word.strip(), s=round(w.start, 3), e=round(w.end, 3)) for seg in segments for w in seg.words if w.word.strip()]
json.dump(words, open(src + '.words.json', 'w'))
print(len(words), 'words ->', src + '.words.json')
