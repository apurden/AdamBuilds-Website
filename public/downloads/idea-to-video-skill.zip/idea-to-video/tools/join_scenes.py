"""Join rendered scenes on exact frame counts, lay the voice under them, optional avatar bubble, loudness -14 LUFS.
sections.json: {"sections": [{"id": "open", "start": 0.0, "end": 6.2}, ...], "scene_dir": "out", "hide": [[12.0, 15.5]]}
python3 join_scenes.py sections.json voice_tight.wav final.mp4 [--avatar voice_tight.mp4]"""
import json, os, sys
from _common import ff

spec = json.load(open(sys.argv[1])); voice = sys.argv[2]; out = sys.argv[3]
avatar = sys.argv[sys.argv.index('--avatar') + 1] if '--avatar' in sys.argv else None
base = os.path.dirname(os.path.abspath(sys.argv[1])); sd = os.path.join(base, spec.get('scene_dir', 'out'))
secs = spec['sections']; tmp = os.path.join(base, '_body.mp4'); ins = []; g = ''
for k, s in enumerate(secs):
    nf = int(round(s['end'] * 30)) - int(round(s['start'] * 30))
    ins += ['-i', os.path.join(sd, s['id'] + '.mp4')]
    g += f'[{k}:v]fps=30,tpad=stop_mode=clone:stop_duration=2,trim=end_frame={nf},setpts=PTS-STARTPTS,format=yuv420p,setsar=1[v{k}];'
g += ''.join(f'[v{k}]' for k in range(len(secs))) + f'concat=n={len(secs)}:v=1:a=0[v]'
open(os.path.join(base, '_join.fc'), 'w').write(g)
ff(*ins, '-filter_complex_script', os.path.join(base, '_join.fc'), '-map', '[v]', '-c:v', 'libx264', '-crf', '17', '-preset', 'fast', '-r', '30', tmp)
vin = ['-i', tmp, '-i', voice]; fc = ''
if avatar:   # round bubble, bottom-right, hidden during listed ranges
    S = 330; x, y = 1920 - S - 60, 1080 - S - 90
    hide = '+'.join(f'between(t,{a:.3f},{b:.3f})' for a, b in spec.get('hide', [])) or '0'
    vin += ['-i', avatar]
    fc += (f"[2:v]fps=30,crop='min(iw,ih)':'min(iw,ih)',scale={S}:{S},format=rgba,"
           f"geq=r='r(X,Y)':g='g(X,Y)':b='b(X,Y)':a='if(lt(hypot(X-{S/2},Y-{S/2}),{S/2 - 1}),255,0)'[av];"
           f"[0:v][av]overlay={x}:{y}:eof_action=pass:enable='not({hide})'[v];")
else:
    fc += '[0:v]null[v];'
import re as _re, subprocess as _sp
def _lufs(f):
    e = _sp.run(['ffmpeg', '-hide_banner', '-i', f, '-af', 'ebur128', '-f', 'null', '-'], capture_output=True, text=True).stderr
    return float(_re.findall(r'I:\s+(-?[\d.]+) LUFS', e)[-1])
# Loudness: gain then a limiter (peaks under -1.5 dB). The limiter lowers loudness a little, so measure and correct up to 3 times.
lim = os.path.join(base, '_voice_lim.wav'); gain = -14.0 - _lufs(voice)
for _ in range(3):
    ff('-i', voice, '-af', 'aresample=48000,volume=%.2fdB,alimiter=limit=0.84:attack=1:release=60:level=false' % gain, lim)
    miss = -14.0 - _lufs(lim)
    if abs(miss) < 0.3: break
    gain += miss
vin[3] = lim
fc += '[1:a]anull[a]'
open(os.path.join(base, '_mix.fc'), 'w').write(fc)
ff(*vin, '-filter_complex_script', os.path.join(base, '_mix.fc'), '-map', '[v]', '-map', '[a]', '-c:v', 'libx264', '-crf', '17', '-preset', 'medium',
   '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '256k', '-shortest', '-movflags', '+faststart', out)
for f in ('_body.mp4', '_join.fc', '_mix.fc', '_voice_lim.wav'): os.remove(os.path.join(base, f))
print('wrote', out)
