"""Captions from script_words.json: one cue per sentence (split if long), at most 2 lines of 42 characters.
python3 make_srt.py script_words.json final.srt [--offset 0]"""
import json, sys, textwrap

words = json.load(open(sys.argv[1])); out = sys.argv[2]
off = float(sys.argv[sys.argv.index('--offset') + 1]) if '--offset' in sys.argv else 0.0
def ts(t):
    ms = max(0, round(t * 1000)); s, ms = divmod(ms, 1000); m, s = divmod(s, 60); h, m = divmod(m, 60)
    return f'{h:02}:{m:02}:{s:02},{ms:03}'
cues = []
def emit(ws):
    txt = ' '.join(w['w'] for w in ws)
    if len(txt) > 84 and len(ws) > 4:
        k = len(ws) // 2
        commas = [j + 1 for j, w in enumerate(ws[:-1]) if w['w'][-1] in ',;:' and .3 * len(ws) <= j + 1 <= .7 * len(ws)]
        if commas: k = min(commas, key=lambda j: abs(j - len(ws) / 2))
        emit(ws[:k]); emit(ws[k:]); return
    cues.append((ws[0]['s'] + off, ws[-1]['e'] + off, txt))
cur = []
for w in words:
    cur.append(w)
    if w['w'][-1] in '.?!' and len(cur) > 2: emit(cur); cur = []
if cur: emit(cur)
lines = []
for i, (a, b, t) in enumerate(cues):
    b = max(b, a + 0.8)
    if i + 1 < len(cues): b = min(b, cues[i + 1][0] - 0.02)
    lines.append(f'{i + 1}\n{ts(a)} --> {ts(b)}\n' + '\n'.join(textwrap.wrap(t, 42, break_long_words=False)) + '\n')
open(out, 'w', encoding='utf-8').write('\n'.join(lines))
print(len(cues), 'captions ->', out)
