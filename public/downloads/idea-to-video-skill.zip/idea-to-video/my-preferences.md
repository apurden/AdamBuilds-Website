# My preferences

NOT SET UP YET. Run the setup interview in `references/setup-interview.md`.

<!-- After setup this file lists: who the videos are for; channel name and link; newsletter or website link; usual length; how I talk (words I use, words I never use, example lines); brand colors and logo files; my face reference for thumbnails (for example a saved ChatGPT reference name); ending I always use; things never to show on screen; whether I want to approve the script before the voice is made. -->
