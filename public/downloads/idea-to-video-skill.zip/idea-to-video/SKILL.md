---
name: idea-to-video
description: Turn one sentence idea into a finished YouTube video and its full upload package - script in the user's own voice, dynamic full-screen animations, narration (the user's own recording, free text-to-speech, or a HeyGen avatar), assembly with tight pauses, sound effects and captions, the title, description, chapters, tags and pinned comment, ten thumbnail options made in ChatGPT Images, and a private YouTube upload. Use whenever the user says "make a video about...", "turn this idea into a video", "make me a YouTube video", "build the package", "make thumbnails", or runs this skill for the first time. On first run it interviews the user about their setup and preferences, and it updates itself whenever it learns something new.
---

# Idea to video

One sentence in, a finished video and a ready-to-upload package out. The user reviews the result; you do the rest.

## 0. Every run starts here

1. Read `my-setup.md` and `my-preferences.md` in this skill folder.
2. If either still says `NOT SET UP YET`, run the **setup interview** (`references/setup-interview.md`) before anything else, then continue.
3. Quickly re-check the setup (tools installed, browser connection, accounts the user mentioned). If something changed, update `my-setup.md` and tell the user in one sentence.
4. Read `CHANGELOG.md` so you know what this copy of the skill has already learned.

## The workflow

Work in a new folder for each video: `videos/<short-name>/`. Never write into a folder that holds other work.

1. **Idea and facts** (`references/script.md`). Restate the idea in one line. Check every fact, number, price or feature claim against its official source before it goes in. If something can't be checked, leave it out or say it as the user's opinion.
2. **Script** (`references/script.md`). Write it in the user's voice from `my-preferences.md`. One sentence per line, short sections with `## id | Label` headers. Show it to the user only if `my-preferences.md` says they want to approve scripts; otherwise keep going.
3. **Voice** (`references/voice.md`). Use the path in `my-setup.md`: the user's own recording (with the teleprompter), free text-to-speech, or a HeyGen avatar. Then cut every pause longer than 0.3 seconds and get a time for every word.
4. **Picture** (`references/animation.md`). Build full-screen, fast-moving scenes with HyperFrames, each one placed on the exact word it illustrates. Use real logos and real screens. Something new every 3 to 6 seconds.
5. **Assemble** (`references/assemble.md`). Join the scenes on exact frame counts, put the voice and sound effects under them, set loudness to -14 LUFS, write captions, run the checks.
6. **Package** (`references/package.md`). Three title options, description with chapters and links, tags, one-sentence pinned comment.
7. **Thumbnails** (`references/thumbnails.md`). Ten clearly different options made in ChatGPT Images, then a recommended pick and a backup.
8. **Upload** (`references/upload.md`). Upload as **Private** with everything filled in, if the user's setup allows it. Never publish or schedule; the user does that after reviewing.
9. **Hand over.** Tell the user what was made, where the files are, what you verified, and anything they should look at. Keep it short and positive.

## Ground rules

- **Honesty:** nothing on screen, in the title or on a thumbnail may be invented. Real screens, real numbers, real results.
- **Privacy:** before anything is shared, check every frame, file and description for the user's full name, addresses, emails, account numbers, file paths with their username, and open tabs or notifications. Blur or remove them. The list of things the user never wants shown is in `my-preferences.md`.
- **Plain words:** explain any technical word in the same sentence it first appears.
- **No code on screen** unless the user asks for it. Show the real app doing the work.
- **Cost:** before spending paid credits (HeyGen, image generators), make sure the script is final. Log credits spent in the video folder.

## It updates itself (`references/self-update.md`)

When you do something this skill hasn't done before, when a step changes, or when the user corrects you or states a preference, update this skill **in the same session**:
- change the right file (`SKILL.md`, a reference file, `my-preferences.md` or `my-setup.md`),
- copy the old version into `.backup/` first,
- add a dated line to `CHANGELOG.md`,
- tell the user in one sentence: "I saved that: ...".

Never write passwords, API keys, tokens or private data into any skill file.

## Files

- `my-setup.md`, `my-preferences.md`: filled in by the setup interview, kept current.
- `CHANGELOG.md`: what this copy has learned.
- `references/`: one file per step.
- `tools/`: small Python helpers (need Python 3 and ffmpeg).
- `templates/`: a scene starter and the teleprompter.
- `recipes.js`, `hyperframes.json`, `sounds/`: animation building blocks and free sound effects (licenses in `sounds/LICENSES.md`).
